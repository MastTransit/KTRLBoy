import { builtInCommandDescriptions, createCommandRouter } from "../src/core/commandRouter.js";
import { createCommandStore } from "../src/core/commandStore.js";

const smokeName = "ktrl_smoke_chat_mod";
const replies = [];

const commandStore = createCommandStore({
  reservedNames: Object.keys(builtInCommandDescriptions),
});
commandStore.remove(smokeName);

const moduleSettings = {
  commands: { label: "Custom Commands", enabled: true },
  timers: { label: "Timers", enabled: true },
  spamFilters: { label: "Spam Filters", enabled: true },
  modCommandManager: { label: "Moderator Command Manager", enabled: true },
};
const moduleStore = {
  getSettings: () => moduleSettings,
  isEnabled: (name) => moduleSettings[name]?.enabled !== false,
  updateSettings(input) {
    for (const [key, value] of Object.entries(input)) {
      moduleSettings[key] = {
        ...moduleSettings[key],
        ...value,
      };
    }
    return moduleSettings;
  },
};

const router = createCommandRouter({
  commandPrefix: "!",
  botName: "KTRLBoy",
  commandStore,
  moduleStore,
});

function context({ text, isModerator = false }) {
  return {
    platform: "test",
    channel: "local",
    text,
    user: {
      id: isModerator ? "mod-1" : "viewer-1",
      name: isModerator ? "mod" : "viewer",
      displayName: isModerator ? "Mod" : "Viewer",
      isModerator,
    },
    reply: async (message) => replies.push(message),
  };
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

await router.handleMessage(context({ text: `!cmd add ${smokeName} should not save` }));
assert(!commandStore.get(smokeName), "viewer was able to add a command");
assert(replies.pop() === "Only chat moderators can manage commands.", "viewer denial reply was wrong");

await router.handleMessage(
  context({
    text: `!cmd add ${smokeName} Hello {arg1} from {bot}`,
    isModerator: true,
  }),
);
assert(commandStore.get(smokeName)?.response === "Hello {arg1} from {bot}", "moderator add failed");

await router.handleMessage(context({ text: `!${smokeName} Levi`, isModerator: true }));
assert(replies.pop() === "Hello Levi from KTRLBoy", "custom command response failed");

await router.handleMessage(
  context({
    text: `!cmd edit ${smokeName} Updated {user} on {platform}`,
    isModerator: true,
  }),
);
assert(commandStore.get(smokeName)?.response === "Updated {user} on {platform}", "moderator edit failed");

await router.handleMessage(context({ text: `!${smokeName}`, isModerator: true }));
assert(replies.pop() === "Updated Mod on test", "edited command response failed");

await router.handleMessage(context({ text: `!cmd disable ${smokeName}`, isModerator: true }));
assert(commandStore.get(smokeName)?.enabled === false, "moderator disable failed");

await router.handleMessage(context({ text: `!cmd enable ${smokeName}`, isModerator: true }));
assert(commandStore.get(smokeName)?.enabled === true, "moderator enable failed");

await router.handleMessage(context({ text: "!module commands disable", isModerator: true }));
assert(moduleSettings.commands.enabled === false, "moderator module disable failed");
const replyCountBeforeDisabledCommand = replies.length;
await router.handleMessage(context({ text: `!${smokeName}`, isModerator: true }));
assert(replies.length === replyCountBeforeDisabledCommand, "custom command responded while commands module was disabled");

await router.handleMessage(context({ text: "!module commands enable", isModerator: true }));
assert(moduleSettings.commands.enabled === true, "moderator module enable failed");

await router.handleMessage(context({ text: `!cmd delete ${smokeName}`, isModerator: true }));
assert(!commandStore.get(smokeName), "moderator delete failed");

await router.handleMessage(
  context({
    text: "!cmd add ping cannot replace built-ins",
    isModerator: true,
  }),
);
assert(
  replies.pop().startsWith("Command update failed:"),
  "built-in command protection was not enforced",
);

console.log("chat command manager smoke test passed");
