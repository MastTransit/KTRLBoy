﻿const {
  getConfig,
  updateConfig
} = require("./config");

const {
  getPlatformSummary
} = require("./platform-manager");

function getRuntimeStatus() {
  const config = getConfig();
  const platformSummary = getPlatformSummary();

  return {
    runtimeEnabled: config.runtimeEnabled === true,
    state: config.runtimeEnabled === true ? "started" : "stopped",
    connected: false,
    connectedPlatforms: [],
    platformSummary,
    notes: [
      "Runtime control is KTRL-native.",
      "Real Twitch/YouTube/Kick adapters are not connected yet.",
      "Start enables KTRLboy runtime readiness checks only for now."
    ]
  };
}

function startRuntime() {
  const config = updateConfig({
    runtimeEnabled: true
  });

  return {
    action: "start",
    config,
    runtime: getRuntimeStatus()
  };
}

function stopRuntime() {
  const config = updateConfig({
    runtimeEnabled: false
  });

  return {
    action: "stop",
    config,
    runtime: getRuntimeStatus()
  };
}

function restartRuntime() {
  stopRuntime();
  return {
    action: "restart",
    ...startRuntime()
  };
}

module.exports = {
  getRuntimeStatus,
  startRuntime,
  stopRuntime,
  restartRuntime
};
