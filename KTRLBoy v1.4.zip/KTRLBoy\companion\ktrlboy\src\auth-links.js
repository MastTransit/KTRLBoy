﻿const crypto = require("crypto");

const {
  getConfig,
  updateConfig
} = require("./config");

const {
  getTokenProviderRaw,
  setTokenProvider
} = require("./token-manager");

const PROVIDERS = {
  twitch: {
    id: "twitch",
    label: "Twitch",
    docs: "Twitch OAuth uses the KTRL-native callback route."
  },
  youtube: {
    id: "youtube",
    label: "YouTube Live",
    docs: "YouTube OAuth will be wired in a later adapter/auth pass."
  },
  kick: {
    id: "kick",
    label: "Kick",
    docs: "Kick authorization will be wired in a later adapter/auth pass."
  }
};

function getTwitchAuthConfig() {
  const config = getConfig();
  const twitch = config.platforms?.twitch || {};
  const tokenRaw = getTokenProviderRaw("twitch");

  const clientId = twitch.clientId || tokenRaw.clientId || "";
  const redirectUri = twitch.redirectUri || "http://localhost:3000/api/ktrlboy/auth/twitch/callback";
  const scopes = Array.isArray(twitch.scopes)
    ? twitch.scopes
    : ["chat:read", "chat:edit"];

  return {
    clientId,
    redirectUri,
    scopes,
    state: twitch.oauthState || "",
    hasClientId: Boolean(clientId),
    hasRedirectUri: Boolean(redirectUri),
    readyForAuthUrl: Boolean(clientId && redirectUri),
    readyForTokenExchange: Boolean(clientId && redirectUri)
  };
}

function getAuthProvider(providerId) {
  const provider = PROVIDERS[providerId];

  if (!provider) {
    throw new Error(`Unknown auth provider: ${providerId}`);
  }

  const twitchConfig = providerId === "twitch"
    ? getTwitchAuthConfig()
    : null;

  const authReady = providerId === "twitch"
    ? twitchConfig.readyForAuthUrl
    : false;

  return {
    ...provider,
    authReady,
    route: `/api/ktrlboy/auth/${providerId}`,
    startRoute: `/api/ktrlboy/auth/${providerId}/start`,
    callbackRoute: `/api/ktrlboy/auth/${providerId}/callback`,
    status: authReady ? "config_ready" : "placeholder",
    config: providerId === "twitch"
      ? {
          hasClientId: twitchConfig.hasClientId,
          hasRedirectUri: twitchConfig.hasRedirectUri,
          redirectUri: twitchConfig.redirectUri,
          scopes: twitchConfig.scopes
        }
      : null
  };
}

function listAuthProviders() {
  return Object.keys(PROVIDERS).map(getAuthProvider);
}

function createTwitchState() {
  return crypto.randomBytes(24).toString("hex");
}

function saveTwitchState(state) {
  const config = getConfig();

  updateConfig({
    platforms: {
      twitch: {
        ...(config.platforms?.twitch || {}),
        oauthState: state
      }
    }
  });
}

function buildTwitchAuthUrl() {
  const twitchConfig = getTwitchAuthConfig();

  if (!twitchConfig.readyForAuthUrl) {
    return null;
  }

  const state = createTwitchState();
  saveTwitchState(state);

  const params = new URLSearchParams({
    response_type: "token",
    client_id: twitchConfig.clientId,
    redirect_uri: twitchConfig.redirectUri,
    scope: twitchConfig.scopes.join(" "),
    state,
    force_verify: "true"
  });

  return `https://id.twitch.tv/oauth2/authorize?${params.toString()}`;
}

function getAuthStart(providerId) {
  const provider = getAuthProvider(providerId);

  if (providerId === "twitch") {
    const authUrl = buildTwitchAuthUrl();

    return {
      provider,
      canStart: Boolean(authUrl),
      authUrl,
      message: authUrl
        ? "Twitch auth URL is ready. Complete auth in the browser."
        : "Twitch auth needs a Client ID before an auth URL can be generated."
    };
  }

  return {
    provider,
    canStart: false,
    authUrl: null,
    message: `${provider.label} auth is not wired yet. This route is reserved for the KTRLboy auth rebuild.`
  };
}

function getTwitchAuthPreflight() {
  const twitchConfig = getTwitchAuthConfig();
  const missing = [];

  if (!twitchConfig.hasClientId) missing.push("clientId");
  if (!twitchConfig.hasRedirectUri) missing.push("redirectUri");
  if (!Array.isArray(twitchConfig.scopes) || twitchConfig.scopes.length === 0) missing.push("scopes");

  return {
    provider: "twitch",
    readyForAuthUrl: twitchConfig.readyForAuthUrl,
    readyForTokenExchange: twitchConfig.readyForTokenExchange,
    missing,
    config: {
      hasClientId: twitchConfig.hasClientId,
      hasRedirectUri: twitchConfig.hasRedirectUri,
      redirectUri: twitchConfig.redirectUri,
      scopes: twitchConfig.scopes
    },
    notes: [
      "Redirect URI must exactly match the Twitch Developer Console redirect URL.",
      "KTRLboy uses a client-side authorization popup and does not require a Client Secret.",
      "Use Generate Twitch Auth URL from /KTRLboy instead of opening the callback URL directly."
    ]
  };
}

async function validateTwitchToken() {
  const tokenRaw = getTokenProviderRaw("twitch");
  const accessToken = tokenRaw.accessToken || "";

  if (!accessToken) {
    return {
      valid: false,
      provider: "twitch",
      reason: "missing_access_token",
      redacted: true
    };
  }

  const response = await fetch("https://id.twitch.tv/oauth2/validate", {
    headers: {
      Authorization: `OAuth ${accessToken}`
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    return {
      valid: false,
      provider: "twitch",
      reason: data.message || data.status || "token_validation_failed",
      redacted: true
    };
  }

  return {
    valid: true,
    provider: "twitch",
    login: data.login || null,
    userId: data.user_id || null,
    clientId: data.client_id || null,
    scopes: Array.isArray(data.scopes) ? data.scopes : [],
    expiresIn: data.expires_in || null,
    redacted: true
  };
}

async function exchangeTwitchCode(query = {}) {
  if (query.access_token) {
    return saveTwitchClientToken(query);
  }

  const code = query.code || "";
  const returnedState = query.state || "";
  const error = query.error || "";
  const errorDescription = query.error_description || "";

  if (error) {
    throw new Error(`${error}: ${errorDescription || "Twitch authorization failed."}`);
  }

  if (!code) {
    throw new Error("Missing Twitch popup token. Open /KTRLboy, save Twitch client config, click Generate Twitch Auth URL, then use Open Twitch Auth.");
  }

  const config = getConfig();
  const expectedState = config.platforms?.twitch?.oauthState || "";

  if (!expectedState || returnedState !== expectedState) {
    throw new Error("Invalid Twitch OAuth state.");
  }

  const twitchConfig = getTwitchAuthConfig();

  if (!twitchConfig.readyForTokenExchange) {
    throw new Error("Twitch authorization needs Client ID and Redirect URI.");
  }

  const body = new URLSearchParams({
    client_id: twitchConfig.clientId,
    code,
    grant_type: "authorization_code",
    redirect_uri: twitchConfig.redirectUri
  });

  const response = await fetch("https://id.twitch.tv/oauth2/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || data.error_description || data.error || "Twitch token exchange failed.");
  }

  const expiresAt = data.expires_in
    ? new Date(Date.now() + Number(data.expires_in) * 1000).toISOString()
    : null;

  const provider = setTokenProvider("twitch", {
    accessToken: data.access_token || "",
    refreshToken: data.refresh_token || "",
    clientId: twitchConfig.clientId,
    expiresAt,
    scopes: Array.isArray(data.scope) ? data.scope : twitchConfig.scopes
  });

  updateConfig({
    platforms: {
      twitch: {
        ...(config.platforms?.twitch || {}),
        oauthState: ""
      }
    }
  });

  return {
    provider,
    redacted: true,
    message: "Twitch authorization complete. Token values were stored and redacted."
  };
}

async function saveTwitchClientToken(payload = {}) {
  const accessToken = payload.accessToken || payload.access_token || "";
  const returnedState = payload.state || "";
  if (!accessToken) throw new Error("Missing Twitch access token from authorization popup.");

  const config = getConfig();
  const expectedState = config.platforms?.twitch?.oauthState || "";
  if (!expectedState || returnedState !== expectedState) {
    throw new Error("Invalid Twitch OAuth state.");
  }

  const validation = await validateTwitchAccessToken(accessToken);
  if (!validation.valid) {
    throw new Error(validation.reason || "Twitch token validation failed.");
  }

  const expiresAt = payload.expiresIn || payload.expires_in
    ? new Date(Date.now() + Number(payload.expiresIn || payload.expires_in) * 1000).toISOString()
    : null;
  const twitchConfig = getTwitchAuthConfig();
  const provider = setTokenProvider("twitch", {
    accessToken,
    clientId: twitchConfig.clientId,
    expiresAt,
    scopes: payload.scope ? String(payload.scope).split(/[,\s]+/).filter(Boolean) : twitchConfig.scopes
  });

  updateConfig({
    platforms: {
      twitch: {
        ...(config.platforms?.twitch || {}),
        oauthState: ""
      }
    }
  });

  return {
    provider,
    validation,
    redacted: true,
    message: "Twitch authorization complete. Token values were stored and redacted."
  };
}

async function validateTwitchAccessToken(accessToken) {
  if (!accessToken) {
    return {
      valid: false,
      provider: "twitch",
      reason: "missing_access_token",
      redacted: true
    };
  }

  const response = await fetch("https://id.twitch.tv/oauth2/validate", {
    headers: {
      Authorization: `OAuth ${accessToken}`
    }
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    return {
      valid: false,
      provider: "twitch",
      reason: data.message || data.status || "token_validation_failed",
      redacted: true
    };
  }

  return {
    valid: true,
    provider: "twitch",
    login: data.login || null,
    userId: data.user_id || null,
    clientId: data.client_id || null,
    scopes: Array.isArray(data.scopes) ? data.scopes : [],
    expiresIn: data.expires_in || null,
    redacted: true
  };
}

module.exports = {
  PROVIDERS,
  listAuthProviders,
  getAuthProvider,
  getAuthStart,
  getTwitchAuthConfig,
  buildTwitchAuthUrl,
  exchangeTwitchCode,
  saveTwitchClientToken,
  getTwitchAuthPreflight,
  validateTwitchToken
};
