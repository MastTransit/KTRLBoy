import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";

const guiRoot = path.join(process.cwd(), "src", "gui");
const resolvedGuiRoot = path.resolve(guiRoot);
const envPath = path.join(process.cwd(), ".env");
const envExamplePath = path.join(process.cwd(), ".env.example");
const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
};

function writeJson(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(body, null, 2));
}

function writeHtml(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error("Request body must be valid JSON."));
      }
    });
    req.on("error", reject);
  });
}

function writeFile(res, filePath) {
  fs.readFile(filePath, (error, content) => {
    if (error) {
      writeJson(res, 404, { ok: false, error: "Not found" });
      return;
    }

    const extension = path.extname(filePath);
    res.writeHead(200, {
      "Content-Type": mimeTypes[extension] || "application/octet-stream",
      "Cache-Control": "no-store",
    });
    res.end(content);
  });
}

function tryServeGui(req, res) {
  if (req.method !== "GET") return false;

  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/" || url.pathname === "/gui") {
    writeFile(res, path.join(guiRoot, "index.html"));
    return true;
  }

  if (!url.pathname.startsWith("/gui/")) return false;

  const requestedPath = decodeURIComponent(url.pathname.replace("/gui/", ""));
  const filePath = path.resolve(guiRoot, requestedPath);
  if (filePath !== resolvedGuiRoot && !filePath.startsWith(`${resolvedGuiRoot}${path.sep}`)) {
    writeJson(res, 403, { ok: false, error: "Forbidden" });
    return true;
  }

  writeFile(res, filePath);
  return true;
}

function launcherBaseUrl(config) {
  return `${config.launcherStatus.protocol || "http"}://${config.launcherStatus.host}:${config.launcherStatus.port}`;
}

function resolveProjectPath(filePath) {
  if (!filePath) return "";
  return path.isAbsolute(filePath) ? filePath : path.resolve(process.cwd(), filePath);
}

function httpsOptions(config) {
  const pfxPath = resolveProjectPath(config.launcherStatus.https?.pfxPath);
  if (pfxPath) {
    if (!fs.existsSync(pfxPath)) {
      throw new Error(`HTTPS PFX file was not found: ${pfxPath}`);
    }

    return {
      pfx: fs.readFileSync(pfxPath),
      passphrase: config.launcherStatus.https?.pfxPassphrase || undefined,
    };
  }

  const certPath = resolveProjectPath(config.launcherStatus.https?.certPath);
  const keyPath = resolveProjectPath(config.launcherStatus.https?.keyPath);
  const missing = missingFields({
    LAUNCHER_STATUS_HTTPS_CERT_PATH: certPath,
    LAUNCHER_STATUS_HTTPS_KEY_PATH: keyPath,
  });

  if (missing.length) {
    throw new Error(`HTTPS status server is missing ${missing.join(", ")}`);
  }

  if (!fs.existsSync(certPath)) {
    throw new Error(`HTTPS certificate file was not found: ${certPath}`);
  }

  if (!fs.existsSync(keyPath)) {
    throw new Error(`HTTPS private key file was not found: ${keyPath}`);
  }

  return {
    cert: fs.readFileSync(certPath),
    key: fs.readFileSync(keyPath),
  };
}

function missingFields(fields) {
  return Object.entries(fields)
    .filter(([, value]) => !value)
    .map(([name]) => name);
}

function envKey(provider, field) {
  return `${provider.toUpperCase()}_${field}`;
}

function oauthSettingsSnapshot(config) {
  return {
    updatedAt: new Date().toISOString(),
    providers: Object.fromEntries(
      ["twitch", "youtube", "kick"].map((provider) => {
        const oauth = config.oauth?.[provider] || {};
        return [
          provider,
          {
            label: provider === "youtube" ? "YouTube" : provider.slice(0, 1).toUpperCase() + provider.slice(1),
            clientId: oauth.clientId || "",
            authMode: provider === "kick" ? "popup-pkce" : "client-popup",
            scopes: oauth.scopes || [],
            callbackUrl: `${config.oauth.redirectBaseUrl.replace(/\/$/, "")}/auth/${provider}/callback`,
            missing: missingFields({
              [envKey(provider, "CLIENT_ID")]: oauth.clientId,
            }),
          },
        ];
      }),
    ),
  };
}

function cleanEnvValue(value) {
  return String(value ?? "").replace(/\r?\n/g, "").trim();
}

function formatEnvLine(key, value) {
  return `${key}=${cleanEnvValue(value)}`;
}

function updateDotEnv(values) {
  const sourcePath = fs.existsSync(envPath) ? envPath : envExamplePath;
  const source = fs.existsSync(sourcePath) ? fs.readFileSync(sourcePath, "utf8") : "";
  const lines = source.split(/\r?\n/);
  const pending = new Map(Object.entries(values).map(([key, value]) => [key, cleanEnvValue(value)]));
  const updated = lines.map((line) => {
    const match = line.match(/^([A-Z0-9_]+)=/);
    if (!match || !pending.has(match[1])) return line;

    const key = match[1];
    const value = pending.get(key);
    pending.delete(key);
    return formatEnvLine(key, value);
  });

  if (pending.size) {
    if (updated.length && updated[updated.length - 1] !== "") updated.push("");
    for (const [key, value] of pending) {
      updated.push(formatEnvLine(key, value));
    }
  }

  fs.writeFileSync(envPath, `${updated.join("\n").replace(/\n*$/, "")}\n`, "utf8");
}

function applyOAuthSettings(config, body) {
  const provider = String(body.provider || "").toLowerCase();
  if (!["twitch", "youtube", "kick"].includes(provider)) {
    throw new Error("Unknown OAuth provider.");
  }

  const oauth = config.oauth[provider];
  const updates = {};
  const clientId = cleanEnvValue(body.clientId);
  const rawScopes = body.scopes;
  const scopes = Array.isArray(rawScopes)
    ? body.scopes.map(cleanEnvValue).filter(Boolean)
    : cleanEnvValue(rawScopes)
        .split(/[\s,]+/)
        .map((item) => item.trim())
        .filter(Boolean);

  if (!clientId) {
    throw new Error(`${envKey(provider, "CLIENT_ID")} is required.`);
  }

  oauth.clientId = clientId;
  updates[envKey(provider, "CLIENT_ID")] = clientId;

  if (Array.isArray(rawScopes) || cleanEnvValue(rawScopes)) {
    oauth.scopes = scopes;
    updates[envKey(provider, "OAUTH_SCOPES")] = scopes.join(" ");
  }

  if (provider === "twitch") {
    config.twitch.clientId = oauth.clientId;
  }

  if (Object.keys(updates).length) updateDotEnv(updates);
  return oauthSettingsSnapshot(config).providers[provider];
}

function channelApiSnapshot(config, oauthStatus) {
  const twitchMetadata = oauthStatus.twitch?.metadata || {};
  const youtubeMetadata = oauthStatus.youtube?.metadata || {};
  const kickMetadata = oauthStatus.kick?.metadata || {};

  const twitchConnected = Boolean(oauthStatus.twitch?.connected);
  const youtubeConnected = Boolean(oauthStatus.youtube?.connected);
  const kickConnected = Boolean(oauthStatus.kick?.connected);

  const twitchAccessMode = twitchConnected
    ? "streamer-account"
    : config.twitch.oauthToken
      ? "manual-env"
      : "not-connected";
  const youtubeAccessMode = youtubeConnected
    ? "streamer-account"
    : config.youtube.accessToken
      ? "manual-env"
      : "not-connected";
  const kickAccessMode = kickConnected
    ? "streamer-account"
    : config.kick.accessToken
      ? "manual-env"
      : "not-connected";

  return {
    updatedAt: new Date().toISOString(),
    providers: {
      twitch: {
        label: "Twitch",
        loginConfigured: Boolean(config.oauth.twitch.clientId),
        loginMissing: missingFields({
          TWITCH_CLIENT_ID: config.oauth.twitch.clientId,
        }),
        connected: twitchConnected,
        chatReady: Boolean(twitchConnected || config.twitch.oauthToken),
        configured: Boolean(twitchConnected || config.twitch.oauthToken),
        accessMode: twitchAccessMode,
        account:
          twitchMetadata.displayName ||
          twitchMetadata.username ||
          config.twitch.username ||
          "",
        channelName:
          config.twitch.channel ||
          twitchMetadata.channelSlug ||
          twitchMetadata.username ||
          "",
        channelId: twitchMetadata.userId || config.twitch.broadcasterId || "",
        scopes: oauthStatus.twitch?.scopes || config.oauth.twitch.scopes || [],
        missing: missingFields({
          STREAMER_ACCOUNT_LOGIN: twitchConnected || config.twitch.oauthToken,
        }),
        actions: {
          connect: "/auth/twitch/start?flow=browser",
          refresh: "/api/channel-api/twitch/refresh",
          sync: "/api/channel-api/twitch/sync",
        },
      },
      youtube: {
        label: "YouTube",
        loginConfigured: Boolean(config.oauth.youtube.clientId),
        loginMissing: missingFields({
          YOUTUBE_CLIENT_ID: config.oauth.youtube.clientId,
        }),
        connected: youtubeConnected,
        chatReady: Boolean((youtubeConnected || config.youtube.accessToken) && config.youtube.liveChatId),
        configured: Boolean(youtubeConnected || config.youtube.accessToken),
        accessMode: youtubeAccessMode,
        account:
          youtubeMetadata.channelTitle ||
          youtubeMetadata.customUrl ||
          youtubeMetadata.broadcastTitle ||
          "",
        channelName: youtubeMetadata.channelTitle || "",
        channelId: youtubeMetadata.channelId || "",
        liveChatId: config.youtube.liveChatId || youtubeMetadata.liveChatId || "",
        broadcastId: youtubeMetadata.broadcastId || "",
        scopes: oauthStatus.youtube?.scopes || config.oauth.youtube.scopes || [],
        missing: missingFields({
          STREAMER_ACCOUNT_LOGIN: youtubeConnected || config.youtube.accessToken,
          YOUTUBE_LIVE_CHAT_ID: config.youtube.liveChatId || youtubeMetadata.liveChatId,
        }),
        actions: {
          connect: "/auth/youtube/start?flow=browser",
          refresh: "/api/channel-api/youtube/refresh",
          sync: "/api/channel-api/youtube/sync",
          discoverChat: "/api/channel-api/youtube/discover-chat",
        },
      },
      kick: {
        label: "Kick",
        loginConfigured: Boolean(config.oauth.kick.clientId),
        loginMissing: missingFields({
          KICK_CLIENT_ID: config.oauth.kick.clientId,
        }),
        connected: kickConnected,
        chatReady: Boolean(kickConnected || config.kick.accessToken),
        configured: Boolean(kickConnected || config.kick.accessToken),
        accessMode: kickAccessMode,
        account:
          kickMetadata.displayName ||
          kickMetadata.username ||
          kickMetadata.channelSlug ||
          "",
        channelName: kickMetadata.channelSlug || kickMetadata.username || "",
        channelId: String(kickMetadata.userId || config.kick.broadcasterUserId || ""),
        scopes: oauthStatus.kick?.scopes || config.oauth.kick.scopes || [],
        missing: missingFields({
          STREAMER_ACCOUNT_LOGIN: kickConnected || config.kick.accessToken,
        }),
        actions: {
          connect: "/auth/kick/start?flow=browser",
          refresh: "/api/channel-api/kick/refresh",
          sync: "/api/channel-api/kick/sync",
        },
      },
    },
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function oauthResultPage(title, message, event = null) {
  const eventJson = event ? JSON.stringify(event).replaceAll("</", "<\\/") : "null";

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${title}</title>
    <style>
      body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #07090b; color: #f4f5f7; font-family: system-ui, sans-serif; }
      main { width: min(520px, calc(100vw - 32px)); border: 1px solid #2b3038; border-top-color: #7e2027; background: #101318; padding: 28px; box-shadow: 0 18px 48px rgba(0, 0, 0, .42); }
      h1 { margin: 0 0 10px; font-size: 1.45rem; }
      p { color: #9aa1ab; line-height: 1.5; }
      a { color: #ff5960; font-weight: 800; }
    </style>
  </head>
  <body>
    <main>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(message)}</p>
      <a href="/#logins">Back to KTRLBoy setup</a>
    </main>
    <script>
      const event = ${eventJson};
      if (event) {
        try {
          localStorage.setItem("ktrlboy-auth-event", JSON.stringify(event));
          if (window.opener) window.opener.postMessage(event, window.location.origin);
        } catch {}
        window.setTimeout(() => {
          if (window.opener) window.close();
          else window.location.href = event.intent === "consumer" ? "/#consumers" : "/#logins";
        }, 1600);
      }
    </script>
  </body>
</html>`;
}

function oauthClientTokenPage(provider) {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${escapeHtml(provider)} authorization</title>
    <style>
      body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #07090b; color: #f4f5f7; font-family: system-ui, sans-serif; }
      main { width: min(520px, calc(100vw - 32px)); border: 1px solid #2b3038; border-top-color: #7e2027; background: #101318; padding: 28px; box-shadow: 0 18px 48px rgba(0, 0, 0, .42); }
      h1 { margin: 0 0 10px; font-size: 1.45rem; }
      p { color: #9aa1ab; line-height: 1.5; }
      a { color: #ff5960; font-weight: 800; }
    </style>
  </head>
  <body>
    <main>
      <h1>Finishing ${escapeHtml(provider)} authorization</h1>
      <p id="message">Reading the authorization popup response from the provider website.</p>
      <a href="/#logins">Back to KTRLBoy setup</a>
    </main>
    <script>
      const message = document.querySelector("#message");
      const params = new URLSearchParams((window.location.hash || "").replace(/^#/, ""));
      const payload = {
        state: params.get("state"),
        accessToken: params.get("access_token"),
        tokenType: params.get("token_type"),
        expiresIn: params.get("expires_in"),
        scope: params.get("scope")
      };
      if (!payload.accessToken) {
        message.textContent = "The provider did not return an access token. Start the popup authorization again from KTRLBoy.";
      } else {
        fetch("/auth/${provider}/token", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        })
          .then(async (response) => {
            const body = await response.json();
            if (!response.ok || !body.ok) throw new Error(body.error || "Authorization failed");
            const event = {
              type: "ktrlboy-auth-verified",
              provider: "${provider}",
              intent: body.status?.metadata?.installType || "owner",
              status: body.status,
              verifiedAt: new Date().toISOString()
            };
            localStorage.setItem("ktrlboy-auth-event", JSON.stringify(event));
            if (window.opener) window.opener.postMessage(event, window.location.origin);
            message.textContent = "Authorization complete. Returning to KTRLBoy.";
            window.setTimeout(() => {
              if (window.opener) window.close();
              else window.location.href = event.intent === "consumer" ? "/#consumers" : "/#logins";
            }, 1200);
          })
          .catch((error) => {
            message.textContent = error instanceof Error ? error.message : String(error);
          });
      }
    </script>
  </body>
</html>`;
}

function consumerInstallPage(config, consumerStatus) {
  const providers = ["twitch", "youtube", "kick"];
  const rows = providers
    .map((provider) => {
      const oauth = config.oauth?.[provider] || {};
      const label = provider === "youtube" ? "YouTube" : provider.slice(0, 1).toUpperCase() + provider.slice(1);
      const ready = Boolean(oauth.clientId);
      return `
        <article>
          <div>
            <h2>${escapeHtml(label)}</h2>
            <p>${ready ? "Authorize your channel so KTRLBoy can be added to chat." : "This platform needs the app owner to add a Client ID first."}</p>
          </div>
          <a class="${ready ? "" : "disabled"}" href="${ready ? `/auth/${provider}/start?flow=browser&intent=consumer` : "#"}">${ready ? "Add KTRLBoy" : "Not Ready"}</a>
        </article>
      `;
    })
    .join("");

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Add KTRLBoy</title>
    <style>
      body { margin: 0; min-height: 100vh; background: #07090b; color: #f4f5f7; font-family: system-ui, sans-serif; }
      main { width: min(860px, calc(100vw - 32px)); margin: 0 auto; padding: 42px 0; }
      header { margin-bottom: 22px; }
      h1 { margin: 0 0 8px; font-size: clamp(2rem, 4vw, 3.2rem); }
      p { color: #9aa1ab; line-height: 1.5; }
      .grid { display: grid; gap: 12px; }
      article { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 18px; align-items: center; border: 1px solid #2b3038; border-top-color: #7e2027; border-radius: 8px; background: #101318; padding: 18px; box-shadow: 0 18px 48px rgba(0,0,0,.42); }
      h2 { margin: 0 0 6px; font-size: 1.05rem; }
      article p { margin: 0; }
      a { display: inline-flex; min-height: 38px; align-items: center; border: 1px solid #7e2027; border-radius: 6px; background: #261014; color: #ff5960; font-weight: 900; padding: 0 13px; text-decoration: none; }
      a.disabled { opacity: .45; pointer-events: none; }
      .meta { margin-top: 18px; color: #9aa1ab; }
      code { color: #cfd3da; overflow-wrap: anywhere; }
      @media (max-width: 620px) { article { grid-template-columns: 1fr; } }
    </style>
  </head>
  <body>
    <main>
      <header>
        <h1>Add KTRLBoy</h1>
        <p>Authorize your streaming channel in a provider popup. KTRLBoy stores the channel install locally and can use it to join or moderate your chat once the platform adapter is enabled.</p>
      </header>
      <section class="grid">${rows}</section>
      <p class="meta">Installed channels on this machine: <strong>${escapeHtml(String(consumerStatus.count || 0))}</strong>. Owner dashboard: <code>/</code></p>
    </main>
  </body>
</html>`;
}

export function createStatusServer(
  config,
  state,
  logger,
  oauthManager = null,
  commandStore = null,
  router = null,
  moderationStore = null,
  authorizationCatalog = null,
  timerStore = null,
  moduleStore = null,
  consumerStore = null,
) {
  let server;

  function snapshot() {
    const baseUrl = launcherBaseUrl(config);
    const oauthStatus = oauthManager?.status() || {};
    const channelApi = channelApiSnapshot(config, oauthStatus);

    return {
      botName: config.botName,
      ok: state.errors.length === 0,
      uptimeMs: Date.now() - state.startedAt,
      commandPrefix: config.commandPrefix,
      routes: {
        gui: `${baseUrl}/`,
        install: `${baseUrl}/install`,
        health: `${baseUrl}/health`,
        status: `${baseUrl}/status`,
        consumers: `${baseUrl}/api/consumers`,
      },
      requestedPlatforms: config.enabledPlatforms,
      startedPlatforms: state.platforms
        .filter((platform) => platform.status === "started")
        .map((platform) => platform.name),
      platforms: state.platforms,
      oauth: oauthStatus,
      oauthSettings: oauthSettingsSnapshot(config),
      channelApi,
      consumers: consumerStore?.status?.() || { count: 0, installs: [] },
      authorizations: authorizationCatalog?.getCatalog?.() || null,
      commands: {
        builtIn: router?.listBuiltIns?.() || [],
        custom: commandStore?.list?.() || [],
      },
      moderation: moderationStore
        ? {
            settings: moderationStore.getSettings(),
            log: moderationStore.recentLog(),
          }
        : null,
      timers: timerStore
        ? {
            items: timerStore.list(),
          }
        : null,
      modules: moduleStore?.getSettings?.() || null,
      platformConfig: {
        twitch: {
          configured: channelApi.providers.twitch.chatReady,
          accessMode: channelApi.providers.twitch.accessMode,
          missing: missingFields({
            TWITCH_CHANNEL: config.twitch.channel,
            STREAMER_ACCOUNT_LOGIN: oauthStatus.twitch?.connected || config.twitch.oauthToken,
          }),
        },
        youtube: {
          configured: channelApi.providers.youtube.chatReady,
          accessMode: channelApi.providers.youtube.accessMode,
          missing: missingFields({
            STREAMER_ACCOUNT_LOGIN: oauthStatus.youtube?.connected || config.youtube.accessToken,
            YOUTUBE_LIVE_CHAT_ID: config.youtube.liveChatId || oauthStatus.youtube?.metadata?.liveChatId,
          }),
        },
        kick: {
          configured: channelApi.providers.kick.chatReady,
          accessMode: channelApi.providers.kick.accessMode,
          missing: missingFields({
            STREAMER_ACCOUNT_LOGIN: oauthStatus.kick?.connected || config.kick.accessToken,
          }),
        },
      },
      errors: state.errors,
    };
  }

  function start() {
    if (!config.launcherStatus.enabled) return;

    const handleRequest = (req, res) => {
      const url = new URL(req.url, "http://localhost");

      if (oauthManager && url.pathname === "/auth/status" && req.method === "GET") {
        writeJson(res, 200, { ok: true, providers: oauthManager.status() });
        return;
      }

      if (url.pathname === "/install" && req.method === "GET") {
        writeHtml(res, 200, consumerInstallPage(config, consumerStore?.status?.() || { count: 0 }));
        return;
      }

      const consumerMatch = url.pathname.match(/^\/api\/consumers(?:\/(.+))?$/);
      if (consumerStore && consumerMatch) {
        const [, rawId] = consumerMatch;
        if (req.method === "GET") {
          writeJson(res, 200, { ok: true, consumers: consumerStore.status() });
          return;
        }

        if (req.method === "DELETE" && rawId) {
          const removed = consumerStore.remove(decodeURIComponent(rawId));
          writeJson(res, removed ? 200 : 404, { ok: removed });
          return;
        }
      }

      if (authorizationCatalog && url.pathname === "/api/authorizations") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            catalog: authorizationCatalog.getCatalog(),
          });
          return;
        }

        if (req.method === "POST") {
          authorizationCatalog
            .refresh()
            .then((catalog) => writeJson(res, 200, { ok: true, catalog }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (oauthManager && url.pathname === "/api/oauth-settings") {
        if (req.method === "GET") {
          writeJson(res, 200, { ok: true, settings: oauthSettingsSnapshot(config) });
          return;
        }

        if (req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const provider = applyOAuthSettings(config, body);
              writeJson(res, 200, {
                ok: true,
                provider,
                settings: oauthSettingsSnapshot(config),
              });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (oauthManager && url.pathname === "/api/channel-api" && req.method === "GET") {
        writeJson(res, 200, { ok: true, channelApi: snapshot().channelApi });
        return;
      }

      const channelApiMatch = url.pathname.match(
        /^\/api\/channel-api\/(twitch|youtube|kick)\/(sync|refresh|discover-chat)$/,
      );
      if (oauthManager && channelApiMatch && req.method === "POST") {
        const [, provider, action] = channelApiMatch;
        const task =
          action === "sync"
            ? oauthManager.syncProfile(provider)
            : action === "refresh"
              ? oauthManager.refresh(provider)
              : provider === "youtube"
                ? oauthManager.discoverYouTubeLiveChat()
                : Promise.reject(new Error("Chat discovery is only available for YouTube."));

        task
          .then((status) => writeJson(res, 200, { ok: true, status, channelApi: snapshot().channelApi }))
          .catch((error) =>
            writeJson(res, 400, {
              ok: false,
              error: error instanceof Error ? error.message : String(error),
            }),
          );
        return;
      }

      const oauthMatch = url.pathname.match(
        /^\/auth\/(twitch|youtube|kick)\/(start|callback|token|logout|refresh|sync-profile|discover-chat)$/,
      );
      if (oauthManager && oauthMatch) {
        const [, provider, action] = oauthMatch;

        if (action === "start" && req.method === "GET") {
          try {
            res.writeHead(302, {
              Location: oauthManager.start(provider, {
                flow: url.searchParams.get("flow") || "browser",
                intent: url.searchParams.get("intent") || "owner",
              }),
            });
            res.end();
          } catch (error) {
            writeHtml(
              res,
              400,
              oauthResultPage("Login setup needed", error instanceof Error ? error.message : String(error)),
            );
          }
          return;
        }

        if (action === "callback" && req.method === "GET") {
          if (!url.searchParams.get("code") && !url.searchParams.get("error") && provider !== "kick") {
            writeHtml(res, 200, oauthClientTokenPage(provider));
            return;
          }

          oauthManager
            .handleCallback(provider, url.searchParams)
            .then((status) => {
              writeHtml(
                res,
                200,
                oauthResultPage(
                  `${provider} connected`,
                  "Browser verification completed. You can return to the KTRLBoy Integrations menu.",
                  {
                    type: "ktrlboy-auth-verified",
                    provider,
                    status,
                    intent: status.metadata?.installType || "owner",
                    verifiedAt: new Date().toISOString(),
                  },
                ),
              );
            })
            .catch((error) => {
              writeHtml(
                res,
                400,
                oauthResultPage(
                  `${provider} login failed`,
                  error instanceof Error ? error.message : String(error),
                ),
              );
            });
          return;
        }

        if (action === "token" && req.method === "POST") {
          readJsonBody(req)
            .then((body) => oauthManager.saveClientToken(provider, body))
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (action === "logout" && req.method === "POST") {
          oauthManager.clear(provider);
          writeJson(res, 200, { ok: true, providers: oauthManager.status() });
          return;
        }

        if (action === "refresh" && req.method === "POST") {
          oauthManager
            .refresh(provider)
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (action === "sync-profile" && req.method === "POST") {
          oauthManager
            .syncProfile(provider)
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (action === "discover-chat" && provider === "youtube" && req.method === "POST") {
          oauthManager
            .discoverYouTubeLiveChat()
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (oauthManager && url.pathname === "/auth/sync-profiles" && req.method === "POST") {
        oauthManager
          .syncProfiles()
          .then((providers) => writeJson(res, 200, { ok: true, providers }))
          .catch((error) =>
            writeJson(res, 400, {
              ok: false,
              error: error instanceof Error ? error.message : String(error),
            }),
          );
        return;
      }

      const commandMatch = url.pathname.match(/^\/api\/commands(?:\/([a-z0-9_-]+))?$/i);
      if (commandStore && commandMatch) {
        const [, commandName] = commandMatch;

        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            builtIn: router?.listBuiltIns?.() || [],
            custom: commandStore.list(),
          });
          return;
        }

        if (req.method === "POST" || req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const command = commandStore.upsert({
                ...body,
                name: commandName || body.name,
              });
              writeJson(res, commandName ? 200 : 201, { ok: true, command });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (req.method === "DELETE" && commandName) {
          const removed = commandStore.remove(commandName);
          writeJson(res, removed ? 200 : 404, { ok: removed });
          return;
        }
      }

      if (moderationStore && url.pathname === "/api/moderation") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            settings: moderationStore.getSettings(),
            log: moderationStore.recentLog(),
          });
          return;
        }

        if (req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const settings = moderationStore.updateSettings(body);
              writeJson(res, 200, { ok: true, settings });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      const timerMatch = url.pathname.match(/^\/api\/timers(?:\/([a-z0-9_-]+))?$/i);
      if (timerStore && timerMatch) {
        const [, timerName] = timerMatch;

        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            timers: timerStore.list(),
          });
          return;
        }

        if (req.method === "POST" || req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const timer = timerStore.upsert({
                ...body,
                name: timerName || body.name,
              });
              writeJson(res, timerName ? 200 : 201, { ok: true, timer });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (req.method === "DELETE" && timerName) {
          const removed = timerStore.remove(timerName);
          writeJson(res, removed ? 200 : 404, { ok: removed });
          return;
        }
      }

      if (moduleStore && url.pathname === "/api/modules") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            modules: moduleStore.getSettings(),
          });
          return;
        }

        if (req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const modules = moduleStore.updateSettings(body.modules || body);
              writeJson(res, 200, { ok: true, modules });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (tryServeGui(req, res)) return;

      if (req.method === "GET" && req.url === "/health") {
        writeJson(res, state.errors.length === 0 ? 200 : 500, {
          ok: state.errors.length === 0,
          botName: config.botName,
        });
        return;
      }

      if (req.method === "GET" && req.url === "/status") {
        writeJson(res, state.errors.length === 0 ? 200 : 500, snapshot());
        return;
      }

      writeJson(res, 404, { ok: false, error: "Not found" });
    };

    server = config.launcherStatus.https?.enabled
      ? https.createServer(httpsOptions(config), handleRequest)
      : http.createServer(handleRequest);

    server.listen(config.launcherStatus.port, config.launcherStatus.host, () => {
      logger.info(
        `[launcher] status listening on ${launcherBaseUrl(config)}`,
      );
    });
  }

  return {
    start,
    stop: () => server?.close(),
    snapshot,
  };
}
