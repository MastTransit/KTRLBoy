import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".data");
const storePath = path.join(storeDir, "timers.json");
const timerNamePattern = /^[a-z0-9][a-z0-9_-]{0,31}$/;

function readStore() {
  if (!fs.existsSync(storePath)) return { timers: [] };

  try {
    const data = JSON.parse(fs.readFileSync(storePath, "utf8"));
    return {
      timers: Array.isArray(data.timers) ? data.timers : [],
    };
  } catch {
    return { timers: [] };
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function positiveNumber(value, fallback, min = 1, max = Number.MAX_SAFE_INTEGER) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, Math.round(number)));
}

function normalizeMessages(input) {
  const values = Array.isArray(input)
    ? input
    : String(input || "")
        .split(/\r?\n/)
        .map((line) => line.trim());

  const messages = values.map((message) => String(message).trim()).filter(Boolean);
  if (messages.length === 0) {
    throw new Error("Timer message is required.");
  }

  if (messages.some((message) => message.length > 400)) {
    throw new Error("Timer messages must be 400 characters or less.");
  }

  return messages.slice(0, 10);
}

function normalizeTimer(input) {
  const name = String(input.name || "")
    .trim()
    .replace(/^!+/, "")
    .toLowerCase();

  if (!timerNamePattern.test(name)) {
    throw new Error("Timer names must be 1-32 characters: lowercase letters, numbers, dashes, or underscores.");
  }

  const messages = normalizeMessages(input.messages || input.message || input.response);

  return {
    name,
    messages,
    enabled: input.enabled !== false,
    intervalMinutes: positiveNumber(input.intervalMinutes, 15, 1, 1440),
    chatLines: positiveNumber(input.chatLines, 5, 1, 10000),
    updatedAt: new Date().toISOString(),
  };
}

export function createTimerStore() {
  function list() {
    return readStore().timers.sort((a, b) => a.name.localeCompare(b.name));
  }

  function get(name) {
    const normalized = String(name || "").trim().replace(/^!+/, "").toLowerCase();
    return list().find((timer) => timer.name === normalized) || null;
  }

  function upsert(input) {
    const timer = normalizeTimer(input);
    const data = readStore();
    const existing = data.timers.findIndex((item) => item.name === timer.name);

    if (existing === -1) {
      data.timers.push({
        ...timer,
        createdAt: timer.updatedAt,
      });
    } else {
      data.timers[existing] = {
        ...data.timers[existing],
        ...timer,
      };
    }

    writeStore(data);
    return get(timer.name);
  }

  function remove(name) {
    const normalized = String(name || "").trim().replace(/^!+/, "").toLowerCase();
    const data = readStore();
    const next = data.timers.filter((timer) => timer.name !== normalized);
    const removed = next.length !== data.timers.length;
    writeStore({ timers: next });
    return removed;
  }

  return {
    get,
    list,
    remove,
    upsert,
  };
}
