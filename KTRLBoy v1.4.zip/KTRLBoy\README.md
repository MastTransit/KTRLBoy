# KTRLBoy Chat Bot

Current release: `Alpha 1.3` (`1.3.0-alpha`)

A small custom chatbot starter for Twitch, YouTube Live, and Kick. It keeps the local bot identity as KTRLBoy and uses streamer/platform account OAuth logins for chat/API access, with plain Node.js so the first run is simple and each platform adapter can be expanded as your stream setup grows.

## What It Does

- Responds to `!ping`, `!hello`, `!uptime`, and `!help`
- Connects to Twitch chat over IRC for a quick local bot
- Polls YouTube Live Chat through the YouTube Live Streaming API
- Accepts Kick chat events by webhook and sends Kick chat messages through Kick's official chat API
- Keeps shared command logic in one place so commands work the same across platforms
- Provides a StreamElements-inspired local dashboard with Integrations, Channel API, Commands, Timers, Spam Filters, and Modules
- Connects chat through streamer account authorization popups and uses that token before any manual fallback token
- Provides a consumer-facing install page so streamers can add KTRLBoy to their own chat through provider popups
- Lets moderators manage custom commands from chat with `!cmd`
- Lets moderators toggle major modules from chat with `!module`
- Sends timer messages at configured intervals after enough chat activity
- Applies local spam filters for blocked terms, links, caps, repeated characters, and message spam

## Quick Start

1. Copy `.env.example` to `.env`.
2. Fill in the platform credentials you want to use.
3. Set `ENABLED_PLATFORMS`, for example:

```env
ENABLED_PLATFORMS=twitch,youtube,kick
```

4. Run:

```powershell
npm.cmd run check
npm.cmd start
```

To smoke test KTRLBoy locally before integrating it with another launcher:

```powershell
npm.cmd run test:local
```

To open the local GUI menu:

```powershell
npm.cmd run gui
```

Then visit `http://localhost:8790/`.

To serve the GUI, install page, launcher API, and OAuth callbacks over HTTPS, see [docs/https-access.md](docs/https-access.md).

For Twitch, YouTube, and Kick account login setup, including how to make the visible chat sender show as KTRLBoy, see [docs/login-integration.md](docs/login-integration.md).

To connect and inspect streamer channel API access from the GUI or local launcher API, see [docs/channel-api.md](docs/channel-api.md).

To let consumers add KTRLBoy to their own Twitch, YouTube, or Kick chat, see [docs/consumer-install.md](docs/consumer-install.md).

To refresh and store provider authorization links, see [docs/authorization-links.md](docs/authorization-links.md).

To add or edit chat commands from the GUI, see [docs/command-editor.md](docs/command-editor.md).

To schedule recurring chat messages, see [docs/timers.md](docs/timers.md).

To enable spam filter moderation rules, see [docs/moderation.md](docs/moderation.md).

To turn bot areas on or off from the dashboard or chat, see [docs/modules.md](docs/modules.md).

To test KTRLBoy as a Windows executable, see [docs/executable-test.md](docs/executable-test.md).

## KTRL Native Service

Alpha 1.3 adds the KTRL-native service foundation from the v1.3 update package. KTRL consumes it from:

```text
companion/ktrlboy
```

The native service is served by KTRL at `/KTRLboy`, exposes APIs under `/api/ktrlboy`, and keeps its independent update manifest at [releases/ktrlboy-latest.json](releases/ktrlboy-latest.json). Start with [companion/ktrlboy/docs/developer-handoff.md](companion/ktrlboy/docs/developer-handoff.md) for the v1.3 architecture and route list.

## Run Beside Another GitHub Project

KTRLBoy can run as a sidecar next to a project you collaborate on. The safest default is to keep the bot in its own folder beside that repo:

```text
projects/
  collaborator-project/
  ktrlboy-chat-bot/
```

For Docker or submodule setups, see [docs/github-sidecar.md](docs/github-sidecar.md).

If the GitHub project is a launcher, use [docs/launcher-integration.md](docs/launcher-integration.md) for the start command and local health/status API.

## Platform Notes

### Twitch

This starter uses Twitch IRC because it is the fastest way to get a local custom bot online. KTRLBoy can use the account token saved from the Integrations login flow as the IRC chat token.

Manual fallback environment:

```env
TWITCH_CHANNEL=your_channel_name
TWITCH_BOT_USERNAME=your_bot_username
TWITCH_OAUTH_TOKEN=oauth:...
```

The preferred setup is to connect a Twitch account from `Integrations`; that stored streamer account token wins over `TWITCH_OAUTH_TOKEN`. Manual fallback tokens need chat read/write permissions, commonly `chat:read` and `chat:edit`.

### YouTube

YouTube Live Chat requires a connected streamer account and the active `liveChatId` for the current broadcast. The bot polls `liveChatMessages.list` and posts replies with `liveChatMessages.insert`.

Manual fallback environment:

```env
YOUTUBE_ACCESS_TOKEN=...
YOUTUBE_LIVE_CHAT_ID=...
```

### Kick

Kick has official OAuth, chat API, and webhook docs. This starter receives chat events at:

```text
POST /kick/webhook
```

Run the bot locally, expose the webhook with a tunnel such as Cloudflare Tunnel or ngrok, then subscribe Kick events to your public URL.

Manual fallback environment:

```env
KICK_ACCESS_TOKEN=...
KICK_SEND_AS=bot
KICK_WEBHOOK_PORT=8787
```

If sending as `user`, also set:

```env
KICK_BROADCASTER_USER_ID=123
```

## Adding Commands

Edit `src/core/commandRouter.js`. Each command receives:

```js
{
  platform,
  channel,
  user,
  text,
  raw,
  reply
}
```

Add a new command in the `commands` map:

```js
shoutout: async (ctx, args) => {
  const name = args[0]?.replace(/^@/, "");
  if (!name) return ctx.reply("Usage: !shoutout @name");
  return ctx.reply(`Go check out @${name}!`);
}
```

## Useful Official Docs

- Twitch Chat & Chatbots: https://dev.twitch.tv/docs/chat
- YouTube Live Chat Messages: https://developers.google.com/youtube/v3/live/docs/liveChatMessages
- Kick Chat API: https://docs.kick.com/apis/chat
