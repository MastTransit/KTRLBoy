﻿# KTRLboy API Smoke Tests

Run these from the KTRL root while KTRL is running.

## Status

Invoke-RestMethod "http://localhost:3000/api/ktrlboy/status" | ConvertTo-Json -Depth 10

## Commands

$CommandPayload = @{
    items = @(
        @{
            name = "test"
            trigger = "!test"
            response = "KTRLboy test command works."
            enabled = $true
        }
    )
} | ConvertTo-Json -Depth 8

Invoke-RestMethod `
    -Method Put `
    -Uri "http://localhost:3000/api/ktrlboy/commands" `
    -ContentType "application/json" `
    -Body $CommandPayload | ConvertTo-Json -Depth 8

## Local message pipeline

$MessagePayload = @{
    platform = "local"
    user = "Kody"
    message = "!test"
} | ConvertTo-Json -Depth 8

Invoke-RestMethod `
    -Method Post `
    -Uri "http://localhost:3000/api/ktrlboy/test-message" `
    -ContentType "application/json" `
    -Body $MessagePayload | ConvertTo-Json -Depth 10

## Twitch adapter stub

Invoke-RestMethod `
    -Method Post `
    -Uri "http://localhost:3000/api/ktrlboy/adapters/twitch/start" | ConvertTo-Json -Depth 10

$AdapterMessagePayload = @{
    user = "Kody"
    message = "!test"
} | ConvertTo-Json -Depth 8

Invoke-RestMethod `
    -Method Post `
    -Uri "http://localhost:3000/api/ktrlboy/adapters/twitch/test-message" `
    -ContentType "application/json" `
    -Body $AdapterMessagePayload | ConvertTo-Json -Depth 10

Invoke-RestMethod `
    -Method Post `
    -Uri "http://localhost:3000/api/ktrlboy/adapters/twitch/stop" | ConvertTo-Json -Depth 10

## Token redaction

Invoke-RestMethod "http://localhost:3000/api/ktrlboy/tokens" | ConvertTo-Json -Depth 10

Raw token values should never appear in API responses.
