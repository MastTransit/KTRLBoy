﻿const {
  readStore
} = require("./stores");

function normalizeCommand(command) {
  return {
    name: command.name || command.trigger || "",
    trigger: command.trigger || command.name || "",
    response: command.response || "",
    enabled: command.enabled !== false,
    aliases: Array.isArray(command.aliases) ? command.aliases : []
  };
}

function getCommandItems() {
  const store = readStore("commands");
  const items = Array.isArray(store.items) ? store.items : [];

  return items.map(normalizeCommand);
}

function normalizeMessage(message) {
  return String(message || "").trim();
}

function findCommand(message) {
  const text = normalizeMessage(message);

  if (!text) {
    return null;
  }

  const commands = getCommandItems();

  return commands.find((command) => {
    if (!command.enabled) {
      return false;
    }

    const trigger = normalizeMessage(command.trigger);

    if (trigger && text.toLowerCase() === trigger.toLowerCase()) {
      return true;
    }

    return command.aliases.some((alias) => {
      const normalizedAlias = normalizeMessage(alias);
      return normalizedAlias && text.toLowerCase() === normalizedAlias.toLowerCase();
    });
  }) || null;
}

function routeMessage(input) {
  const message = typeof input === "string" ? input : input?.message;
  const platform = typeof input === "object" ? input.platform || "local" : "local";
  const user = typeof input === "object" ? input.user || "local-user" : "local-user";

  const normalizedMessage = normalizeMessage(message);
  const command = findCommand(normalizedMessage);

  if (!command) {
    return {
      matched: false,
      platform,
      user,
      message: normalizedMessage,
      response: null
    };
  }

  return {
    matched: true,
    platform,
    user,
    message: normalizedMessage,
    command: {
      name: command.name,
      trigger: command.trigger
    },
    response: command.response
  };
}

module.exports = {
  normalizeCommand,
  getCommandItems,
  findCommand,
  routeMessage
};
