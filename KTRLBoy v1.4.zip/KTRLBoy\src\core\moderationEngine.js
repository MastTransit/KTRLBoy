const urlPattern = /\b(?:https?:\/\/|www\.)\S+/i;

function roleSet(ctx) {
  const roles = new Set();
  const badges = String(ctx.user?.badges || "").toLowerCase();

  if (ctx.user?.isOwner) roles.add("owner");
  if (ctx.user?.isModerator) roles.add("moderator");
  if (badges.includes("broadcaster/")) roles.add("broadcaster");
  if (badges.includes("moderator/")) roles.add("moderator");
  if (badges.includes("vip/")) roles.add("vip");

  return roles;
}

function shouldIgnore(ctx, settings) {
  const roles = roleSet(ctx);
  return settings.ignoredRoles.some((role) => roles.has(role));
}

function capsPercent(text) {
  const letters = [...text].filter((char) => /[a-z]/i.test(char));
  if (letters.length === 0) return 0;
  const uppercase = letters.filter((char) => char === char.toUpperCase()).length;
  return Math.round((uppercase / letters.length) * 100);
}

function repeatedCharPattern(maxRepeatedChars) {
  return new RegExp(`(.)\\1{${maxRepeatedChars},}`, "i");
}

function userKey(ctx) {
  return `${ctx.platform}:${ctx.user?.id || ctx.user?.name || "unknown"}`;
}

function renderWarning(ctx, reasons) {
  const name = ctx.user?.displayName || ctx.user?.name || "there";
  return `${name}, KTRLBoy moderation flagged that message: ${reasons.join(", ")}.`;
}

export function createModerationEngine(moderationStore, logger, moduleStore = null) {
  const messageHistory = new Map();
  const violationCounts = new Map();

  function evaluate(ctx, settings) {
    const text = String(ctx.text || "");
    const normalizedText = text.toLowerCase();
    const reasons = [];

    const blockedTerm = settings.blockedTerms.find((term) =>
      normalizedText.includes(term.toLowerCase()),
    );
    if (blockedTerm) reasons.push(`blocked term "${blockedTerm}"`);

    if (!settings.allowLinks && urlPattern.test(text)) {
      reasons.push("link");
    }

    const letterCount = [...text].filter((char) => /[a-z]/i.test(char)).length;
    if (
      letterCount >= settings.minCapsLength &&
      capsPercent(text) >= settings.maxCapsPercent
    ) {
      reasons.push("excessive caps");
    }

    if (repeatedCharPattern(settings.maxRepeatedChars).test(text)) {
      reasons.push("repeated characters");
    }

    const key = userKey(ctx);
    const now = Date.now();
    const windowMs = settings.spamWindowSeconds * 1000;
    const recent = (messageHistory.get(key) || []).filter((timestamp) => now - timestamp < windowMs);
    recent.push(now);
    messageHistory.set(key, recent);

    if (recent.length > settings.maxMessagesPerWindow) {
      reasons.push("message spam");
    }

    return reasons;
  }

  async function applyAction(ctx, settings, reasons) {
    const key = userKey(ctx);
    const count = (violationCounts.get(key) || 0) + 1;
    violationCounts.set(key, count);

    const logBase = {
      platform: ctx.platform,
      channel: ctx.channel,
      user: ctx.user?.displayName || ctx.user?.name || "unknown",
      userId: ctx.user?.id || "",
      messageId: ctx.messageId || "",
      text: String(ctx.text || "").slice(0, 500),
      reasons,
      action: settings.action,
      dryRun: settings.dryRun,
      violationCount: count,
    };

    if (settings.dryRun) {
      moderationStore.appendLog({
        ...logBase,
        result: "dry-run",
      });
      logger.info(`[moderation] dry-run ${ctx.platform}: ${reasons.join(", ")}`);
      return false;
    }

    if (settings.warnBeforeAction || settings.action === "warn") {
      await ctx.reply?.(renderWarning(ctx, reasons));
    }

    let result = "warned";
    if (settings.action === "delete" || settings.action === "timeout" || settings.action === "ban") {
      try {
        await ctx.moderationActions?.deleteMessage?.(ctx, reasons);
        result = "deleted";
      } catch (error) {
        result = `delete failed: ${error instanceof Error ? error.message : String(error)}`;
        logger.warn("[moderation] delete failed", result);
      }
    }

    if (settings.action === "timeout" && count >= settings.timeoutAfterViolations) {
      try {
        await ctx.moderationActions?.timeoutUser?.(ctx, settings.timeoutSeconds, reasons);
        result = `timed out ${settings.timeoutSeconds}s`;
      } catch (error) {
        result = `timeout failed: ${error instanceof Error ? error.message : String(error)}`;
        logger.warn("[moderation] timeout failed", result);
      }
    }

    if (settings.action === "ban" && count >= settings.timeoutAfterViolations) {
      try {
        await ctx.moderationActions?.banUser?.(ctx, reasons);
        result = "banned";
      } catch (error) {
        result = `ban failed: ${error instanceof Error ? error.message : String(error)}`;
        logger.warn("[moderation] ban failed", result);
      }
    }

    moderationStore.appendLog({
      ...logBase,
      result,
    });
    return true;
  }

  async function handleMessage(ctx) {
    if (moduleStore?.isEnabled?.("spamFilters") === false) return false;

    const settings = moderationStore.getSettings();
    if (!settings.enabled || shouldIgnore(ctx, settings)) return false;

    const reasons = evaluate(ctx, settings);
    if (reasons.length === 0) return false;

    return applyAction(ctx, settings, reasons);
  }

  return {
    handleMessage,
    evaluate,
  };
}
