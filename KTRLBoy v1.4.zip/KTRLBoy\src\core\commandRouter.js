const startedAt = Date.now();
export const builtInCommandDescriptions = {
  ping: "Replies with pong.",
  hello: "Greets the viewer.",
  uptime: "Shows bot runtime.",
  help: "Lists chat commands.",
  cmd: "Moderator command manager.",
  module: "Moderator module toggle.",
};

function formatDuration(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}

function renderTemplate(template, ctx, args) {
  const values = {
    args: args.join(" "),
    bot: ctx.botName,
    channel: ctx.channel || "",
    platform: ctx.platform || "",
    prefix: ctx.commandPrefix,
    user: ctx.user?.displayName || ctx.user?.name || "there",
  };

  return template.replace(/\{([a-zA-Z0-9_]+)\}/g, (match, key) => {
    if (key.startsWith("arg")) {
      const position = Number(key.slice(3)) - 1;
      return Number.isInteger(position) && position >= 0 ? args[position] || "" : match;
    }

    return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : match;
  });
}

function hasBadge(ctx, names) {
  const badges = String(ctx.user?.badges || "").toLowerCase();
  return names.some((name) => badges.includes(`${name.toLowerCase()}/`));
}

function hasModeratorPermission(ctx) {
  const roles = Array.isArray(ctx.user?.roles)
    ? ctx.user.roles.map((role) => String(role).toLowerCase())
    : [];

  return Boolean(
    ctx.user?.isOwner ||
      ctx.user?.isModerator ||
      ctx.user?.isBroadcaster ||
      roles.includes("owner") ||
      roles.includes("moderator") ||
      roles.includes("broadcaster") ||
      hasBadge(ctx, ["broadcaster", "moderator"]),
  );
}

function commandManagerUsage(commandPrefix) {
  return `Mod commands: ${commandPrefix}cmd add name response, ${commandPrefix}cmd edit name response, ${commandPrefix}cmd delete name, ${commandPrefix}cmd enable name, ${commandPrefix}cmd disable name`;
}

function moduleUsage(commandPrefix) {
  return `Module commands: ${commandPrefix}module list, ${commandPrefix}module name enable, ${commandPrefix}module name disable`;
}

function moduleKeyByName(moduleStore, name) {
  const normalized = String(name || "").trim().toLowerCase();
  const settings = moduleStore?.getSettings?.() || {};
  return (
    Object.keys(settings).find(
      (key) =>
        key.toLowerCase() === normalized ||
        settings[key].label?.toLowerCase() === normalized ||
        settings[key].label?.toLowerCase().replace(/\s+/g, "") === normalized,
    ) || ""
  );
}

export function createCommandRouter({
  commandPrefix,
  botName,
  commandStore,
  moderationEngine,
  timerEngine,
  moduleStore,
}) {
  function moduleEnabled(name) {
    return moduleStore?.isEnabled?.(name) !== false;
  }

  const commands = {
    ping: async (ctx) => ctx.reply("pong"),

    hello: async (ctx) => {
      const name = ctx.user?.displayName || ctx.user?.name || "there";
      return ctx.reply(`Hey ${name}, ${botName} is online.`);
    },

    uptime: async (ctx) => {
      return ctx.reply(`${botName} has been running for ${formatDuration(Date.now() - startedAt)}.`);
    },

    help: async (ctx) => {
      const customCommands = commandStore
        ? moduleEnabled("commands")
          ? commandStore
            .list()
            .filter((command) => command.enabled)
            .map((command) => `${commandPrefix}${command.name}`)
          : []
        : [];
      const names = [
        `${commandPrefix}ping`,
        `${commandPrefix}hello`,
        `${commandPrefix}uptime`,
        ...(moduleEnabled("modCommandManager") ? [`${commandPrefix}cmd`] : []),
        `${commandPrefix}module`,
        ...customCommands,
      ];
      return ctx.reply(`Commands: ${names.join(", ")}`);
    },

    cmd: async (ctx, args) => {
      if (!commandStore) return ctx.reply("Command editing is not available.");
      if (!moduleEnabled("modCommandManager")) {
        return ctx.reply("Moderator command editing is disabled in KTRLBoy Modules.");
      }
      if (!hasModeratorPermission(ctx)) {
        return ctx.reply("Only chat moderators can manage commands.");
      }

      const [action, rawName, ...responseParts] = args;
      const name = String(rawName || "").replace(/^!+/, "").toLowerCase();
      const response = responseParts.join(" ").trim();

      try {
        if (!action || action === "help") {
          return ctx.reply(commandManagerUsage(commandPrefix));
        }

        if (action === "add" || action === "edit" || action === "set") {
          if (!name || !response) return ctx.reply(commandManagerUsage(commandPrefix));
          const existing = commandStore.get(name);
          const command = commandStore.upsert({
            name,
            response,
            enabled: existing?.enabled !== false,
          });
          return ctx.reply(`${commandPrefix}${command.name} ${existing ? "updated" : "added"}.`);
        }

        if (action === "delete" || action === "remove") {
          if (!name) return ctx.reply(commandManagerUsage(commandPrefix));
          const removed = commandStore.remove(name);
          return ctx.reply(removed ? `${commandPrefix}${name} deleted.` : `${commandPrefix}${name} was not found.`);
        }

        if (action === "enable" || action === "disable") {
          if (!name) return ctx.reply(commandManagerUsage(commandPrefix));
          const existing = commandStore.get(name);
          if (!existing) return ctx.reply(`${commandPrefix}${name} was not found.`);

          const command = commandStore.upsert({
            ...existing,
            enabled: action === "enable",
          });
          return ctx.reply(`${commandPrefix}${command.name} ${command.enabled ? "enabled" : "disabled"}.`);
        }

        if (action === "list") {
          const customCommands = commandStore
            .list()
            .map((command) => `${commandPrefix}${command.name}${command.enabled ? "" : " (off)"}`);
          return ctx.reply(customCommands.length ? `Custom commands: ${customCommands.join(", ")}` : "No custom commands yet.");
        }

        return ctx.reply(commandManagerUsage(commandPrefix));
      } catch (error) {
        return ctx.reply(`Command update failed: ${error instanceof Error ? error.message : String(error)}`);
      }
    },

    module: async (ctx, args) => {
      if (!moduleStore) return ctx.reply("Module controls are not available.");
      if (!hasModeratorPermission(ctx)) {
        return ctx.reply("Only chat moderators can manage modules.");
      }

      const [rawName, rawAction] = args;
      const settings = moduleStore.getSettings();

      if (!rawName || rawName === "help" || rawName === "list") {
        const moduleList = Object.entries(settings).map(
          ([key, module]) => `${key}:${module.enabled ? "on" : "off"}`,
        );
        return ctx.reply(`${moduleUsage(commandPrefix)}. Current: ${moduleList.join(", ")}`);
      }

      const key = moduleKeyByName(moduleStore, rawName);
      const action = String(rawAction || "").toLowerCase();
      if (!key || !["enable", "disable", "on", "off"].includes(action)) {
        return ctx.reply(moduleUsage(commandPrefix));
      }

      const next = moduleStore.updateSettings({
        [key]: {
          enabled: action === "enable" || action === "on",
        },
      });
      return ctx.reply(`${next[key].label} ${next[key].enabled ? "enabled" : "disabled"}.`);
    },
  };

  async function handleMessage(ctx) {
    timerEngine?.recordMessage?.(ctx);
    if (await moderationEngine?.handleMessage(ctx)) return true;

    const text = String(ctx.text || "").trim();
    if (!text.startsWith(commandPrefix)) return false;

    const [commandName, ...args] = text.slice(commandPrefix.length).trim().split(/\s+/);
    const normalizedName = commandName.toLowerCase();
    const command = commands[normalizedName];
    if (command) {
      await command(ctx, args);
      return true;
    }

    if (!moduleEnabled("commands")) return false;

    const customCommand = commandStore?.get(normalizedName);
    if (!customCommand || !customCommand.enabled) return false;

    await ctx.reply(
      renderTemplate(
        customCommand.response,
        {
          ...ctx,
          botName,
          commandPrefix,
        },
        args,
      ),
    );
    return true;
  }

  function listBuiltIns() {
    return Object.entries(builtInCommandDescriptions).map(([name, description]) => ({
      name,
      description,
      enabled:
        name === "cmd"
          ? moduleEnabled("modCommandManager")
          : true,
      builtIn: true,
      response: "",
    }));
  }

  return {
    handleMessage,
    commands,
    listBuiltIns,
  };
}
