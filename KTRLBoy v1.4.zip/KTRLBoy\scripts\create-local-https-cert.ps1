param(
  [string]$OutputDirectory = ".certs",
  [string]$Hostname = "localhost",
  [int]$Days = 365,
  [string]$PfxPassword = "ktrlboy-local"
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$certDir = if ([System.IO.Path]::IsPathRooted($OutputDirectory)) {
  $OutputDirectory
} else {
  Join-Path $root $OutputDirectory
}

New-Item -ItemType Directory -Force -Path $certDir | Out-Null

$certPath = Join-Path $certDir "ktrlboy-localhost.crt"
$pfxPath = Join-Path $certDir "ktrlboy-localhost.pfx"

$rsa = [System.Security.Cryptography.RSA]::Create(2048)
$subject = [System.Security.Cryptography.X509Certificates.X500DistinguishedName]::new("CN=$Hostname")
$request = [System.Security.Cryptography.X509Certificates.CertificateRequest]::new(
  $subject,
  $rsa,
  [System.Security.Cryptography.HashAlgorithmName]::SHA256,
  [System.Security.Cryptography.RSASignaturePadding]::Pkcs1
)

$san = [System.Security.Cryptography.X509Certificates.SubjectAlternativeNameBuilder]::new()
$san.AddDnsName($Hostname)
if ($Hostname -eq "localhost") {
  $san.AddIPAddress([System.Net.IPAddress]::Parse("127.0.0.1"))
}

$request.CertificateExtensions.Add($san.Build())
$request.CertificateExtensions.Add(
  [System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension]::new($false, $false, 0, $false)
)
$request.CertificateExtensions.Add(
  [System.Security.Cryptography.X509Certificates.X509KeyUsageExtension]::new(
    [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]::DigitalSignature -bor
      [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]::KeyEncipherment,
    $false
  )
)

$serverAuth = [System.Security.Cryptography.Oid]::new("1.3.6.1.5.5.7.3.1")
$eku = [System.Security.Cryptography.OidCollection]::new()
[void]$eku.Add($serverAuth)
$request.CertificateExtensions.Add(
  [System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension]::new($eku, $false)
)

$cert = $request.CreateSelfSigned([DateTimeOffset]::Now.AddDays(-1), [DateTimeOffset]::Now.AddDays($Days))

function ConvertTo-Pem([string]$Label, [byte[]]$Bytes) {
  $base64 = [Convert]::ToBase64String($Bytes)
  $lines = for ($index = 0; $index -lt $base64.Length; $index += 64) {
    $base64.Substring($index, [Math]::Min(64, $base64.Length - $index))
  }
  "-----BEGIN $Label-----`n$($lines -join "`n")`n-----END $Label-----`n"
}

[System.IO.File]::WriteAllText($certPath, (ConvertTo-Pem "CERTIFICATE" $cert.RawData))
[System.IO.File]::WriteAllBytes(
  $pfxPath,
  $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pfx, $PfxPassword)
)

[pscustomobject]@{
  CertPath = $certPath
  PfxPath = $pfxPath
  PfxPassphrase = $PfxPassword
  Hostname = $Hostname
  Days = $Days
} | Format-List
