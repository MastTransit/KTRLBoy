$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$node = "node"
$statusPort = "8790"
$envPath = Join-Path $root ".env"
$hadEnv = Test-Path $envPath
$envBackup = if ($hadEnv) { Get-Content -LiteralPath $envPath -Raw } else { $null }

$startInfo = [System.Diagnostics.ProcessStartInfo]::new()
$startInfo.FileName = $node
$startInfo.Arguments = "src/index.js"
$startInfo.WorkingDirectory = $root.Path
$startInfo.UseShellExecute = $false
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true
$startInfo.CreateNoWindow = $true
$startInfo.Environment["BOT_NAME"] = "KTRLBoy"
$startInfo.Environment["ENABLED_PLATFORMS"] = ""
$startInfo.Environment["LAUNCHER_STATUS_ENABLED"] = "true"
$startInfo.Environment["LAUNCHER_STATUS_HOST"] = "127.0.0.1"
$startInfo.Environment["LAUNCHER_STATUS_PORT"] = $statusPort

$process = [System.Diagnostics.Process]::Start($startInfo)

try {
  $healthUrl = "http://127.0.0.1:$statusPort/health"
  $statusUrl = "http://127.0.0.1:$statusPort/status"
  $guiUrl = "http://127.0.0.1:$statusPort/"
  $cssUrl = "http://127.0.0.1:$statusPort/gui/styles.css"
  $jsUrl = "http://127.0.0.1:$statusPort/gui/app.js"
  $authStatusUrl = "http://127.0.0.1:$statusPort/auth/status"
  $commandsUrl = "http://127.0.0.1:$statusPort/api/commands"
  $timersUrl = "http://127.0.0.1:$statusPort/api/timers"
  $moderationUrl = "http://127.0.0.1:$statusPort/api/moderation"
  $modulesUrl = "http://127.0.0.1:$statusPort/api/modules"
  $authorizationsUrl = "http://127.0.0.1:$statusPort/api/authorizations"
  $channelApiUrl = "http://127.0.0.1:$statusPort/api/channel-api"
  $oauthSettingsUrl = "http://127.0.0.1:$statusPort/api/oauth-settings"
  $consumersUrl = "http://127.0.0.1:$statusPort/api/consumers"
  $installUrl = "http://127.0.0.1:$statusPort/install"
  $healthy = $false

  for ($attempt = 0; $attempt -lt 20; $attempt++) {
    try {
      $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
      if ($health.ok -eq $true -and $health.botName -eq "KTRLBoy") {
        $healthy = $true
        break
      }
    } catch {
      Start-Sleep -Milliseconds 250
    }
  }

  if (-not $healthy) {
    throw "KTRLBoy did not become healthy at $healthUrl"
  }

  $status = Invoke-RestMethod -Uri $statusUrl -TimeoutSec 2
  $gui = Invoke-WebRequest -Uri $guiUrl -UseBasicParsing -TimeoutSec 2
  $css = Invoke-WebRequest -Uri $cssUrl -UseBasicParsing -TimeoutSec 2
  $js = Invoke-WebRequest -Uri $jsUrl -UseBasicParsing -TimeoutSec 2

  if ($gui.StatusCode -ne 200 -or $gui.Content -notmatch "KTRLBoy Dashboard" -or $gui.Content -notmatch "Connections" -or $gui.Content -notmatch "Consumer Login" -or $gui.Content -notmatch "Channel API" -or $gui.Content -notmatch "Timers" -or $gui.Content -notmatch "Modules" -or $gui.Content -notmatch "auth-refresh-button" -or $gui.Content -notmatch "oauth-setup-list" -or $gui.Content -notmatch "consumer-list" -or $gui.Content -notmatch "/install" -or $gui.Content -notmatch "channel-api-list" -or $gui.Content -notmatch "command-form" -or $gui.Content -notmatch "timer-form" -or $gui.Content -notmatch "moderation-form" -or $gui.Content -notmatch "module-list" -or $gui.Content -notmatch "data-insert-token" -or $gui.Content -notmatch "data-timer-token" -or $gui.Content -notmatch "data-mod-action") {
    throw "KTRLBoy GUI did not render at $guiUrl"
  }

  if ($css.StatusCode -ne 200 -or $css.Headers["Content-Type"] -notmatch "text/css") {
    throw "KTRLBoy GUI CSS did not load"
  }

  if ($js.StatusCode -ne 200 -or $js.Headers["Content-Type"] -notmatch "text/javascript") {
    throw "KTRLBoy GUI JavaScript did not load"
  }

  if ($js.Content -notmatch "ktrlboy-auth-verified" -or $js.Content -notmatch "refreshAuthorizationLinks" -or $js.Content -notmatch "renderOAuthSetup" -or $js.Content -notmatch "renderConsumers" -or $js.Content -notmatch "renderChannelApi" -or $js.Content -notmatch "insertCommandToken" -or $js.Content -notmatch "saveTimer" -or $js.Content -notmatch "renderModules" -or $js.Content -notmatch "syncActionButtons") {
    throw "KTRLBoy browser verification or GUI button wiring did not load"
  }

  $authStatus = Invoke-RestMethod -Uri $authStatusUrl -TimeoutSec 2
  if ($authStatus.ok -ne $true -or -not $authStatus.providers.twitch -or -not $authStatus.providers.youtube -or -not $authStatus.providers.kick) {
    throw "KTRLBoy OAuth status did not include all providers"
  }

  $oauthSettings = Invoke-RestMethod -Uri $oauthSettingsUrl -TimeoutSec 2
  if ($oauthSettings.ok -ne $true -or -not $oauthSettings.settings.providers.twitch -or -not $oauthSettings.settings.providers.youtube -or -not $oauthSettings.settings.providers.kick) {
    throw "KTRLBoy OAuth settings API did not include all providers"
  }
  if ($oauthSettings.settings.providers.twitch.authMode -ne "client-popup" -or -not $oauthSettings.settings.providers.twitch.callbackUrl) {
    throw "KTRLBoy OAuth settings API did not report Twitch setup metadata"
  }

  $saveOauthBody = @{
    provider = "twitch"
    clientId = "local-smoke-client-id"
    scopes = "chat:read chat:edit"
  } | ConvertTo-Json
  $savedOauth = Invoke-RestMethod -Uri $oauthSettingsUrl -Method Put -Body $saveOauthBody -ContentType "application/json" -TimeoutSec 2
  if ($savedOauth.ok -ne $true -or $savedOauth.provider.clientId -ne "local-smoke-client-id") {
    throw "KTRLBoy OAuth settings API did not save Twitch Client ID"
  }

  $oauthSettingsAfterSave = Invoke-RestMethod -Uri $oauthSettingsUrl -TimeoutSec 2
  if ($oauthSettingsAfterSave.settings.providers.twitch.clientId -ne "local-smoke-client-id") {
    throw "KTRLBoy OAuth settings API did not keep saved Twitch Client ID"
  }

  $consumers = Invoke-RestMethod -Uri $consumersUrl -TimeoutSec 2
  if ($consumers.ok -ne $true -or -not ($consumers.PSObject.Properties.Name -contains "consumers") -or -not ($consumers.consumers.PSObject.Properties.Name -contains "installs")) {
    throw "KTRLBoy consumer install API did not return install status"
  }

  $install = Invoke-WebRequest -Uri $installUrl -UseBasicParsing -TimeoutSec 2
  if ($install.StatusCode -ne 200 -or $install.Content -notmatch "Add KTRLBoy" -or $install.Content -notmatch "This platform needs the app owner to add a Client ID first") {
    throw "KTRLBoy consumer install page did not render"
  }

  $channelApi = Invoke-RestMethod -Uri $channelApiUrl -TimeoutSec 2
  if ($channelApi.ok -ne $true -or -not $channelApi.channelApi.providers.twitch -or -not $channelApi.channelApi.providers.youtube -or -not $channelApi.channelApi.providers.kick) {
    throw "KTRLBoy channel API status did not include all providers"
  }
  if ($channelApi.channelApi.providers.twitch.accessMode -ne "not-connected" -or -not $channelApi.channelApi.providers.twitch.actions.connect) {
    throw "KTRLBoy channel API did not expose connection actions"
  }

  $commands = Invoke-RestMethod -Uri $commandsUrl -TimeoutSec 2
  if ($commands.ok -ne $true -or -not ($commands.PSObject.Properties.Name -contains "builtIn") -or -not ($commands.PSObject.Properties.Name -contains "custom")) {
    throw "KTRLBoy command API did not return command lists"
  }
  if (-not ($commands.builtIn | Where-Object { $_.name -eq "module" })) {
    throw "KTRLBoy command API did not include module command"
  }

  $smokeBody = @{ name = "smoke_test"; response = "Smoke test for {bot}"; enabled = $true } | ConvertTo-Json
  $created = Invoke-RestMethod -Uri $commandsUrl -Method Post -Body $smokeBody -ContentType "application/json" -TimeoutSec 2
  if ($created.ok -ne $true -or $created.command.name -ne "smoke_test") {
    throw "KTRLBoy command API did not create a command"
  }

  $updatedBody = @{ response = "Updated smoke test"; enabled = $false } | ConvertTo-Json
  $updated = Invoke-RestMethod -Uri "$commandsUrl/smoke_test" -Method Put -Body $updatedBody -ContentType "application/json" -TimeoutSec 2
  if ($updated.ok -ne $true -or $updated.command.enabled -ne $false) {
    throw "KTRLBoy command API did not update a command"
  }

  $deleted = Invoke-RestMethod -Uri "$commandsUrl/smoke_test" -Method Delete -TimeoutSec 2
  if ($deleted.ok -ne $true) {
    throw "KTRLBoy command API did not delete a command"
  }

  $timers = Invoke-RestMethod -Uri $timersUrl -TimeoutSec 2
  if ($timers.ok -ne $true -or -not ($timers.PSObject.Properties.Name -contains "timers")) {
    throw "KTRLBoy timer API did not return timer list"
  }

  $timerBody = @{ name = "smoke_timer"; messages = @("Smoke timer for {bot}"); intervalMinutes = 5; chatLines = 1; enabled = $true } | ConvertTo-Json
  $timerCreated = Invoke-RestMethod -Uri $timersUrl -Method Post -Body $timerBody -ContentType "application/json" -TimeoutSec 2
  if ($timerCreated.ok -ne $true -or $timerCreated.timer.name -ne "smoke_timer") {
    throw "KTRLBoy timer API did not create a timer"
  }

  $timerUpdatedBody = @{ messages = @("Updated timer"); intervalMinutes = 10; chatLines = 2; enabled = $false } | ConvertTo-Json
  $timerUpdated = Invoke-RestMethod -Uri "$timersUrl/smoke_timer" -Method Put -Body $timerUpdatedBody -ContentType "application/json" -TimeoutSec 2
  if ($timerUpdated.ok -ne $true -or $timerUpdated.timer.enabled -ne $false -or $timerUpdated.timer.intervalMinutes -ne 10) {
    throw "KTRLBoy timer API did not update a timer"
  }

  $timerDeleted = Invoke-RestMethod -Uri "$timersUrl/smoke_timer" -Method Delete -TimeoutSec 2
  if ($timerDeleted.ok -ne $true) {
    throw "KTRLBoy timer API did not delete a timer"
  }

  $moderation = Invoke-RestMethod -Uri $moderationUrl -TimeoutSec 2
  if ($moderation.ok -ne $true -or -not $moderation.settings -or -not ($moderation.PSObject.Properties.Name -contains "log")) {
    throw "KTRLBoy moderation API did not return settings and log"
  }

  $moderationBody = $moderation.settings | ConvertTo-Json -Depth 5
  $moderationSaved = Invoke-RestMethod -Uri $moderationUrl -Method Put -Body $moderationBody -ContentType "application/json" -TimeoutSec 2
  if ($moderationSaved.ok -ne $true -or -not $moderationSaved.settings) {
    throw "KTRLBoy moderation API did not save settings"
  }

  $modules = Invoke-RestMethod -Uri $modulesUrl -TimeoutSec 2
  if ($modules.ok -ne $true -or -not $modules.modules.commands -or -not $modules.modules.timers -or -not $modules.modules.spamFilters) {
    throw "KTRLBoy modules API did not return module settings"
  }

  $modulesBody = @{ modules = $modules.modules } | ConvertTo-Json -Depth 5
  $modulesSaved = Invoke-RestMethod -Uri $modulesUrl -Method Put -Body $modulesBody -ContentType "application/json" -TimeoutSec 2
  if ($modulesSaved.ok -ne $true -or -not $modulesSaved.modules.commands) {
    throw "KTRLBoy modules API did not save settings"
  }

  $authorizations = Invoke-RestMethod -Uri $authorizationsUrl -TimeoutSec 2
  if ($authorizations.ok -ne $true -or -not $authorizations.catalog.providers.twitch -or -not $authorizations.catalog.providers.youtube -or -not $authorizations.catalog.providers.kick) {
    throw "KTRLBoy authorization catalog API did not return all providers"
  }

  [pscustomobject]@{
    health = "ok"
    botName = $health.botName
    guiUrl = $guiUrl
    statusUrl = $statusUrl
    authStatusUrl = $authStatusUrl
    commandsUrl = $commandsUrl
    timersUrl = $timersUrl
    moderationUrl = $moderationUrl
    modulesUrl = $modulesUrl
    authorizationsUrl = $authorizationsUrl
    channelApiUrl = $channelApiUrl
    oauthSettingsUrl = $oauthSettingsUrl
    consumersUrl = $consumersUrl
    installUrl = $installUrl
    uptimeMs = $status.uptimeMs
    startedPlatforms = ($status.startedPlatforms -join ",")
    requestedPlatforms = ($status.requestedPlatforms -join ",")
  } | Format-List
} finally {
  if ($process -and -not $process.HasExited) {
    $process.Kill()
    $process.WaitForExit()
  }

  $stdout = $process.StandardOutput.ReadToEnd().Trim()
  $stderr = $process.StandardError.ReadToEnd().Trim()

  if ($stdout) {
    "KTRLBoy stdout:"
    $stdout
  }

  if ($stderr) {
    "KTRLBoy stderr:"
    $stderr
  }

  if ($hadEnv) {
    Set-Content -LiteralPath $envPath -Value $envBackup -NoNewline
  } elseif (Test-Path $envPath) {
    Remove-Item -LiteralPath $envPath -Force
  }
}
