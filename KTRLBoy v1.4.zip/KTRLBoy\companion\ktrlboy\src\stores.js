﻿const fs = require("fs");
const path = require("path");

const SERVICE_ROOT = path.resolve(__dirname, "..");
const DATA_ROOT = path.join(SERVICE_ROOT, "data");

const STORE_FILES = {
  commands: "commands.json",
  timers: "timers.json",
  modules: "modules.json",
  moderation: "moderation.json",
  tokens: "tokens.json"
};

const DEFAULTS = {
  commands: {
    schemaVersion: 1,
    items: [],
    notes: "KTRLboy command data. Rebuilt from KTRLboy v1.2 commandStore logic."
  },
  timers: {
    schemaVersion: 1,
    items: [],
    notes: "KTRLboy timer data. Rebuilt from KTRLboy v1.2 timerStore logic."
  },
  modules: {
    schemaVersion: 1,
    items: {
      commands: true,
      timers: true,
      spamFilters: false,
      modCommandManager: false
    },
    notes: "KTRLboy module data. Rebuilt from KTRLboy v1.2 moduleStore logic."
  },
  moderation: {
    schemaVersion: 1,
    settings: {
      enabled: false
    },
    log: [],
    notes: "KTRLboy moderation data. Rebuilt from KTRLboy v1.2 moderationStore logic."
  },
  tokens: {
    schemaVersion: 1,
    providers: {},
    notes: "KTRLboy token data. Placeholder only. Do not commit real tokens."
  }
};

function ensureDataRoot() {
  fs.mkdirSync(DATA_ROOT, { recursive: true });
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function getStorePath(storeName) {
  const fileName = STORE_FILES[storeName];

  if (!fileName) {
    throw new Error(`Unknown KTRLboy store: ${storeName}`);
  }

  return path.join(DATA_ROOT, fileName);
}

function readJsonSafe(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return clone(fallback);
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return clone(fallback);
  }
}

function writeJson(filePath, value) {
  ensureDataRoot();
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + "\n", "utf8");
}

function ensureStore(storeName) {
  ensureDataRoot();

  const filePath = getStorePath(storeName);

  if (!fs.existsSync(filePath)) {
    writeJson(filePath, DEFAULTS[storeName]);
  }

  return filePath;
}

function readStore(storeName) {
  const filePath = ensureStore(storeName);
  return readJsonSafe(filePath, DEFAULTS[storeName]);
}

function writeStore(storeName, value) {
  const filePath = ensureStore(storeName);
  writeJson(filePath, value);
  return readStore(storeName);
}

function normalizeArrayStore(value, fallback) {
  const base = {
    ...clone(fallback),
    ...(value || {})
  };

  if (!Array.isArray(base.items)) {
    base.items = [];
  }

  return base;
}

function normalizeObjectStore(value, fallback) {
  return {
    ...clone(fallback),
    ...(value || {})
  };
}

function replaceArrayStoreItems(storeName, items) {
  if (!Array.isArray(items)) {
    throw new Error(`${storeName} items must be an array.`);
  }

  const current = normalizeArrayStore(readStore(storeName), DEFAULTS[storeName]);

  return writeStore(storeName, {
    ...current,
    items,
    updatedAt: new Date().toISOString()
  });
}

function replaceObjectStore(storeName, value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${storeName} payload must be an object.`);
  }

  const current = normalizeObjectStore(readStore(storeName), DEFAULTS[storeName]);

  return writeStore(storeName, {
    ...current,
    ...value,
    updatedAt: new Date().toISOString()
  });
}

function resetStore(storeName) {
  if (!DEFAULTS[storeName]) {
    throw new Error(`Unknown KTRLboy store: ${storeName}`);
  }

  return writeStore(storeName, {
    ...clone(DEFAULTS[storeName]),
    resetAt: new Date().toISOString()
  });
}

function listStores() {
  return Object.keys(STORE_FILES).map((storeName) => {
    const filePath = ensureStore(storeName);
    const stat = fs.statSync(filePath);

    return {
      id: storeName,
      file: STORE_FILES[storeName],
      path: filePath,
      exists: true,
      sizeBytes: stat.size,
      modifiedAt: stat.mtime.toISOString()
    };
  });
}

function getDataSnapshot() {
  const tokenStore = readStore("tokens");

  return {
    stores: listStores(),
    data: {
      commands: readStore("commands"),
      timers: readStore("timers"),
      modules: readStore("modules"),
      moderation: readStore("moderation"),
      tokens: {
        schemaVersion: tokenStore.schemaVersion,
        providers: Object.keys(tokenStore.providers || {}),
        redacted: true
      }
    }
  };
}

module.exports = {
  DATA_ROOT,
  STORE_FILES,
  DEFAULTS,
  ensureDataRoot,
  ensureStore,
  readStore,
  writeStore,
  listStores,
  getDataSnapshot,
  replaceArrayStoreItems,
  replaceObjectStore,
  resetStore
};
