﻿# KTRLboy inside KTRL

KTRLboy is a built-in KTRL service, not a standalone user-facing sidecar.

## Source

This rebuild uses KTRLboy v1.2 as the source of truth:

- Source repo: MastTransit/KTRLBoy
- Source version: 1.2.0-alpha.1
- Imported source snapshot: companion/ktrlboy/_source-v1.2

## Target

The KTRL-integrated version will become:

- KTRLboy Alpha v1.3
- Route: /KTRLboy
- Service API: /api/services/ktrlboy
- Update source: MastTransit/KTRLBoy
- Update scope: companion/ktrlboy only

## Rules

- KTRL is the platform.
- Builder and Overlays track the KTRL platform version.
- KTRLboy has its own independent version.
- KTRLboy runs dependently under KTRL.
- KTRLboy updates independently from the KTRLboy GitHub.
- KTRLboy updates must not modify core KTRL, Builder, Overlays, Launcher, or platform scripts.

## v1.10 goal

Rebuild KTRLboy v1.2 logic into KTRL directly, then publish KTRLboy Alpha v1.3 back to the KTRLboy GitHub so the other developer can continue from the standalone service source.
