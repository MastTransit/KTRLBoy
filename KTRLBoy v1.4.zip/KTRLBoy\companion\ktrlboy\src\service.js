﻿const fs = require("fs");
const path = require("path");

const SERVICE_ROOT = path.resolve(__dirname, "..");
const VERSION_PATH = path.join(SERVICE_ROOT, "ktrlboy-version.json");
const UPDATE_PATH = path.join(SERVICE_ROOT, "service-update.json");

const {
  readStore,
  listStores,
  getDataSnapshot,
  replaceArrayStoreItems,
  replaceObjectStore,
  resetStore
} = require("./stores");

const {
  routeMessage
} = require("./command-router");

const {
  getDueTimers,
  tickTimers
} = require("./timer-engine");

const {
  checkAndLogMessage,
  clearModerationLog
} = require("./moderation-engine");

const {
  processMessage
} = require("./message-pipeline");

const {
  getConfig,
  updateConfig,
  resetConfig
} = require("./config");

const {
  listTokenProviders,
  getTokenProvider,
  setTokenProvider,
  clearTokenProvider
} = require("./token-manager");

const {
  getPlatformStatus,
  getPlatformSummary
} = require("./platform-manager");

const {
  getRuntimeStatus,
  startRuntime,
  stopRuntime,
  restartRuntime
} = require("./runtime-manager");

const {
  listAdapters,
  getAdapterState,
  startAdapter,
  stopAdapter,
  testAdapterMessage
} = require("./adapter-manager");

const {
  listAuthProviders,
  getAuthProvider,
  getAuthStart,
  exchangeTwitchCode,
  saveTwitchClientToken,
  getTwitchAuthPreflight,
  validateTwitchToken
} = require("./auth-links");
const SOURCE_ROOT = path.join(SERVICE_ROOT, "_source-v1.2");

function readJsonSafe(filePath, fallback = null) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function getVersion() {
  return readJsonSafe(VERSION_PATH, {
    name: "KTRLboy",
    display: "KTRLboy Alpha v1.3-dev",
    number: "1.3.0-alpha-dev",
    channel: "ktrlboy-alpha-v1-3",
    sourceVersion: "1.2.0-alpha.1",
    sourceRepo: "MastTransit/KTRLBoy"
  });
}

function getUpdateSource() {
  return readJsonSafe(UPDATE_PATH, {
    serviceId: "ktrlboy",
    updateScope: "service",
    independentUpdate: true,
    updateProvider: "github",
    repo: "MastTransit/KTRLBoy",
    latestManifestUrl: "https://raw.githubusercontent.com/MastTransit/KTRLBoy/main/releases/ktrlboy-latest.json",
    ownedPaths: ["companion/ktrlboy"]
  });
}

function getSourceStatus() {
  const packagePath = path.join(SOURCE_ROOT, "package.json");
  const srcPath = path.join(SOURCE_ROOT, "src");

  const packageJson = readJsonSafe(packagePath, null);

  return {
    sourceImported: fs.existsSync(SOURCE_ROOT),
    packageFound: fs.existsSync(packagePath),
    srcFound: fs.existsSync(srcPath),
    sourcePackageVersion: packageJson?.version || null,
    sourcePackageName: packageJson?.name || null
  };
}

function getStatus() {
  const version = getVersion();
  const updateSource = getUpdateSource();
  const source = getSourceStatus();

  return {
    id: "ktrlboy",
    displayName: "KTRLboy",
    status: "rebuild",
    runtimeEnabled: false,
    staged: true,
    route: "/KTRLboy",
    apiBase: "/api/ktrlboy",
    version,
    source,
    update: {
      independentUpdate: true,
      updateScope: "service",
      repo: updateSource.repo,
      latestManifestUrl: updateSource.latestManifestUrl,
      ownedPaths: updateSource.ownedPaths,
      protectedPaths: updateSource.protectedPaths || []
    },
    notes: [
      "KTRLboy is being rebuilt from KTRLboy v1.2 into the KTRL built-in service architecture.",
      "KTRLboy will run dependently under KTRL but update independently from the KTRLboy GitHub.",
      "Runtime bot adapters are not enabled in this shell yet."
    ]
  };
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderPage() {
  const status = getStatus();
  const version = status.version;

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="UTF-8" />
        <title>KTRLboy</title>
        <link rel="icon" href="/favicon.svg?v=1.10" type="image/svg+xml" />
        <style>
          :root {
            --bg:#0f0f10;
            --card:#18181b;
            --line:#33333a;
            --text:#f4f4f5;
            --muted:#a1a1aa;
            --red:#ff4444;
            --green:#22c55e;
            --yellow:#facc15;
          }

          * { box-sizing:border-box; }

          body {
            margin:0;
            min-height:100vh;
            font-family:Arial, sans-serif;
            background:
              radial-gradient(circle at top left, rgba(255,68,68,0.20), transparent 34%),
              linear-gradient(180deg, #141416, #0f0f10 45%);
            color:var(--text);
            padding:28px;
          }

          .wrap {
            max-width:1120px;
            margin:0 auto;
          }

          .top {
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:18px;
            margin-bottom:22px;
          }

          h1 {
            margin:0;
            font-size:48px;
            letter-spacing:-0.06em;
          }

          h2 {
            margin:0 0 10px;
            letter-spacing:-0.035em;
          }

          p {
            color:var(--muted);
            line-height:1.45;
          }

          .pill {
            display:inline-flex;
            align-items:center;
            gap:8px;
            border-radius:999px;
            padding:9px 13px;
            font-weight:900;
            white-space:nowrap;
          }

          .pill.yellow {
            color:var(--yellow);
            background:rgba(250,204,21,0.08);
            border:1px solid rgba(250,204,21,0.42);
          }

          .pill.green {
            color:var(--green);
            background:rgba(34,197,94,0.10);
            border:1px solid rgba(34,197,94,0.42);
          }

          .dot {
            width:9px;
            height:9px;
            border-radius:999px;
            background:currentColor;
            box-shadow:0 0 14px currentColor;
          }

          .wrap {
            max-width: 1320px !important;
          }

          .grid {
            gap: 12px !important;
          }

          .card {
            padding: 16px !important;
            margin-bottom: 10px !important;
          }

          .card h2 {
            font-size: 20px;
            margin-bottom: 8px;
          }

          p {
            margin-top: 4px;
            margin-bottom: 10px;
          }

          .actions {
            gap: 8px !important;
            margin-top: 12px !important;
          }

          .button {
            min-height: 34px !important;
            padding: 7px 10px !important;
            font-size: 12px;
          }

          .console-output {
            max-height: 150px !important;
            min-height: 90px !important;
            font-size: 11px !important;
          }

          .console-output.ktrlboy-output-collapsed {
            display: none !important;
          }

          .output-toggle-row {
            display:flex;
            justify-content:flex-end;
            margin-top:10px;
          }

          .output-toggle-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:28px;
            padding:6px 9px;
            border-radius:8px;
            border:0;
            background:#3f3f46;
            color:white;
            font-weight:900;
            font-size:11px;
            cursor:pointer;
          }

          .output-toggle-button:hover {
            background:var(--red);
          }

          .platform-card,
          .token-card,
          .runtime-panel {
            padding: 11px !important;
          }

          .platform-card-title,
          .token-card-title {
            font-size: 16px !important;
          }

          .pill {
            padding: 7px 10px !important;
            font-size: 12px;
          }

          .meta-row {
            padding: 7px 9px !important;
          }
          .ktrlboy-quick-nav {
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            margin:14px 0 20px;
          }

          .ktrlboy-quick-nav a {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:32px;
            padding:7px 10px;
            border-radius:9px;
            background:#3f3f46;
            color:white;
            text-decoration:none;
            font-weight:900;
            font-size:12px;
          }

          .ktrlboy-quick-nav a:hover {
            background:var(--red);
          }

          .section-label-card {
            display:flex !important;
            align-items:center;
            justify-content:space-between;
            cursor:pointer;
            user-select:none;
            border:1px solid rgba(255,255,255,0.07);
            background:rgba(15,15,16,0.52);
            border-radius:10px;
            padding:8px 10px !important;
            margin:8px 0 2px !important;
          }

          .section-label-card::after {
            content:"Hide";
            color:white;
            background:#3f3f46;
            border-radius:999px;
            padding:4px 8px;
            font-size:10px;
            font-weight:900;
            text-transform:none;
            letter-spacing:0;
          }

          .section-label-card.ktrlboy-section-collapsed::after {
            content:"Show";
            background:var(--red);
          }

          .ktrlboy-card-hidden {
            display:none !important;
          }

          .ktrlboy-section-hint {
            color:var(--muted);
            font-size:11px;
            font-weight:800;
            text-transform:none;
            letter-spacing:0;
            margin-left:8px;
          }
          .section-label-card {
            grid-column:1 / -1;
            margin:4px 0 -2px;
            padding:0 4px;
            color:var(--muted);
            font-size:12px;
            font-weight:900;
            text-transform:uppercase;
            letter-spacing:0.09em;
          }

          .card.compact-card {
            padding:16px;
          }

          .card.compact-card h2 {
            margin-bottom:8px;
          }

          .console-output {
            max-height:220px;
          }
          .grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:14px;
          }

          .card {
            background:rgba(24,24,27,0.90);
            border:1px solid var(--line);
            border-radius:16px;
            padding:20px;
            box-shadow:0 18px 46px rgba(0,0,0,0.28);
            margin-bottom:14px;
          }

          .wide { grid-column:1 / -1; }

          .version {
            display:inline-flex;
            align-items:center;
            gap:8px;
            margin-top:8px;
            color:#e4e4e7;
            background:rgba(15,15,16,0.72);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:999px;
            padding:8px 11px;
            font-weight:900;
          }

          .meta {
            display:grid;
            gap:8px;
            margin-top:12px;
          }

          .meta-row {
            display:grid;
            grid-template-columns:150px 1fr;
            gap:10px;
            padding:9px 10px;
            background:rgba(15,15,16,0.48);
            border:1px solid rgba(255,255,255,0.07);
            border-radius:10px;
          }

          .label {
            color:var(--muted);
            font-size:12px;
            font-weight:900;
            text-transform:uppercase;
            letter-spacing:0.05em;
          }

          .value {
            color:var(--text);
            font-weight:800;
            word-break:break-word;
          }

          .actions {
            display:flex;
            flex-wrap:wrap;
            gap:10px;
            margin-top:18px;
          }

          .button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:38px;
            background:var(--red);
            color:white;
            border:0;
            padding:9px 12px;
            border-radius:10px;
            cursor:pointer;
            font-weight:900;
            text-decoration:none;
          }

          .button.secondary {
            background:#3f3f46;
          }

          .note-list {
            margin:0;
            padding-left:18px;
            color:var(--muted);
            line-height:1.5;
          }

          select {
            width:100%;
            min-height:38px;
            border-radius:10px;
            border:1px solid rgba(255,255,255,0.10);
            background:rgba(15,15,16,0.72);
            color:var(--text);
            padding:9px 10px;
            font-weight:800;
            outline:none;
          }

          .platform-config-grid {
            display:grid;
            grid-template-columns:1fr 220px;
            gap:12px;
            margin-bottom:14px;
          }

          .token-card-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .token-card {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:14px;
            padding:14px;
          }

          .token-card-title {
            font-size:18px;
            font-weight:900;
            letter-spacing:-0.03em;
            margin-bottom:8px;
          }

          .token-card-meta {
            display:grid;
            gap:7px;
            margin-top:10px;
          }

          .token-mini-row {
            display:flex;
            justify-content:space-between;
            gap:10px;
            font-size:12px;
            color:var(--muted);
          }

          .token-mini-row strong {
            color:var(--text);
          }

          .token-safe-note {
            margin-top:10px;
            color:var(--muted);
            font-size:12px;
            line-height:1.4;
          }
          .platform-card-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .platform-card {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:14px;
            padding:14px;
          }

          .platform-card-title {
            font-size:18px;
            font-weight:900;
            letter-spacing:-0.03em;
            margin-bottom:8px;
          }

          .platform-card-meta {
            display:grid;
            gap:7px;
            margin-top:10px;
          }

          .platform-mini-row {
            display:flex;
            justify-content:space-between;
            gap:10px;
            font-size:12px;
            color:var(--muted);
          }

          .platform-mini-row strong {
            color:var(--text);
          }

          .platform-missing {
            margin-top:10px;
            color:var(--muted);
            font-size:12px;
            line-height:1.4;
          }
          .runtime-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .runtime-panel {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:12px;
            padding:12px;
          }

          .runtime-value {
            margin-top:6px;
            font-size:18px;
            font-weight:900;
            color:var(--text);
          }

          .status-good {
            color:var(--green);
          }

          .status-warn {
            color:var(--yellow);
          }

          .status-muted {
            color:var(--muted);
          }
          .console-grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:12px;
          }

          label {
            display:block;
            color:var(--muted);
            font-size:12px;
            font-weight:900;
            text-transform:uppercase;
            letter-spacing:0.05em;
            margin-bottom:6px;
          }

          input {
            width:100%;
            min-height:38px;
            border-radius:10px;
            border:1px solid rgba(255,255,255,0.10);
            background:rgba(15,15,16,0.72);
            color:var(--text);
            padding:9px 10px;
            font-weight:800;
            outline:none;
          }

          input:focus {
            border-color:rgba(255,68,68,0.52);
            box-shadow:0 0 0 3px rgba(255,68,68,0.10);
          }

          .console-output {
            margin-top:16px;
            min-height:160px;
            max-height:320px;
            overflow:auto;
            border-radius:12px;
            border:1px solid rgba(255,255,255,0.09);
            background:rgba(8,8,10,0.82);
            color:#e4e4e7;
            padding:12px;
            font-size:12px;
            line-height:1.45;
            white-space:pre-wrap;
          }
          @media (max-width:850px) {
            body { padding:16px; }
            .top { flex-direction:column; }
            .wrap {
            max-width: 1320px !important;
          }

          .grid {
            gap: 12px !important;
          }

          .card {
            padding: 16px !important;
            margin-bottom: 10px !important;
          }

          .card h2 {
            font-size: 20px;
            margin-bottom: 8px;
          }

          p {
            margin-top: 4px;
            margin-bottom: 10px;
          }

          .actions {
            gap: 8px !important;
            margin-top: 12px !important;
          }

          .button {
            min-height: 34px !important;
            padding: 7px 10px !important;
            font-size: 12px;
          }

          .console-output {
            max-height: 150px !important;
            min-height: 90px !important;
            font-size: 11px !important;
          }

          .console-output.ktrlboy-output-collapsed {
            display: none !important;
          }

          .output-toggle-row {
            display:flex;
            justify-content:flex-end;
            margin-top:10px;
          }

          .output-toggle-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:28px;
            padding:6px 9px;
            border-radius:8px;
            border:0;
            background:#3f3f46;
            color:white;
            font-weight:900;
            font-size:11px;
            cursor:pointer;
          }

          .output-toggle-button:hover {
            background:var(--red);
          }

          .platform-card,
          .token-card,
          .runtime-panel {
            padding: 11px !important;
          }

          .platform-card-title,
          .token-card-title {
            font-size: 16px !important;
          }

          .pill {
            padding: 7px 10px !important;
            font-size: 12px;
          }

          .meta-row {
            padding: 7px 9px !important;
          }
          .ktrlboy-quick-nav {
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            margin:14px 0 20px;
          }

          .ktrlboy-quick-nav a {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:32px;
            padding:7px 10px;
            border-radius:9px;
            background:#3f3f46;
            color:white;
            text-decoration:none;
            font-weight:900;
            font-size:12px;
          }

          .ktrlboy-quick-nav a:hover {
            background:var(--red);
          }

          .section-label-card {
            display:flex !important;
            align-items:center;
            justify-content:space-between;
            cursor:pointer;
            user-select:none;
            border:1px solid rgba(255,255,255,0.07);
            background:rgba(15,15,16,0.52);
            border-radius:10px;
            padding:8px 10px !important;
            margin:8px 0 2px !important;
          }

          .section-label-card::after {
            content:"Hide";
            color:white;
            background:#3f3f46;
            border-radius:999px;
            padding:4px 8px;
            font-size:10px;
            font-weight:900;
            text-transform:none;
            letter-spacing:0;
          }

          .section-label-card.ktrlboy-section-collapsed::after {
            content:"Show";
            background:var(--red);
          }

          .ktrlboy-card-hidden {
            display:none !important;
          }

          .ktrlboy-section-hint {
            color:var(--muted);
            font-size:11px;
            font-weight:800;
            text-transform:none;
            letter-spacing:0;
            margin-left:8px;
          }
          .section-label-card {
            grid-column:1 / -1;
            margin:4px 0 -2px;
            padding:0 4px;
            color:var(--muted);
            font-size:12px;
            font-weight:900;
            text-transform:uppercase;
            letter-spacing:0.09em;
          }

          .card.compact-card {
            padding:16px;
          }

          .card.compact-card h2 {
            margin-bottom:8px;
          }

          .console-output {
            max-height:220px;
          }
          .grid { grid-template-columns:1fr; }
            .meta-row { grid-template-columns:1fr; }
            select {
            width:100%;
            min-height:38px;
            border-radius:10px;
            border:1px solid rgba(255,255,255,0.10);
            background:rgba(15,15,16,0.72);
            color:var(--text);
            padding:9px 10px;
            font-weight:800;
            outline:none;
          }

          .platform-config-grid {
            display:grid;
            grid-template-columns:1fr 220px;
            gap:12px;
            margin-bottom:14px;
          }

          .token-card-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .token-card {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:14px;
            padding:14px;
          }

          .token-card-title {
            font-size:18px;
            font-weight:900;
            letter-spacing:-0.03em;
            margin-bottom:8px;
          }

          .token-card-meta {
            display:grid;
            gap:7px;
            margin-top:10px;
          }

          .token-mini-row {
            display:flex;
            justify-content:space-between;
            gap:10px;
            font-size:12px;
            color:var(--muted);
          }

          .token-mini-row strong {
            color:var(--text);
          }

          .token-safe-note {
            margin-top:10px;
            color:var(--muted);
            font-size:12px;
            line-height:1.4;
          }
          .platform-card-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .platform-card {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:14px;
            padding:14px;
          }

          .platform-card-title {
            font-size:18px;
            font-weight:900;
            letter-spacing:-0.03em;
            margin-bottom:8px;
          }

          .platform-card-meta {
            display:grid;
            gap:7px;
            margin-top:10px;
          }

          .platform-mini-row {
            display:flex;
            justify-content:space-between;
            gap:10px;
            font-size:12px;
            color:var(--muted);
          }

          .platform-mini-row strong {
            color:var(--text);
          }

          .platform-missing {
            margin-top:10px;
            color:var(--muted);
            font-size:12px;
            line-height:1.4;
          }
          .runtime-grid {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:12px;
            margin-top:16px;
          }

          .runtime-panel {
            background:rgba(15,15,16,0.56);
            border:1px solid rgba(255,255,255,0.08);
            border-radius:12px;
            padding:12px;
          }

          .runtime-value {
            margin-top:6px;
            font-size:18px;
            font-weight:900;
            color:var(--text);
          }

          .status-good {
            color:var(--green);
          }

          .status-warn {
            color:var(--yellow);
          }

          .status-muted {
            color:var(--muted);
          }
          .console-grid { grid-template-columns:1fr; }
          }
        </style>
      </head>

      <body>
        <div class="wrap">
          <div class="top">
            <div>
              <h1>KTRLboy</h1>
              <p>Built-in chat bot service for KTRL.</p>
              <div class="version">${escapeHtml(version.display)}</div>
              <div class="ktrlboy-quick-nav">
                <a href="#ktrlboy-core">Core</a>
                <a href="#ktrlboy-runtime">Runtime</a>
                <a href="#ktrlboy-auth">Auth</a>
                <a href="#ktrlboy-testing">Testing</a>
                <a href="#ktrlboy-dev">Dev</a>
                <a href="/KTRL">Back to KTRL</a>
              </div>
            </div>

            <div class="pill yellow">
              <span class="dot"></span>
              REBUILD
            </div>
          </div>

          <div class="grid">
            <div class="card">
              <h2>Service Status</h2>
              <div class="pill yellow">
                <span class="dot"></span>
                STAGED
              </div>

              <div class="meta">
                <div class="meta-row">
                  <div class="label">Runtime</div>
                  <div class="value">Disabled during rebuild</div>
                </div>
                <div class="meta-row">
                  <div class="label">Route</div>
                  <div class="value">/KTRLboy</div>
                </div>
                <div class="meta-row">
                  <div class="label">API</div>
                  <div class="value">/api/ktrlboy/status</div>
                </div>
              </div>
            </div>

            <div class="card">
              <h2>Source Import</h2>
              <div class="pill green">
                <span class="dot"></span>
                SOURCE READY
              </div>

              <div class="meta">
                <div class="meta-row">
                  <div class="label">Source</div>
                  <div class="value">${escapeHtml(version.sourceRepo || "MastTransit/KTRLBoy")}</div>
                </div>
                <div class="meta-row">
                  <div class="label">Imported</div>
                  <div class="value">${escapeHtml(status.source.sourcePackageVersion || "unknown")}</div>
                </div>
                <div class="meta-row">
                  <div class="label">Package</div>
                  <div class="value">${escapeHtml(status.source.sourcePackageName || "unknown")}</div>
                </div>
              </div>
            </div>

            <div class="card wide">
              <h2>Independent Update Rules</h2>
              <div class="meta">
                <div class="meta-row">
                  <div class="label">Update Repo</div>
                  <div class="value">${escapeHtml(status.update.repo)}</div>
                </div>
                <div class="meta-row">
                  <div class="label">Write Scope</div>
                  <div class="value">${escapeHtml((status.update.ownedPaths || []).join(", "))}</div>
                </div>
                <div class="meta-row">
                  <div class="label">Protected</div>
                  <div class="value">${escapeHtml((status.update.protectedPaths || []).join(", "))}</div>
                </div>
              </div>
            </div>

            <div class="card wide">
              <h2>Auth Links</h2>
              <p>Client-side authorization popup entry points for Twitch, YouTube, and Kick. Twitch is wired first; YouTube and Kick remain reserved for adapter/auth passes.</p>

              <div class="actions">
                <button class="button" type="button" onclick="refreshAuthLinks()">Refresh Auth Links</button>
                <button class="button secondary" type="button" onclick="startAuthProvider('twitch')">Twitch Auth</button>
                <button class="button secondary" type="button" onclick="startAuthProvider('youtube')">YouTube Auth</button>
                <button class="button secondary" type="button" onclick="startAuthProvider('kick')">Kick Auth</button>
              </div>

              <div class="platform-config-grid" style="margin-top:14px;">
                <div>
                  <label>Twitch Client ID</label>
                  <input id="twitchClientId" placeholder="Paste Twitch Client ID" />
                </div>

                <div>
                  <label>Twitch Redirect URI</label>
                  <input id="twitchRedirectUri" value="http://localhost:3000/api/ktrlboy/auth/twitch/callback" />
                </div>
              </div>

              <div>
                <label>Twitch Scopes</label>
                <input id="twitchScopes" value="chat:read chat:edit" />
              </div>

              <div class="actions">
                <button class="button" type="button" onclick="saveTwitchAuthConfig()">Save Twitch Auth Config</button>
                <button class="button secondary" type="button" onclick="generateTwitchAuthUrl()">Generate Twitch Auth URL</button>
                <a id="openTwitchAuthLink" class="button secondary" href="#" target="_blank" style="display:none;">Open Twitch Auth</a>
              </div>

              <div id="authCards" class="token-card-grid">
                <div class="token-card">Loading auth links...</div>
              </div>

              <div class="runtime-grid" style="margin-top:14px;">
                <div class="runtime-panel">
                  <div class="label">Twitch Preflight</div>
                  <div id="twitchPreflightStatus" class="runtime-value status-muted">Unknown</div>
                </div>

                <div class="runtime-panel">
                  <div class="label">Twitch Token</div>
                  <div id="twitchTokenStatus" class="runtime-value status-muted">Unknown</div>
                </div>

                <div class="runtime-panel">
                  <div class="label">Next Step</div>
                  <div id="twitchNextStep" class="runtime-value status-muted">Run Preflight</div>
                </div>
              </div>

              <pre id="authOutput" class="console-output">Auth link controls ready.</pre>
            </div>

            <div class="card wide">
              <h2>Auth / Token Status</h2>
              <p>View redacted token readiness for Twitch, YouTube, and Kick. Raw token values are never shown in the UI.</p>

              <div class="actions">
                <button class="button" type="button" onclick="refreshTokenCards()">Refresh Token Status</button>
                <button class="button secondary" type="button" onclick="clearProviderToken('twitch')">Clear Twitch</button>
                <button class="button secondary" type="button" onclick="clearProviderToken('youtube')">Clear YouTube</button>
                <button class="button secondary" type="button" onclick="clearProviderToken('kick')">Clear Kick</button>
              </div>

              <div id="tokenCards" class="token-card-grid">
                <div class="token-card">Loading tokens...</div>
              </div>

              <pre id="tokenOutput" class="console-output">Token controls ready.</pre>
            </div>

            <div class="card wide">
              <h2>Platform Readiness</h2>
              <p>Configure and inspect platform readiness before real Twitch, YouTube, and Kick adapters are enabled.</p>

              <div class="platform-config-grid">
                <div>
                  <label>Twitch Channel</label>
                  <input id="twitchChannel" value="kodezero" />
                </div>

                <div>
                  <label>Twitch Enabled</label>
                  <select id="twitchEnabled">
                    <option value="false">Disabled</option>
                    <option value="true">Enabled</option>
                  </select>
                </div>
              </div>

              <div class="actions">
                <button class="button" type="button" onclick="savePlatformConfig()">Save Platform Config</button>
                <button class="button secondary" type="button" onclick="refreshPlatformCards()">Refresh Platform Cards</button>
              </div>

              <div id="platformCards" class="platform-card-grid">
                <div class="platform-card">Loading platforms...</div>
              </div>

              <pre id="platformOutput" class="console-output">Platform controls ready.</pre>
            </div>

            <div class="card wide">
              <h2>Runtime Controls</h2>
              <p>Start and stop the KTRL-native KTRLboy runtime readiness layer. Real platform adapters are not connected yet.</p>

              <div class="actions">
                <button class="button" type="button" onclick="startRuntime()">Start Runtime</button>
                <button class="button secondary" type="button" onclick="stopRuntime()">Stop Runtime</button>
                <button class="button secondary" type="button" onclick="refreshRuntime()">Refresh Runtime</button>
                <button class="button secondary" type="button" onclick="refreshPlatforms()">Refresh Platforms</button>
              </div>

              <div class="runtime-grid">
                <div class="runtime-panel">
                  <div class="label">Runtime</div>
                  <div id="runtimeState" class="runtime-value">Loading...</div>
                </div>

                <div class="runtime-panel">
                  <div class="label">Ready Platforms</div>
                  <div id="runtimeReadyPlatforms" class="runtime-value">Loading...</div>
                </div>

                <div class="runtime-panel">
                  <div class="label">Connected</div>
                  <div id="runtimeConnectedPlatforms" class="runtime-value">Loading...</div>
                </div>
              </div>

              <pre id="runtimeOutput" class="console-output">Runtime controls ready.</pre>
            </div>

            <div class="card wide">
              <h2>Local Test Console</h2>
              <p>Test KTRLboy command routing and moderation locally before platform adapters are enabled.</p>

              <div class="console-grid">
                <div>
                  <label>Command Trigger</label>
                  <input id="commandTrigger" value="!test" />
                </div>

                <div>
                  <label>Command Response</label>
                  <input id="commandResponse" value="KTRLboy test command works." />
                </div>
              </div>

              <div class="actions">
                <button class="button" type="button" onclick="saveTestCommand()">Save Test Command</button>
                <button class="button secondary" type="button" onclick="resetCommands()">Reset Commands</button>
              </div>

              <div class="console-grid" style="margin-top:16px;">
                <div>
                  <label>Test User</label>
                  <input id="testUser" value="Kody" />
                </div>

                <div>
                  <label>Test Message</label>
                  <input id="testMessage" value="!test" />
                </div>
              </div>

              <div class="actions">
                <button class="button" type="button" onclick="sendTestMessage()">Send Test Message</button>
                <button class="button secondary" type="button" onclick="loadStores()">Refresh Stores</button>
              </div>

              <pre id="consoleOutput" class="console-output">Ready.</pre>
            </div>

            <div class="card wide">
              <h2>Rebuild Notes</h2>
              <ul class="note-list">
                ${status.notes.map((note) => `<li>${escapeHtml(note)}</li>`).join("")}
              </ul>

              <div class="actions">
                <a class="button" href="/KTRL">Back to Dashboard</a>
                <a class="button secondary" href="/api/services/ktrlboy">Service Metadata</a>
                <a class="button secondary" href="/api/ktrlboy/status">KTRLboy Status API</a>
              </div>
            </div>
          </div>
        </div>
        <script>
          function setOutput(value) {
            const output = document.getElementById("consoleOutput");
            output.textContent = typeof value === "string"
              ? value
              : JSON.stringify(value, null, 2);
          }

          async function apiFetch(url, options = {}) {
            const response = await fetch(url, {
              cache: "no-store",
              ...options,
              headers: {
                "Content-Type": "application/json",
                ...(options.headers || {})
              }
            });

            const data = await response.json();

            if (!response.ok) {
              throw data;
            }

            return data;
          }

          async function saveTestCommand() {
            try {
              const trigger = document.getElementById("commandTrigger").value.trim() || "!test";
              const response = document.getElementById("commandResponse").value.trim() || "KTRLboy test command works.";

              const data = await apiFetch("/api/ktrlboy/commands", {
                method: "PUT",
                body: JSON.stringify({
                  items: [
                    {
                      name: trigger.replace(/^!/, "") || "test",
                      trigger,
                      response,
                      enabled: true
                    }
                  ]
                })
              });

              setOutput(data);
            } catch (error) {
              setOutput(error);
            }
          }

          async function resetCommands() {
            try {
              const data = await apiFetch("/api/ktrlboy/commands/reset", {
                method: "POST",
                body: "{}"
              });

              setOutput(data);
            } catch (error) {
              setOutput(error);
            }
          }

          async function sendTestMessage() {
            try {
              const user = document.getElementById("testUser").value.trim() || "local-user";
              const message = document.getElementById("testMessage").value.trim();

              const data = await apiFetch("/api/ktrlboy/test-message", {
                method: "POST",
                body: JSON.stringify({
                  platform: "local",
                  user,
                  message
                })
              });

              setOutput(data);
            } catch (error) {
              setOutput(error);
            }
          }

          async function loadStores() {
            try {
              const data = await apiFetch("/api/ktrlboy/data");
              setOutput(data);
            } catch (error) {
              setOutput(error);
            }
          }
          function setRuntimeOutput(value) {
            const output = document.getElementById("runtimeOutput");
            if (!output) return;

            output.textContent = typeof value === "string"
              ? value
              : JSON.stringify(value, null, 2);
          }

          function setRuntimeSummary(runtime) {
            const state = document.getElementById("runtimeState");
            const ready = document.getElementById("runtimeReadyPlatforms");
            const connected = document.getElementById("runtimeConnectedPlatforms");

            if (!runtime) return;

            if (state) {
              state.textContent = runtime.state || "unknown";
              state.className = "runtime-value " + (runtime.runtimeEnabled ? "status-good" : "status-muted");
            }

            if (ready) {
              const count = runtime.platformSummary ? runtime.platformSummary.ready : 0;
              ready.textContent = String(count || 0);
              ready.className = "runtime-value " + (count > 0 ? "status-good" : "status-warn");
            }

            if (connected) {
              const count = runtime.connectedPlatforms ? runtime.connectedPlatforms.length : 0;
              connected.textContent = String(count || 0);
              connected.className = "runtime-value " + (count > 0 ? "status-good" : "status-muted");
            }
          }

          async function refreshRuntime() {
            try {
              const data = await apiFetch("/api/ktrlboy/runtime");
              setRuntimeSummary(data.runtime);
              setRuntimeOutput(data);
            } catch (error) {
              setRuntimeOutput(error);
            }
          }

          async function startRuntime() {
            try {
              const data = await apiFetch("/api/ktrlboy/runtime/start", {
                method: "POST",
                body: "{}"
              });

              setRuntimeSummary(data.result.runtime);
              setRuntimeOutput(data);
            } catch (error) {
              setRuntimeOutput(error);
            }
          }

          async function stopRuntime() {
            try {
              const data = await apiFetch("/api/ktrlboy/runtime/stop", {
                method: "POST",
                body: "{}"
              });

              setRuntimeSummary(data.result.runtime);
              setRuntimeOutput(data);
            } catch (error) {
              setRuntimeOutput(error);
            }
          }

          async function refreshPlatforms() {
            try {
              const data = await apiFetch("/api/ktrlboy/platforms");
              setRuntimeOutput(data);
            } catch (error) {
              setRuntimeOutput(error);
            }
          }

          setTimeout(refreshRuntime, 250);
          function setPlatformOutput(value) {
            const output = document.getElementById("platformOutput");
            if (!output) return;

            output.textContent = typeof value === "string"
              ? value
              : JSON.stringify(value, null, 2);
          }

          function renderPlatformCard(platform) {
            const readyClass = platform.ready ? "green" : "yellow";
            const readyText = platform.ready ? "READY" : "NOT READY";
            const missing = Array.isArray(platform.missing) && platform.missing.length
              ? platform.missing.join(", ")
              : "none";

            return ""
              + "<div class='platform-card'>"
              +   "<div class='platform-card-title'>" + (platform.label || platform.id) + "</div>"
              +   "<div class='pill " + readyClass + "'>"
              +     "<span class='dot'></span>"
              +     readyText
              +   "</div>"
              +   "<div class='platform-card-meta'>"
              +     "<div class='platform-mini-row'>"
              +       "<span>Enabled</span>"
              +       "<strong>" + (platform.enabled ? "yes" : "no") + "</strong>"
              +     "</div>"
              +     "<div class='platform-mini-row'>"
              +       "<span>Runtime</span>"
              +       "<strong>" + (platform.runtimeEnabled ? "on" : "off") + "</strong>"
              +     "</div>"
              +     "<div class='platform-mini-row'>"
              +       "<span>Connected</span>"
              +       "<strong>" + (platform.connected ? "yes" : "no") + "</strong>"
              +     "</div>"
              +     "<div class='platform-mini-row'>"
              +       "<span>Tokens</span>"
              +       "<strong>" + (platform.token && platform.token.configured ? "configured" : "missing") + "</strong>"
              +     "</div>"
              +   "</div>"
              +   "<div class='platform-missing'>"
              +     "Missing: " + missing
              +   "</div>"
              + "</div>";
          }
          async function refreshPlatformCards() {
            try {
              const data = await apiFetch("/api/ktrlboy/platforms");
              const cards = document.getElementById("platformCards");

              if (cards) {
                cards.innerHTML = data.summary.platforms.map(renderPlatformCard).join("");
              }

              const twitch = data.summary.platforms.find((platform) => platform.id === "twitch");

              if (twitch) {
                const twitchChannel = document.getElementById("twitchChannel");
                const twitchEnabled = document.getElementById("twitchEnabled");

                if (twitchChannel) {
                  twitchChannel.value = twitch.config.channel || "";
                }

                if (twitchEnabled) {
                  twitchEnabled.value = twitch.enabled ? "true" : "false";
                }
              }

              setPlatformOutput(data);
            } catch (error) {
              setPlatformOutput(error);
            }
          }

          async function savePlatformConfig() {
            try {
              const twitchChannel = document.getElementById("twitchChannel").value.trim();
              const twitchEnabled = document.getElementById("twitchEnabled").value === "true";

              const data = await apiFetch("/api/ktrlboy/config", {
                method: "PUT",
                body: JSON.stringify({
                  platforms: {
                    twitch: {
                      enabled: twitchEnabled,
                      channel: twitchChannel
                    }
                  }
                })
              });

              setPlatformOutput(data);
              await refreshPlatformCards();
            } catch (error) {
              setPlatformOutput(error);
            }
          }

          setTimeout(refreshPlatformCards, 350);
          function setTokenOutput(value) {
            const output = document.getElementById("tokenOutput");
            if (!output) return;

            output.textContent = typeof value === "string"
              ? value
              : JSON.stringify(value, null, 2);
          }

          function renderTokenCard(provider) {
            const configuredClass = provider.configured ? "green" : "yellow";
            const configuredText = provider.configured ? "CONFIGURED" : "MISSING";
            const scopes = Array.isArray(provider.scopes) && provider.scopes.length
              ? provider.scopes.join(", ")
              : "none";

            return ""
              + "<div class='token-card'>"
              +   "<div class='token-card-title'>" + provider.id + "</div>"
              +   "<div class='pill " + configuredClass + "'>"
              +     "<span class='dot'></span>"
              +     configuredText
              +   "</div>"
              +   "<div class='token-card-meta'>"
              +     "<div class='token-mini-row'>"
              +       "<span>Access Token</span>"
              +       "<strong>" + (provider.hasAccessToken ? "yes" : "no") + "</strong>"
              +     "</div>"
              +     "<div class='token-mini-row'>"
              +       "<span>Refresh Token</span>"
              +       "<strong>" + (provider.hasRefreshToken ? "yes" : "no") + "</strong>"
              +     "</div>"
              +     "<div class='token-mini-row'>"
              +       "<span>Client ID</span>"
              +       "<strong>" + (provider.hasClientId ? "yes" : "no") + "</strong>"
              +     "</div>"
              +   "</div>"
              +   "<div class='token-safe-note'>"
              +     "Scopes: " + scopes + "<br />"
              +     "Raw token values are redacted."
              +   "</div>"
              + "</div>";
          }

          async function refreshTokenCards() {
            try {
              const data = await apiFetch("/api/ktrlboy/tokens");
              const cards = document.getElementById("tokenCards");

              if (cards) {
                cards.innerHTML = data.providers.map(renderTokenCard).join("");
              }

              setTokenOutput(data);
            } catch (error) {
              setTokenOutput(error);
            }
          }

          async function clearProviderToken(providerId) {
            try {
              const data = await apiFetch("/api/ktrlboy/tokens/" + encodeURIComponent(providerId) + "/clear", {
                method: "POST",
                body: "{}"
              });

              setTokenOutput(data);
              await refreshTokenCards();
              await refreshPlatformCards();
            } catch (error) {
              setTokenOutput(error);
            }
          }

          setTimeout(refreshTokenCards, 400);
          function setAuthOutput(value) {
            const output = document.getElementById("authOutput");
            if (!output) return;

            output.textContent = typeof value === "string"
              ? value
              : JSON.stringify(value, null, 2);
          }

          function renderAuthCard(provider) {
            const readyClass = provider.authReady ? "green" : "yellow";
            const readyText = provider.authReady ? "READY" : "PLACEHOLDER";

            return ""
              + "<div class='token-card'>"
              +   "<div class='token-card-title'>" + provider.label + "</div>"
              +   "<div class='pill " + readyClass + "'>"
              +     "<span class='dot'></span>"
              +     readyText
              +   "</div>"
              +   "<div class='token-card-meta'>"
              +     "<div class='token-mini-row'>"
              +       "<span>Start</span>"
              +       "<strong>" + provider.startRoute + "</strong>"
              +     "</div>"
              +     "<div class='token-mini-row'>"
              +       "<span>Callback</span>"
              +       "<strong>" + provider.callbackRoute + "</strong>"
              +     "</div>"
              +   "</div>"
              +   "<div class='token-safe-note'>" + provider.docs + "</div>"
              + "</div>";
          }

          async function refreshAuthLinks() {
            try {
              const data = await apiFetch("/api/ktrlboy/auth");
              const cards = document.getElementById("authCards");

              if (cards) {
                cards.innerHTML = data.providers.map(renderAuthCard).join("");
              }

              setAuthOutput(data);
            } catch (error) {
              setAuthOutput(error);
            }
          }

          async function startAuthProvider(providerId) {
            try {
              const data = await apiFetch("/api/ktrlboy/auth/" + encodeURIComponent(providerId) + "/start");
              setAuthOutput(data);
            } catch (error) {
              setAuthOutput(error);
            }
          }

          setTimeout(refreshAuthLinks, 450);
          function ktrlboyFindCardByHeading(text) {
            const wanted = String(text).trim().toLowerCase();
            const cards = Array.from(document.querySelectorAll(".grid > .card"));

            return cards.find(function (card) {
              const h2 = card.querySelector("h2");
              return h2 && h2.textContent.trim().toLowerCase() === wanted;
            });
          }

          function ktrlboyMakeLabel(id, text) {
            const existing = document.getElementById(id);
            if (existing) return existing;

            const label = document.createElement("div");
            label.id = id;
            label.className = "section-label-card";
            label.textContent = text;
            return label;
          }

          function ktrlboyMoveCard(grid, card) {
            if (grid && card) {
              card.classList.add("compact-card");
              grid.appendChild(card);
            }
          }

          function organizeKtrlboyUi() {
            const grid = document.querySelector(".grid");
            if (!grid) return;

            const serviceStatus = ktrlboyFindCardByHeading("Service Status");
            const sourceImport = ktrlboyFindCardByHeading("Source Import");
            const runtimeControls = ktrlboyFindCardByHeading("Runtime Controls");
            const platformReadiness = ktrlboyFindCardByHeading("Platform Readiness");
            const tokenStatus = ktrlboyFindCardByHeading("Auth / Token Status");
            const authLinks = ktrlboyFindCardByHeading("Auth Links");
            const localConsole = ktrlboyFindCardByHeading("Local Test Console");
            const updateRules = ktrlboyFindCardByHeading("Independent Update Rules");
            const rebuildNotes = ktrlboyFindCardByHeading("Rebuild Notes");

            grid.appendChild(ktrlboyMakeLabel("ktrlboy-core", "Core"));
            ktrlboyMoveCard(grid, serviceStatus);
            ktrlboyMoveCard(grid, sourceImport);

            grid.appendChild(ktrlboyMakeLabel("ktrlboy-runtime", "Runtime"));
            ktrlboyMoveCard(grid, runtimeControls);
            ktrlboyMoveCard(grid, platformReadiness);

            grid.appendChild(ktrlboyMakeLabel("ktrlboy-auth", "Auth"));
            ktrlboyMoveCard(grid, tokenStatus);
            ktrlboyMoveCard(grid, authLinks);

            grid.appendChild(ktrlboyMakeLabel("ktrlboy-testing", "Testing"));
            ktrlboyMoveCard(grid, localConsole);

            grid.appendChild(ktrlboyMakeLabel("ktrlboy-dev", "Dev"));
            ktrlboyMoveCard(grid, updateRules);
            ktrlboyMoveCard(grid, rebuildNotes);
          }

          setTimeout(organizeKtrlboyUi, 100);
          function installKtrlboyOutputToggles() {
            const outputs = Array.from(document.querySelectorAll(".console-output"));

            outputs.forEach(function (output) {
              if (output.dataset.toggleInstalled === "true") return;

              output.dataset.toggleInstalled = "true";
              output.classList.add("ktrlboy-output-collapsed");

              const row = document.createElement("div");
              row.className = "output-toggle-row";

              const button = document.createElement("button");
              button.type = "button";
              button.className = "output-toggle-button";
              button.textContent = "Show Output";

              button.addEventListener("click", function () {
                const collapsed = output.classList.toggle("ktrlboy-output-collapsed");
                button.textContent = collapsed ? "Show Output" : "Hide Output";
              });

              row.appendChild(button);
              output.parentNode.insertBefore(row, output);
            });
          }

          setTimeout(installKtrlboyOutputToggles, 150);
          setTimeout(installKtrlboyOutputToggles, 600);
          const KTRLBOY_SECTION_MAP = [
            {
              id: "ktrlboy-core",
              cards: ["Service Status", "Source Import"],
              defaultCollapsed: false,
              hint: "status + imported source"
            },
            {
              id: "ktrlboy-runtime",
              cards: ["Runtime Controls", "Platform Readiness"],
              defaultCollapsed: false,
              hint: "runtime + platform readiness"
            },
            {
              id: "ktrlboy-auth",
              cards: ["Auth / Token Status", "Auth Links"],
              defaultCollapsed: false,
              hint: "tokens + reserved auth routes"
            },
            {
              id: "ktrlboy-testing",
              cards: ["Local Test Console"],
              defaultCollapsed: true,
              hint: "local command/moderation testing"
            },
            {
              id: "ktrlboy-dev",
              cards: ["Independent Update Rules", "Rebuild Notes"],
              defaultCollapsed: true,
              hint: "update rules + rebuild notes"
            }
          ];

          function ktrlboyCardHeading(card) {
            const h2 = card ? card.querySelector("h2") : null;
            return h2 ? h2.textContent.trim() : "";
          }

          function ktrlboyFindCardsByHeadings(headings) {
            const wanted = headings.map(function (heading) {
              return String(heading).trim().toLowerCase();
            });

            return Array.from(document.querySelectorAll(".grid > .card")).filter(function (card) {
              return wanted.includes(ktrlboyCardHeading(card).toLowerCase());
            });
          }

          function setKtrlboySectionCollapsed(label, cards, collapsed) {
            label.classList.toggle("ktrlboy-section-collapsed", collapsed);

            cards.forEach(function (card) {
              card.classList.toggle("ktrlboy-card-hidden", collapsed);
            });

            label.dataset.collapsed = collapsed ? "true" : "false";
          }

          function installKtrlboySectionCollapse() {
            KTRLBOY_SECTION_MAP.forEach(function (section) {
              const label = document.getElementById(section.id);
              if (!label || label.dataset.collapseInstalled === "true") return;

              label.dataset.collapseInstalled = "true";

              if (!label.querySelector(".ktrlboy-section-hint")) {
                const hint = document.createElement("span");
                hint.className = "ktrlboy-section-hint";
                hint.textContent = section.hint || "";
                label.appendChild(hint);
              }

              const cards = ktrlboyFindCardsByHeadings(section.cards);

              label.addEventListener("click", function () {
                const collapsed = label.dataset.collapsed !== "true";
                setKtrlboySectionCollapsed(label, cards, collapsed);
              });

              setKtrlboySectionCollapsed(label, cards, section.defaultCollapsed === true);
            });
          }

          setTimeout(installKtrlboySectionCollapse, 200);
          setTimeout(installKtrlboySectionCollapse, 700);
          function splitScopes(value) {
            return String(value || "")
              .split(/[,\s]+/)
              .map(function (scope) { return scope.trim(); })
              .filter(Boolean);
          }

          async function loadTwitchAuthConfig() {
            try {
              const data = await apiFetch("/api/ktrlboy/config");
              const twitch = data.config && data.config.platforms ? data.config.platforms.twitch || {} : {};

              const clientId = document.getElementById("twitchClientId");
              const redirectUri = document.getElementById("twitchRedirectUri");
              const scopes = document.getElementById("twitchScopes");

              if (clientId) clientId.value = twitch.clientId || "";
              if (redirectUri) redirectUri.value = twitch.redirectUri || "http://localhost:3000/api/ktrlboy/auth/twitch/callback";
              if (scopes) scopes.value = Array.isArray(twitch.scopes) ? twitch.scopes.join(" ") : "chat:read chat:edit";
            } catch (error) {
              setAuthOutput(error);
            }
          }

          async function saveTwitchAuthConfig() {
            try {
              const clientId = document.getElementById("twitchClientId").value.trim();
              const redirectUri = document.getElementById("twitchRedirectUri").value.trim() || "http://localhost:3000/api/ktrlboy/auth/twitch/callback";
              const scopes = splitScopes(document.getElementById("twitchScopes").value);

              if (clientId) {
                await apiFetch("/api/ktrlboy/tokens/twitch", {
                  method: "PUT",
                  body: JSON.stringify({
                    clientId
                  })
                });
              }

              const data = await apiFetch("/api/ktrlboy/config", {
                method: "PUT",
                body: JSON.stringify({
                  platforms: {
                    twitch: {
                      clientId,
                      redirectUri,
                      scopes
                    }
                  }
                })
              });

              setAuthOutput(data);
              await refreshAuthLinks();
            } catch (error) {
              setAuthOutput(error);
            }
          }

          async function generateTwitchAuthUrl() {
            try {
              await saveTwitchAuthConfig();

              const data = await apiFetch("/api/ktrlboy/auth/twitch/start");
              const link = document.getElementById("openTwitchAuthLink");

              if (link && data.auth && data.auth.authUrl) {
                link.href = data.auth.authUrl;
                link.style.display = "inline-flex";
              }

              setAuthOutput(data);
            } catch (error) {
              setAuthOutput(error);
            }
          }

          setTimeout(loadTwitchAuthConfig, 500);
          function setTwitchAuthSummary(preflight, validation) {
            const preflightEl = document.getElementById("twitchPreflightStatus");
            const tokenEl = document.getElementById("twitchTokenStatus");
            const nextEl = document.getElementById("twitchNextStep");

            if (preflightEl && preflight) {
              const ready = preflight.readyForTokenExchange === true;
              preflightEl.textContent = ready ? "Ready" : "Missing";
              preflightEl.className = "runtime-value " + (ready ? "status-good" : "status-warn");
            }

            if (tokenEl && validation) {
              tokenEl.textContent = validation.valid ? "Valid" : "Missing";
              tokenEl.className = "runtime-value " + (validation.valid ? "status-good" : "status-warn");
            }

            if (nextEl) {
              let next = "Run Preflight";
              let cls = "status-muted";

              if (preflight && !preflight.readyForAuthUrl) {
                next = "Add Client ID";
                cls = "status-warn";
              } else if (preflight && preflight.readyForTokenExchange && validation && !validation.valid) {
                next = "Open Twitch Auth";
                cls = "status-warn";
              } else if (validation && validation.valid) {
                next = "Ready";
                cls = "status-good";
              }

              nextEl.textContent = next;
              nextEl.className = "runtime-value " + cls;
            }
          }

          async function refreshTwitchAuthDiagnostics() {
            try {
              const preflightData = await apiFetch("/api/ktrlboy/auth/twitch/preflight");
              const validateData = await apiFetch("/api/ktrlboy/auth/twitch/validate");

              setTwitchAuthSummary(preflightData.preflight, validateData.validation);

              return {
                preflight: preflightData,
                validation: validateData
              };
            } catch (error) {
              setAuthOutput(error);
              return null;
            }
          }

          const oldTwitchPreflight = typeof twitchPreflight === "function" ? twitchPreflight : null;
          twitchPreflight = async function () {
            try {
              await saveTwitchAuthConfig();

              const data = await refreshTwitchAuthDiagnostics();
              setAuthOutput(data);
            } catch (error) {
              setAuthOutput(error);
            }
          };

          const oldValidateTwitchTokenUi = typeof validateTwitchTokenUi === "function" ? validateTwitchTokenUi : null;
          validateTwitchTokenUi = async function () {
            try {
              const data = await refreshTwitchAuthDiagnostics();
              setAuthOutput(data);
              await refreshTokenCards();
              await refreshPlatformCards();
            } catch (error) {
              setAuthOutput(error);
            }
          };

          setTimeout(refreshTwitchAuthDiagnostics, 800);
        </script>
      </body>
    </html>
  `;
}

function sendApiError(res, error, statusCode = 400) {
  res.status(statusCode).json({
    status: "error",
    message: error?.message || String(error)
  });
}

function registerKtrlboyRoutes(app) {
  const express = require("express");
  const ktrlboyJsonParser = express.json({ limit: "1mb" });

  app.get("/KTRLboy", (req, res) => {
    res.send(renderPage());
  });

  app.get("/api/ktrlboy/status", (req, res) => {
    res.json({
      status: "ok",
      service: getStatus()
    });
  });

  app.get("/api/ktrlboy/version", (req, res) => {
    res.json({
      status: "ok",
      version: getVersion()
    });
  });

  app.get("/api/ktrlboy/update-source", (req, res) => {
    res.json({
      status: "ok",
      updateSource: getUpdateSource()
    });
  });

  app.get("/api/ktrlboy/data", (req, res) => {
    res.json({
      status: "ok",
      snapshot: getDataSnapshot()
    });
  });

  app.get("/api/ktrlboy/stores", (req, res) => {
    res.json({
      status: "ok",
      stores: listStores()
    });
  });

  app.get("/api/ktrlboy/commands", (req, res) => {
    res.json({
      status: "ok",
      commands: readStore("commands")
    });
  });

  app.get("/api/ktrlboy/timers", (req, res) => {
    res.json({
      status: "ok",
      timers: readStore("timers")
    });
  });

  app.get("/api/ktrlboy/modules", (req, res) => {
    res.json({
      status: "ok",
      modules: readStore("modules")
    });
  });

  app.get("/api/ktrlboy/moderation", (req, res) => {
    res.json({
      status: "ok",
      moderation: readStore("moderation")
    });
  });

  app.put("/api/ktrlboy/commands", ktrlboyJsonParser, (req, res) => {
    try {
      const updated = replaceArrayStoreItems("commands", req.body?.items);
      res.json({ status: "ok", commands: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/commands/reset", (req, res) => {
    try {
      const updated = resetStore("commands");
      res.json({ status: "ok", commands: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.put("/api/ktrlboy/timers", ktrlboyJsonParser, (req, res) => {
    try {
      const updated = replaceArrayStoreItems("timers", req.body?.items);
      res.json({ status: "ok", timers: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/timers/reset", (req, res) => {
    try {
      const updated = resetStore("timers");
      res.json({ status: "ok", timers: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.put("/api/ktrlboy/modules", ktrlboyJsonParser, (req, res) => {
    try {
      const updated = replaceObjectStore("modules", req.body || {});
      res.json({ status: "ok", modules: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/modules/reset", (req, res) => {
    try {
      const updated = resetStore("modules");
      res.json({ status: "ok", modules: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.put("/api/ktrlboy/moderation", ktrlboyJsonParser, (req, res) => {
    try {
      const updated = replaceObjectStore("moderation", req.body || {});
      res.json({ status: "ok", moderation: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/moderation/reset", (req, res) => {
    try {
      const updated = resetStore("moderation");
      res.json({ status: "ok", moderation: updated });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/route-message", ktrlboyJsonParser, (req, res) => {
    try {
      const result = routeMessage(req.body || {});
      res.json({
        status: "ok",
        result
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });
  app.get("/api/ktrlboy/timers/due", (req, res) => {
    try {
      res.json({
        status: "ok",
        due: getDueTimers()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/timers/tick", (req, res) => {
    try {
      const result = tickTimers();
      res.json({
        status: "ok",
        result
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/moderation/check", ktrlboyJsonParser, (req, res) => {
    try {
      const result = checkAndLogMessage(req.body || {});
      res.json({
        status: "ok",
        result
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/moderation/log/clear", (req, res) => {
    try {
      const moderation = clearModerationLog();
      res.json({
        status: "ok",
        moderation
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/test-message", ktrlboyJsonParser, (req, res) => {
    try {
      const result = processMessage(req.body || {});
      res.json({
        status: "ok",
        result
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/config", (req, res) => {
    try {
      res.json({
        status: "ok",
        config: getConfig()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.put("/api/ktrlboy/config", ktrlboyJsonParser, (req, res) => {
    try {
      const config = updateConfig(req.body || {});
      res.json({
        status: "ok",
        config
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/config/reset", (req, res) => {
    try {
      const config = resetConfig();
      res.json({
        status: "ok",
        config
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/tokens", (req, res) => {
    try {
      res.json({
        status: "ok",
        providers: listTokenProviders(),
        redacted: true
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/tokens/:providerId", (req, res) => {
    try {
      res.json({
        status: "ok",
        provider: getTokenProvider(req.params.providerId),
        redacted: true
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.put("/api/ktrlboy/tokens/:providerId", ktrlboyJsonParser, (req, res) => {
    try {
      const provider = setTokenProvider(req.params.providerId, req.body || {});
      res.json({
        status: "ok",
        provider,
        redacted: true
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/tokens/:providerId/clear", (req, res) => {
    try {
      const provider = clearTokenProvider(req.params.providerId);
      res.json({
        status: "ok",
        provider,
        redacted: true
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/platforms", (req, res) => {
    try {
      res.json({
        status: "ok",
        summary: getPlatformSummary()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/platforms/:providerId", (req, res) => {
    try {
      res.json({
        status: "ok",
        platform: getPlatformStatus(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/runtime", (req, res) => {
    try {
      res.json({
        status: "ok",
        runtime: getRuntimeStatus()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/runtime/start", (req, res) => {
    try {
      res.json({
        status: "ok",
        result: startRuntime()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/runtime/stop", (req, res) => {
    try {
      res.json({
        status: "ok",
        result: stopRuntime()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/runtime/restart", (req, res) => {
    try {
      res.json({
        status: "ok",
        result: restartRuntime()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/auth", (req, res) => {
    try {
      res.json({
        status: "ok",
        providers: listAuthProviders()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/auth/twitch/preflight", (req, res) => {
    try {
      res.json({
        status: "ok",
        preflight: getTwitchAuthPreflight()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/auth/twitch/validate", async (req, res) => {
    try {
      res.json({
        status: "ok",
        validation: await validateTwitchToken()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });
  app.get("/api/ktrlboy/auth/:providerId", (req, res) => {
    try {
      res.json({
        status: "ok",
        provider: getAuthProvider(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/auth/:providerId/start", (req, res) => {
    try {
      res.json({
        status: "ok",
        auth: getAuthStart(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/auth/twitch/token", ktrlboyJsonParser, async (req, res) => {
    try {
      res.json({
        status: "ok",
        result: await saveTwitchClientToken(req.body || {})
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/auth/:providerId/callback", async (req, res) => {
    try {
      if (req.params.providerId !== "twitch") {
        res.status(501).json({
          status: "placeholder",
          message: "KTRLboy OAuth callback route is reserved but not implemented yet.",
          provider: req.params.providerId
        });
        return;
      }

      if (!req.query.code && !req.query.access_token && !req.query.error) {
        res.send(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="UTF-8" />
              <title>KTRLboy Twitch Auth</title>
              <style>
                body { margin:0; min-height:100vh; display:grid; place-items:center; background:#0f0f10; color:#f4f4f5; font-family:Arial, sans-serif; }
                .card { max-width:720px; background:#18181b; border:1px solid #33333a; border-radius:16px; padding:24px; box-shadow:0 18px 46px rgba(0,0,0,0.28); }
                p { color:#a1a1aa; line-height:1.45; }
                a { color:#ff4444; font-weight:900; }
              </style>
            </head>
            <body>
              <div class="card">
                <h1>Finishing Twitch Auth</h1>
                <p id="message">Reading the Twitch authorization popup response.</p>
                <a href="/KTRLboy">Back to KTRLboy</a>
              </div>
              <script>
                const message = document.getElementById("message");
                const params = new URLSearchParams((window.location.hash || "").replace(/^#/, ""));
                fetch("/api/ktrlboy/auth/twitch/token", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    accessToken: params.get("access_token"),
                    tokenType: params.get("token_type"),
                    expiresIn: params.get("expires_in"),
                    scope: params.get("scope"),
                    state: params.get("state")
                  })
                })
                  .then(async function (response) {
                    const body = await response.json();
                    if (!response.ok || body.status !== "ok") throw new Error(body.error || "Twitch authorization failed.");
                    message.textContent = "Twitch authorization complete. You can return to KTRLboy.";
                    window.setTimeout(function () { window.location.href = "/KTRLboy"; }, 1200);
                  })
                  .catch(function (error) {
                    message.textContent = error && error.message ? error.message : String(error);
                  });
              </script>
            </body>
          </html>
        `);
        return;
      }

      const result = await exchangeTwitchCode(req.query || {});

      res.send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8" />
            <title>KTRLboy Twitch Auth</title>
            <style>
              body {
                margin:0;
                min-height:100vh;
                display:grid;
                place-items:center;
                background:#0f0f10;
                color:#f4f4f5;
                font-family:Arial, sans-serif;
              }
              .card {
                max-width:720px;
                background:#18181b;
                border:1px solid #33333a;
                border-radius:16px;
                padding:24px;
                box-shadow:0 18px 46px rgba(0,0,0,0.28);
              }
              h1 { margin-top:0; }
              p { color:#a1a1aa; line-height:1.45; }
              a {
                display:inline-flex;
                margin-top:12px;
                background:#ff4444;
                color:white;
                text-decoration:none;
                font-weight:900;
                padding:10px 13px;
                border-radius:10px;
              }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Twitch Auth Complete</h1>
              <p>${result.message}</p>
              <p>Raw token values were stored locally and are not displayed.</p>
              <a href="/KTRLboy">Back to KTRLboy</a>
            </div>
          </body>
        </html>
      `);
    } catch (error) {
      res.status(400).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8" />
            <title>KTRLboy Twitch Auth Error</title>
            <style>
              body {
                margin:0;
                min-height:100vh;
                display:grid;
                place-items:center;
                background:#0f0f10;
                color:#f4f4f5;
                font-family:Arial, sans-serif;
              }
              .card {
                max-width:720px;
                background:#18181b;
                border:1px solid #33333a;
                border-radius:16px;
                padding:24px;
              }
              p { color:#a1a1aa; }
              a { color:#ff4444; font-weight:900; }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Twitch Auth Error</h1>
              <p>${String(error.message || error)}</p>
              <a href="/KTRLboy">Back to KTRLboy</a>
            </div>
          </body>
        </html>
      `);
    }
  });
  app.get("/api/ktrlboy/adapters", (req, res) => {
    try {
      res.json({
        status: "ok",
        ...listAdapters()
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.get("/api/ktrlboy/adapters/:providerId", (req, res) => {
    try {
      res.json({
        status: "ok",
        adapter: getAdapterState(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/adapters/:providerId/start", (req, res) => {
    try {
      res.json({
        status: "ok",
        adapter: startAdapter(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/adapters/:providerId/stop", (req, res) => {
    try {
      res.json({
        status: "ok",
        adapter: stopAdapter(req.params.providerId)
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

  app.post("/api/ktrlboy/adapters/:providerId/test-message", ktrlboyJsonParser, (req, res) => {
    try {
      res.json({
        status: "ok",
        ...testAdapterMessage(req.params.providerId, req.body || {})
      });
    } catch (error) {
      sendApiError(res, error);
    }
  });

}

module.exports = {
  getVersion,
  getUpdateSource,
  getStatus,
  renderPage,
  registerKtrlboyRoutes
};


























