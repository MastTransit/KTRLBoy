import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".data");
const storePath = path.join(storeDir, "moderation.json");
const logPath = path.join(storeDir, "moderation-log.json");

export const defaultModerationSettings = {
  enabled: true,
  dryRun: true,
  action: "delete",
  warnBeforeAction: true,
  timeoutAfterViolations: 2,
  timeoutSeconds: 300,
  allowLinks: true,
  blockedTerms: [],
  maxCapsPercent: 80,
  minCapsLength: 12,
  maxRepeatedChars: 8,
  maxMessagesPerWindow: 6,
  spamWindowSeconds: 10,
  ignoredRoles: ["broadcaster", "moderator", "owner"],
};

function readJson(filePath, fallback) {
  if (!fs.existsSync(filePath)) return fallback;

  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function positiveNumber(value, fallback, min = 1, max = Number.MAX_SAFE_INTEGER) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, Math.round(number)));
}

function normalizeBlockedTerms(value) {
  if (Array.isArray(value)) {
    return value.map((term) => String(term).trim()).filter(Boolean);
  }

  return String(value || "")
    .split(/\r?\n|,/)
    .map((term) => term.trim())
    .filter(Boolean);
}

function normalizeSettings(input) {
  const merged = {
    ...defaultModerationSettings,
    ...(input || {}),
  };

  return {
    enabled: Boolean(merged.enabled),
    dryRun: Boolean(merged.dryRun),
    action: ["warn", "delete", "timeout", "ban"].includes(merged.action)
      ? merged.action
      : defaultModerationSettings.action,
    warnBeforeAction: Boolean(merged.warnBeforeAction),
    timeoutAfterViolations: positiveNumber(merged.timeoutAfterViolations, 2, 1, 10),
    timeoutSeconds: positiveNumber(merged.timeoutSeconds, 300, 10, 1209600),
    allowLinks: Boolean(merged.allowLinks),
    blockedTerms: normalizeBlockedTerms(merged.blockedTerms),
    maxCapsPercent: positiveNumber(merged.maxCapsPercent, 80, 1, 100),
    minCapsLength: positiveNumber(merged.minCapsLength, 12, 1, 500),
    maxRepeatedChars: positiveNumber(merged.maxRepeatedChars, 8, 2, 100),
    maxMessagesPerWindow: positiveNumber(merged.maxMessagesPerWindow, 6, 2, 100),
    spamWindowSeconds: positiveNumber(merged.spamWindowSeconds, 10, 2, 300),
    ignoredRoles: Array.isArray(merged.ignoredRoles)
      ? merged.ignoredRoles.map((role) => String(role).toLowerCase())
      : defaultModerationSettings.ignoredRoles,
  };
}

export function createModerationStore() {
  return {
    getSettings() {
      return normalizeSettings(readJson(storePath, defaultModerationSettings));
    },

    updateSettings(input) {
      const settings = normalizeSettings({
        ...this.getSettings(),
        ...input,
      });
      writeJson(storePath, settings);
      return settings;
    },

    appendLog(entry) {
      const current = readJson(logPath, []);
      const next = [
        {
          ...entry,
          at: new Date().toISOString(),
        },
        ...current,
      ].slice(0, 100);
      writeJson(logPath, next);
      return next[0];
    },

    recentLog(limit = 25) {
      return readJson(logPath, []).slice(0, limit);
    },
  };
}
