# KTRLBoy Alpha 1.3

Release version: `1.3.0-alpha`

## Highlights

- Imported the KTRL-native KTRLboy service foundation from `KTRLboy-Alpha-v1.3-Update.zip`.
- Added `companion/ktrlboy` as the service-owned update scope for KTRL integration.
- Added `/KTRLboy` and `/api/ktrlboy` service route implementation for KTRL hosts.
- Added service stores, command routing, timer engine, moderation engine, message pipeline, runtime control, platform readiness, token management, auth link foundation, and adapter manager stubs.
- Added `releases/ktrlboy-latest.json` so the GitHub repo can advertise the latest KTRLboy service update.
- Added a standalone consumer install page and dashboard panel for streamers to add KTRLBoy to their chat through provider authorization popups.
- Kept the existing standalone KTRLBoy launcher/dashboard source intact for local executable testing.

## Verification

- `npm.cmd run check`
- `npm.cmd run test:ktrl-service`
- `npm.cmd run test:streamer-auth`
- `npm.cmd run test:chat-commands`
- `npm.cmd run test:local`
- `dist\KTRLBoy\KTRLBoy.exe --self-test --no-browser`

## Notes

The v1.3 KTRL-native service is a foundation layer. Real Twitch, YouTube, and Kick production adapters are still marked as follow-up work in the imported handoff docs.
