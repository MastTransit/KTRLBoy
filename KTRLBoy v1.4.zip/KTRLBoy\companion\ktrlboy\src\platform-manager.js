﻿const {
  getConfig
} = require("./config");

const {
  getTokenProvider,
  listTokenProviders
} = require("./token-manager");

const PLATFORM_LABELS = {
  twitch: "Twitch",
  youtube: "YouTube Live",
  kick: "Kick"
};

function getPlatformConfig(providerId) {
  const config = getConfig();
  return config.platforms?.[providerId] || {};
}

function getPlatformStatus(providerId) {
  const config = getConfig();
  const platformConfig = getPlatformConfig(providerId);
  const token = getTokenProvider(providerId);

  const configuredTarget =
    Boolean(platformConfig.channel) ||
    Boolean(platformConfig.liveChatId);

  const enabled = platformConfig.enabled === true;
  const runtimeEnabled = config.runtimeEnabled === true;

  const ready =
    runtimeEnabled &&
    enabled &&
    configuredTarget &&
    token.configured === true;

  const missing = [];

  if (!runtimeEnabled) {
    missing.push("runtimeEnabled");
  }

  if (!enabled) {
    missing.push("platformEnabled");
  }

  if (!configuredTarget) {
    missing.push("channelOrLiveChatTarget");
  }

  if (!token.configured) {
    missing.push("tokens");
  }

  return {
    id: providerId,
    label: PLATFORM_LABELS[providerId] || providerId,
    enabled,
    runtimeEnabled,
    ready,
    connected: false,
    connectionState: ready ? "ready_not_connected" : "not_ready",
    missing,
    config: {
      channel: platformConfig.channel || "",
      liveChatId: platformConfig.liveChatId || ""
    },
    token,
    notes: ready
      ? "Platform has enough config to be connected when adapters are enabled."
      : "Platform is not ready yet."
  };
}

function listPlatformStatuses() {
  const providers = listTokenProviders().map((provider) => provider.id);
  const ids = Array.from(new Set(["twitch", "youtube", "kick", ...providers]));

  return ids.map(getPlatformStatus);
}

function getPlatformSummary() {
  const platforms = listPlatformStatuses();

  return {
    runtimeEnabled: getConfig().runtimeEnabled === true,
    total: platforms.length,
    ready: platforms.filter((platform) => platform.ready).length,
    enabled: platforms.filter((platform) => platform.enabled).length,
    connected: platforms.filter((platform) => platform.connected).length,
    platforms
  };
}

module.exports = {
  PLATFORM_LABELS,
  getPlatformStatus,
  listPlatformStatuses,
  getPlatformSummary
};
