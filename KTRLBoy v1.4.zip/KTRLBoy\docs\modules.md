# Modules

KTRLBoy modules are dashboard toggles for major bot areas. They let you pause a feature without deleting its configuration.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Modules` to turn bot areas on or off.

## Available Modules

- `commands`: Enables saved custom commands.
- `timers`: Enables scheduled timer messages.
- `spamFilters`: Enables automatic moderation filters.
- `modCommandManager`: Allows moderators to edit commands from chat with `!cmd`.

Module settings are stored in:

```text
.data/modules.json
```

## Chat Control

Moderators, broadcasters, and owners can toggle modules from chat:

```text
!module list
!module commands disable
!module commands enable
!module timers disable
!module spamFilters enable
```

The `!module` command stays available so moderators can recover a disabled area without opening the dashboard.
