import https from "node:https";

const baseUrl = process.argv[2] || "https://localhost:8791";

function get(pathname) {
  return new Promise((resolve, reject) => {
    const req = https.get(
      `${baseUrl}${pathname}`,
      { rejectUnauthorized: false, timeout: 2000 },
      (res) => {
        let body = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            reject(new Error(`${pathname} returned ${res.statusCode}: ${body}`));
            return;
          }
          resolve(body);
        });
      },
    );
    req.on("timeout", () => {
      req.destroy(new Error(`${pathname} timed out`));
    });
    req.on("error", reject);
  });
}

const health = JSON.parse(await get("/health"));
if (health.ok !== true || health.botName !== "KTRLBoy") {
  throw new Error("HTTPS health route did not return KTRLBoy ok status");
}

const status = JSON.parse(await get("/status"));
if (status.routes?.gui !== `${baseUrl}/` || status.routes?.status !== `${baseUrl}/status`) {
  throw new Error("HTTPS status route did not report HTTPS URLs");
}

const gui = await get("/");
if (!gui.includes("KTRLBoy Dashboard")) {
  throw new Error("HTTPS GUI did not render");
}

console.log(
  JSON.stringify(
    {
      health: "ok",
      guiUrl: `${baseUrl}/`,
      statusUrl: `${baseUrl}/status`,
    },
    null,
    2,
  ),
);

