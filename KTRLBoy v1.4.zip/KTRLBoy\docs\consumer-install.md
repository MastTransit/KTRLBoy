# Consumer Chat Install

KTRLBoy now includes a consumer-facing install page so streamers can add the bot to their own chat through a provider authorization popup.

## Local Install Page

Start KTRLBoy, then open:

```text
http://localhost:8790/install
```

The same page is available from the dashboard under `Consumer Login` with the `Open Install Page` button.

Each provider button starts a browser authorization flow:

```text
/auth/twitch/start?flow=browser&intent=consumer
/auth/youtube/start?flow=browser&intent=consumer
/auth/kick/start?flow=browser&intent=consumer
```

## Required Owner Setup

Before consumers can authorize, the app owner must save each provider Client ID in `Integrations`. This keeps the authorization flow client-side and avoids requiring a developer Client Secret in KTRLBoy.

For Twitch and YouTube, KTRLBoy captures the access token returned by the provider popup callback. Kick uses a PKCE callback because Kick returns an authorization code instead of a direct client-side token.

## Stored Installs

Consumer installs are stored locally at:

```text
.auth/consumers.json
```

The dashboard and `/api/consumers` return only public install status such as provider, account name, channel ID, scopes, and install time. Raw access tokens are not shown in the GUI or API status output.

## Managing Installs

Open `Consumer Login` in the dashboard to:

- add Twitch, YouTube, or Kick consumer chat installs
- view installed consumer channels
- remove a consumer channel install

Consumers must approve the provider authorization popup themselves. KTRLBoy does not collect account passwords.

