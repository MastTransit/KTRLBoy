﻿# KTRLboy Alpha v1.3

KTRLboy Alpha v1.3 is the KTRL-native chat bot service foundation rebuilt from KTRLboy v1.2.

## What this is

This is the standalone source handoff for KTRLboy as a KTRL built-in service.

KTRL consumes this service under:

companion/ktrlboy

## What works

- Native KTRLboy service module
- KTRL route: /KTRLboy
- KTRL API base: /api/ktrlboy
- Core JSON stores
- Command routing
- Timer engine
- Moderation engine
- Message pipeline
- Config foundation
- Redacted token/auth store
- Platform readiness
- Runtime control foundation
- Twitch OAuth foundation
- Twitch adapter stub
- Developer docs and smoke tests

## What does not work yet

- Real Twitch chat socket/API connection
- Real YouTube Live adapter
- Real Kick adapter
- Production command/timer/moderation editor UI

## Important rules

- Do not expose raw tokens in API responses.
- Do not write outside companion/ktrlboy.
- Do not bring back the old 3001 sidecar as the main runtime.
- Keep KTRLboy independently versioned from KTRL.
- Keep update packages scoped to companion/ktrlboy.

## Developer docs

Start with:

- docs/developer-handoff.md
- docs/adapter-api.md
- docs/api-smoke-tests.md
- docs/v1.3-dev-checkpoint.md

## Node check

Run:

npm run check
