import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".data");
const storePath = path.join(storeDir, "modules.json");

export const defaultModules = {
  commands: {
    label: "Custom Commands",
    description: "Viewer-triggered custom responses.",
    enabled: true,
  },
  timers: {
    label: "Timers",
    description: "Scheduled chat messages gated by chat activity.",
    enabled: true,
  },
  spamFilters: {
    label: "Spam Filters",
    description: "Automatic moderation for links, caps, repeats, and spam.",
    enabled: true,
  },
  modCommandManager: {
    label: "Moderator Command Manager",
    description: "Let chat moderators add, edit, enable, and delete commands from chat.",
    enabled: true,
  },
};

function readStore() {
  if (!fs.existsSync(storePath)) return {};

  try {
    return JSON.parse(fs.readFileSync(storePath, "utf8"));
  } catch {
    return {};
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function normalizeModule(key, value) {
  const defaults = defaultModules[key];
  const source = typeof value === "object" && value !== null ? value : { enabled: value };

  return {
    ...defaults,
    enabled: source.enabled === undefined ? defaults.enabled : Boolean(source.enabled),
    updatedAt: source.updatedAt || new Date().toISOString(),
  };
}

function normalizeSettings(input) {
  const source = input?.modules || input || {};
  const settings = {};

  for (const key of Object.keys(defaultModules)) {
    settings[key] = normalizeModule(key, source[key]);
  }

  return settings;
}

export function createModuleStore() {
  return {
    getSettings() {
      return normalizeSettings(readStore());
    },

    isEnabled(name) {
      return this.getSettings()[name]?.enabled !== false;
    },

    updateSettings(input) {
      const current = this.getSettings();
      const updates = input?.modules || input || {};
      const next = {};

      for (const key of Object.keys(defaultModules)) {
        next[key] = normalizeModule(key, {
          ...current[key],
          ...(typeof updates[key] === "object" && updates[key] !== null
            ? updates[key]
            : updates[key] === undefined
              ? {}
              : { enabled: updates[key] }),
          updatedAt: new Date().toISOString(),
        });
      }

      writeStore(next);
      return next;
    },
  };
}
