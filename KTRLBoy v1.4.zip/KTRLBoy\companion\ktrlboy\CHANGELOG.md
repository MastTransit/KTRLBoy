﻿# KTRLboy Changelog

---

## KTRLboy Alpha v1.3

### Added
- Rebuilt KTRLboy as a KTRL-native service foundation.
- Added native service module structure.
- Added core stores for commands, timers, modules, moderation, and tokens.
- Added command router.
- Added timer engine.
- Added moderation engine.
- Added message pipeline.
- Added config foundation.
- Added redacted token/auth store.
- Added platform readiness.
- Added runtime control foundation.
- Added Twitch OAuth foundation.
- Added Twitch adapter stub.
- Added developer handoff docs.
- Added API smoke tests.

### Changed
- KTRLboy is now designed to run under KTRL instead of as a user-facing 3001 sidecar.
- KTRLboy keeps independent versioning and independent update scope.
- Updates should only touch companion/ktrlboy.

### Notes
- Real platform adapters are not production-complete yet.
- Twitch adapter stub defines the contract for the next developer pass.
- Raw token values must remain redacted from API/UI responses.
