import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".data");
const storePath = path.join(storeDir, "commands.json");
const commandNamePattern = /^[a-z0-9][a-z0-9_-]{0,31}$/;

function readStore() {
  if (!fs.existsSync(storePath)) return { commands: [] };

  try {
    const data = JSON.parse(fs.readFileSync(storePath, "utf8"));
    return {
      commands: Array.isArray(data.commands) ? data.commands : [],
    };
  } catch {
    return { commands: [] };
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function normalizeCommand(input) {
  const name = String(input.name || "")
    .trim()
    .replace(/^!+/, "")
    .toLowerCase();
  const response = String(input.response || "").trim();

  if (!commandNamePattern.test(name)) {
    throw new Error("Command names must be 1-32 characters: lowercase letters, numbers, dashes, or underscores.");
  }

  if (!response) {
    throw new Error("Command response is required.");
  }

  if (response.length > 400) {
    throw new Error("Command response must be 400 characters or less.");
  }

  return {
    name,
    response,
    enabled: input.enabled !== false,
    updatedAt: new Date().toISOString(),
  };
}

export function createCommandStore({ reservedNames = [] } = {}) {
  const reserved = new Set(reservedNames.map((name) => name.toLowerCase()));

  function list() {
    return readStore().commands.sort((a, b) => a.name.localeCompare(b.name));
  }

  function get(name) {
    const normalized = String(name || "").trim().replace(/^!+/, "").toLowerCase();
    return list().find((command) => command.name === normalized) || null;
  }

  function upsert(input) {
    const command = normalizeCommand(input);
    if (reserved.has(command.name)) {
      throw new Error(`"${command.name}" is a built-in command and cannot be replaced.`);
    }

    const data = readStore();
    const existing = data.commands.findIndex((item) => item.name === command.name);
    if (existing === -1) {
      data.commands.push({
        ...command,
        createdAt: command.updatedAt,
      });
    } else {
      data.commands[existing] = {
        ...data.commands[existing],
        ...command,
      };
    }

    writeStore(data);
    return get(command.name);
  }

  function remove(name) {
    const normalized = String(name || "").trim().replace(/^!+/, "").toLowerCase();
    const data = readStore();
    const next = data.commands.filter((command) => command.name !== normalized);
    const removed = next.length !== data.commands.length;
    writeStore({ commands: next });
    return removed;
  }

  return {
    get,
    list,
    remove,
    upsert,
  };
}
