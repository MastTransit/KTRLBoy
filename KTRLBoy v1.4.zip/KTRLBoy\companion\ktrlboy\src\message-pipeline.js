﻿const {
  routeMessage
} = require("./command-router");

const {
  checkAndLogMessage
} = require("./moderation-engine");

function processMessage(input = {}) {
  const platform = input.platform || "local";
  const user = input.user || "local-user";
  const message = String(input.message || "");

  const moderation = checkAndLogMessage({
    platform,
    user,
    message
  });

  if (moderation.enabled && !moderation.allowed) {
    return {
      platform,
      user,
      message,
      allowed: false,
      blocked: true,
      moderation,
      command: null,
      response: null
    };
  }

  const command = routeMessage({
    platform,
    user,
    message
  });

  return {
    platform,
    user,
    message,
    allowed: true,
    blocked: false,
    moderation,
    command,
    response: command?.matched ? command.response : null
  };
}

module.exports = {
  processMessage
};
