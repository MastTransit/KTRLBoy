import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".auth");
const storePath = path.join(storeDir, "consumers.json");

function readStore() {
  if (!fs.existsSync(storePath)) return { installs: {} };

  try {
    return JSON.parse(fs.readFileSync(storePath, "utf8"));
  } catch {
    return { installs: {} };
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function publicInstall(record) {
  return {
    id: record.id,
    provider: record.provider,
    channelId: record.channelId || "",
    channelName: record.channelName || "",
    accountName: record.accountName || "",
    scopes: record.scopes || [],
    expiresAt: record.expiresAt || null,
    installedAt: record.installedAt || null,
    updatedAt: record.updatedAt || null,
    metadata: record.metadata || {},
  };
}

function installId(provider, metadata = {}) {
  const channel =
    metadata.channelId ||
    metadata.userId ||
    metadata.channelSlug ||
    metadata.username ||
    metadata.channelTitle ||
    "unknown";
  return `${provider}:${String(channel).toLowerCase()}`;
}

export function createConsumerStore() {
  return {
    list() {
      const data = readStore();
      return Object.values(data.installs || {}).map(publicInstall);
    },

    set(provider, record) {
      const data = readStore();
      const metadata = record.metadata || {};
      const id = record.id || installId(provider, metadata);
      const previous = data.installs?.[id] || {};
      const install = {
        ...previous,
        ...record,
        id,
        provider,
        channelId: metadata.channelId || metadata.userId || previous.channelId || "",
        channelName:
          metadata.channelTitle ||
          metadata.channelSlug ||
          metadata.username ||
          previous.channelName ||
          "",
        accountName:
          metadata.displayName ||
          metadata.username ||
          metadata.channelTitle ||
          metadata.channelSlug ||
          previous.accountName ||
          "",
        installedAt: previous.installedAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      writeStore({
        ...data,
        installs: {
          ...(data.installs || {}),
          [id]: install,
        },
      });

      return publicInstall(install);
    },

    remove(id) {
      const data = readStore();
      if (!data.installs?.[id]) return false;
      const installs = { ...data.installs };
      delete installs[id];
      writeStore({ ...data, installs });
      return true;
    },

    status() {
      return {
        count: this.list().length,
        installs: this.list(),
      };
    },
  };
}
