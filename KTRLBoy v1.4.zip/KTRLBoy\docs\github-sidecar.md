# Running KTRLBoy Alongside a GitHub Project

Use KTRLBoy as a sidecar when you want the stream bot to run next to an existing app without mixing bot credentials or chat code into that app.

## Recommended Folder Layout

```text
projects/
  your-github-project/
  ktrlboy-chat-bot/
```

This keeps the bot independently runnable while still placing it beside the project you collaborate on.

## Option A: Separate Clone

Use this when the GitHub project should stay clean and you only need the bot running nearby.

```powershell
cd path\to\projects
git clone <collaborator-project-url> your-github-project
git clone <ktrlboy-repo-url> ktrlboy-chat-bot
cd ktrlboy-chat-bot
copy .env.example .env
npm.cmd run check
npm.cmd start
```

## Option B: Git Submodule

Use this if the main project should remember the exact bot version.

```powershell
cd path\to\your-github-project
git submodule add <ktrlboy-repo-url> tools/ktrlboy-chat-bot
git commit -m "Add KTRLBoy chat bot sidecar"
```

Team members can then fetch it with:

```powershell
git submodule update --init --recursive
```

## Option C: Docker Compose Sidecar

Use this if the main GitHub project already runs with Docker Compose.

Copy the `ktrlboy` service from `compose.example.yml` into the project compose file, or run it from this folder:

```powershell
copy .env.example .env
docker compose -f compose.example.yml up --build
```

If Kick webhooks are enabled, expose the webhook URL:

```text
http://localhost:8787/kick/webhook
```

For live webhooks, use a public tunnel or your deployment URL.

## Secrets

Do not commit `.env`. Keep platform tokens in:

- local `.env` for development
- GitHub Actions repository secrets for CI/CD
- your host's secret manager for deployment

## Best Default

Start with Option A. It is the cleanest fit when you are a collaborator and may not own the main repository's structure.
