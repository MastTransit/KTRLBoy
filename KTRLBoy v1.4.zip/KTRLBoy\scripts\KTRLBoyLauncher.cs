using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;

public static class KTRLBoyLauncher
{
    private static Process childProcess;

    public static int Main(string[] args)
    {
        bool noBrowser = HasArg(args, "--no-browser");
        bool selfTest = HasArg(args, "--self-test");
        string appRoot = FindAppRoot();
        string indexPath = Path.Combine(appRoot, "src", "index.js");

        if (!File.Exists(indexPath))
        {
            Console.Error.WriteLine("KTRLBoy could not find src\\index.js next to the executable.");
            Console.Error.WriteLine("Expected: " + indexPath);
            return 1;
        }

        string host = Environment.GetEnvironmentVariable("LAUNCHER_STATUS_HOST");
        string port = Environment.GetEnvironmentVariable("LAUNCHER_STATUS_PORT");
        string protocol = Environment.GetEnvironmentVariable("LAUNCHER_STATUS_PROTOCOL");
        string httpsEnabled = Environment.GetEnvironmentVariable("LAUNCHER_STATUS_HTTPS_ENABLED");
        string allowSelfSigned = Environment.GetEnvironmentVariable("LAUNCHER_STATUS_ALLOW_SELF_SIGNED");

        if (String.IsNullOrWhiteSpace(host)) host = "localhost";
        if (String.IsNullOrWhiteSpace(port)) port = "8790";
        if (String.IsNullOrWhiteSpace(protocol))
        {
            protocol = IsTruthy(httpsEnabled) ? "https" : "http";
        }
        protocol = protocol.Trim().ToLowerInvariant() == "https" ? "https" : "http";

        if (protocol == "https")
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            if (IsTruthy(allowSelfSigned))
            {
                ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            }
        }

        string guiUrl = protocol + "://" + host + ":" + port + "/";
        string healthUrl = protocol + "://" + host + ":" + port + "/health";

        Console.WriteLine("Starting KTRLBoy from " + appRoot);
        Console.WriteLine("GUI: " + guiUrl);

        ProcessStartInfo startInfo = new ProcessStartInfo();
        startInfo.FileName = "node";
        startInfo.Arguments = Quote(indexPath);
        startInfo.WorkingDirectory = appRoot;
        startInfo.UseShellExecute = false;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;
        startInfo.CreateNoWindow = false;
        SetDefault("LAUNCHER_STATUS_ENABLED", "true");
        SetDefault("LAUNCHER_STATUS_PROTOCOL", protocol);
        SetDefault("LAUNCHER_STATUS_HOST", host);
        SetDefault("LAUNCHER_STATUS_PORT", port);
        SetDefault("OAUTH_REDIRECT_BASE_URL", guiUrl.TrimEnd('/'));

        try
        {
            childProcess = Process.Start(startInfo);
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("Could not start Node.js. Make sure Node is installed and available on PATH.");
            Console.Error.WriteLine(error.Message);
            return 1;
        }

        Console.CancelKeyPress += delegate
        {
            StopChild();
        };

        childProcess.OutputDataReceived += delegate(object sender, DataReceivedEventArgs eventArgs)
        {
            if (eventArgs.Data != null) Console.WriteLine(eventArgs.Data);
        };
        childProcess.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs eventArgs)
        {
            if (eventArgs.Data != null) Console.Error.WriteLine(eventArgs.Data);
        };
        childProcess.BeginOutputReadLine();
        childProcess.BeginErrorReadLine();

        if (WaitForHealth(healthUrl, 10000))
        {
            Console.WriteLine("KTRLBoy is healthy.");
            if (!noBrowser && !selfTest)
            {
                OpenBrowser(guiUrl);
            }
        }
        else
        {
            Console.Error.WriteLine("KTRLBoy did not report healthy at " + healthUrl);
            StopChild();
            return 1;
        }

        if (selfTest)
        {
            if (!UrlContains(guiUrl, "KTRLBoy Dashboard"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: GUI page did not render.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/auth/status", "twitch"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: auth status route did not respond.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/api/commands", "builtIn"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: command API route did not respond.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/api/moderation", "settings"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: moderation API route did not respond.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/api/timers", "timers"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: timer API route did not respond.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/api/modules", "commands"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: modules API route did not respond.");
                return 1;
            }

            if (!UrlContains(protocol + "://" + host + ":" + port + "/api/authorizations", "authorizationEndpoint"))
            {
                StopChild();
                Console.Error.WriteLine("Executable self-test failed: authorization catalog route did not respond.");
                return 1;
            }

            StopChild();
            Console.WriteLine("Executable self-test passed.");
            return 0;
        }

        childProcess.WaitForExit();
        return childProcess.ExitCode;
    }

    private static string FindAppRoot()
    {
        string baseDir = AppDomain.CurrentDomain.BaseDirectory;
        if (Directory.Exists(Path.Combine(baseDir, "src"))) return baseDir;

        DirectoryInfo current = new DirectoryInfo(baseDir);
        while (current.Parent != null)
        {
            current = current.Parent;
            if (Directory.Exists(Path.Combine(current.FullName, "src"))) return current.FullName;
        }

        return baseDir;
    }

    private static bool HasArg(string[] args, string expected)
    {
        for (int i = 0; i < args.Length; i++)
        {
            if (String.Equals(args[i], expected, StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    private static string Quote(string value)
    {
        return "\"" + value.Replace("\"", "\\\"") + "\"";
    }

    private static void SetDefault(string name, string value)
    {
        string existing = Environment.GetEnvironmentVariable(name);
        if (String.IsNullOrWhiteSpace(existing))
        {
            Environment.SetEnvironmentVariable(name, value);
        }
    }

    private static bool IsTruthy(string value)
    {
        if (String.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim().ToLowerInvariant();
        return value == "1" || value == "true" || value == "yes" || value == "on";
    }

    private static bool WaitForHealth(string healthUrl, int timeoutMs)
    {
        Stopwatch watch = Stopwatch.StartNew();
        while (watch.ElapsedMilliseconds < timeoutMs)
        {
            if (childProcess.HasExited) return false;

            if (healthUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                if (NodeUrlContains(healthUrl, "KTRLBoy")) return true;
                Thread.Sleep(250);
                continue;
            }

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(healthUrl);
                request.Timeout = 1000;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if ((int)response.StatusCode >= 200 && (int)response.StatusCode < 300)
                    {
                        return true;
                    }
                }
            }
            catch
            {
                Thread.Sleep(250);
            }
        }
        return false;
    }

    private static void OpenBrowser(string url)
    {
        try
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = url;
            startInfo.UseShellExecute = true;
            Process.Start(startInfo);
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("Could not open browser automatically: " + error.Message);
            Console.Error.WriteLine("Open this URL manually: " + url);
        }
    }

    private static bool UrlContains(string url, string expected)
    {
        if (url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            return NodeUrlContains(url, expected);
        }

        try
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Timeout = 2000;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                string body = reader.ReadToEnd();
                return body.IndexOf(expected, StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }
        catch
        {
            return false;
        }
    }

    private static bool NodeUrlContains(string url, string expected)
    {
        try
        {
            string code =
                "const https=require('https');" +
                "const url=process.argv[1], expected=process.argv[2];" +
                "https.get(url,{rejectUnauthorized:false,timeout:2000},res=>{" +
                "let body='';res.setEncoding('utf8');" +
                "res.on('data',chunk=>body+=chunk);" +
                "res.on('end',()=>process.exit(body.toLowerCase().includes(expected.toLowerCase())?0:1));" +
                "}).on('error',()=>process.exit(1)).on('timeout',function(){this.destroy();process.exit(1);});";

            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "node";
            startInfo.Arguments = "-e " + Quote(code) + " " + Quote(url) + " " + Quote(expected);
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            using (Process process = Process.Start(startInfo))
            {
                if (!process.WaitForExit(3000))
                {
                    try { process.Kill(); } catch {}
                    return false;
                }
                return process.ExitCode == 0;
            }
        }
        catch
        {
            return false;
        }
    }

    private static void StopChild()
    {
        try
        {
            if (childProcess != null && !childProcess.HasExited)
            {
                childProcess.Kill();
                childProcess.WaitForExit(3000);
            }
        }
        catch
        {
        }
    }
}
