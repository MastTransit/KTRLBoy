const YOUTUBE_API = "https://www.googleapis.com/youtube/v3/liveChat/messages";
const YOUTUBE_BANS_API = "https://www.googleapis.com/youtube/v3/liveChat/bans";

function textFromItem(item) {
  return item.snippet?.textMessageDetails?.messageText || item.snippet?.displayMessage || "";
}

export function createYouTubeAdapter(config, router, logger) {
  let nextPageToken = "";
  let timer;

  async function accessToken() {
    return (await config.getAccessToken?.()) || config.accessToken;
  }

  function requireConfig() {
    const missing = [];
    if (!config.accessToken) missing.push("YOUTUBE_ACCESS_TOKEN");
    if (!config.liveChatId) missing.push("YOUTUBE_LIVE_CHAT_ID");
    if (missing.length) {
      throw new Error(`YouTube is enabled but missing ${missing.join(", ")}`);
    }
  }

  async function apiRequest(url, options = {}) {
    const token = await accessToken();
    const response = await fetch(url, {
      ...options,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "Content-Type": "application/json",
        ...options.headers,
      },
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`YouTube API ${response.status}: ${body}`);
    }

    if (response.status === 204) return {};
    return response.json();
  }

  async function reply(message) {
    await apiRequest(`${YOUTUBE_API}?part=snippet`, {
      method: "POST",
      body: JSON.stringify({
        snippet: {
          liveChatId: config.liveChatId,
          type: "textMessageEvent",
          textMessageDetails: {
            messageText: message,
          },
        },
      }),
    });
  }

  async function poll() {
    const url = new URL(YOUTUBE_API);
    url.searchParams.set("liveChatId", config.liveChatId);
    url.searchParams.set("part", "snippet,authorDetails");
    if (nextPageToken) url.searchParams.set("pageToken", nextPageToken);

    const data = await apiRequest(url);
    nextPageToken = data.nextPageToken || nextPageToken;

    for (const item of data.items || []) {
      const text = textFromItem(item);
      if (!text) continue;

      const message = {
        platform: "youtube",
        channel: config.liveChatId,
        messageId: item.id,
        user: {
          id: item.authorDetails?.channelId,
          name: item.authorDetails?.displayName,
          displayName: item.authorDetails?.displayName,
          isModerator: item.authorDetails?.isChatModerator,
          isOwner: item.authorDetails?.isChatOwner,
        },
        text,
        raw: item,
      };

      logger.info(`[youtube] ${message.user.displayName}: ${message.text}`);
      const moderationActions = {
        async deleteMessage(ctx) {
          if (!ctx.messageId) throw new Error("YouTube message ID was not available");
          const url = new URL(YOUTUBE_API);
          url.searchParams.set("id", ctx.messageId);
          await apiRequest(url, { method: "DELETE" });
        },

        async timeoutUser(ctx, duration, reasons) {
          if (!ctx.user?.id) throw new Error("YouTube channel ID was not available");
          await apiRequest(`${YOUTUBE_BANS_API}?part=snippet`, {
            method: "POST",
            body: JSON.stringify({
              snippet: {
                liveChatId: config.liveChatId,
                type: "temporary",
                banDurationSeconds: duration,
                bannedUserDetails: {
                  channelId: ctx.user.id,
                },
              },
            }),
          });
        },

        async banUser(ctx) {
          if (!ctx.user?.id) throw new Error("YouTube channel ID was not available");
          await apiRequest(`${YOUTUBE_BANS_API}?part=snippet`, {
            method: "POST",
            body: JSON.stringify({
              snippet: {
                liveChatId: config.liveChatId,
                type: "permanent",
                bannedUserDetails: {
                  channelId: ctx.user.id,
                },
              },
            }),
          });
        },
      };

      await router.handleMessage({ ...message, reply, moderationActions });
    }

    const interval = data.pollingIntervalMillis || config.pollIntervalMs;
    timer = setTimeout(() => poll().catch(handlePollError), interval);
  }

  function handlePollError(error) {
    logger.error("[youtube] poll error", error);
    timer = setTimeout(() => poll().catch(handlePollError), config.pollIntervalMs);
  }

  function start() {
    requireConfig();
    logger.info("[youtube] polling live chat");
    poll().catch(handlePollError);
  }

  return {
    platform: "youtube",
    start,
    stop: () => clearTimeout(timer),
    sendMessage: reply,
  };
}
