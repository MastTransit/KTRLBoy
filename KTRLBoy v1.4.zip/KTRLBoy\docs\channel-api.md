# Channel API Connection

KTRLBoy exposes a streamer-facing Channel API layer for Twitch, YouTube, and Kick. It uses the connected streamer/platform account token first, then falls back to manual environment tokens only when no streamer account has been connected.

## GUI Flow

1. Run `npm.cmd run gui`.
2. Open `http://localhost:8790/`.
3. Go to `Channel API`.
4. If the provider says `Save Setup First`, go to `Integrations`, enter the provider Client ID and scopes, then save the Client Authorization card.
5. Choose `Connect` for Twitch, YouTube, or Kick.
6. Complete the provider login in the browser.
7. Use `Sync` to pull the latest channel profile.
8. Use `Refresh` to renew a stored token when the provider supports refresh tokens.
9. For YouTube, use `Find Chat` while the stream is live to discover the active `liveChatId`.

## Local API

The launcher or another local tool can inspect channel connection state with:

```text
GET http://127.0.0.1:8790/api/channel-api
```

The response includes each provider's connection state, access source, account name, channel name, channel ID, scopes, missing setup values, and action paths.

Action endpoints:

```text
GET /api/oauth-settings
PUT /api/oauth-settings
POST /api/channel-api/twitch/sync
POST /api/channel-api/twitch/refresh
POST /api/channel-api/youtube/sync
POST /api/channel-api/youtube/refresh
POST /api/channel-api/youtube/discover-chat
POST /api/channel-api/kick/sync
POST /api/channel-api/kick/refresh
```

`connected` means a streamer account token is stored. `chatReady` means KTRLBoy has enough account/channel data to attempt chat access for that provider.

## Token Priority

Stored streamer account tokens are preferred over these manual fallback values:

```env
TWITCH_OAUTH_TOKEN=oauth:...
YOUTUBE_ACCESS_TOKEN=...
KICK_ACCESS_TOKEN=...
```

The fallback values remain useful for quick testing, but the Channel API panel is built around browser-popup streamer authorization.
