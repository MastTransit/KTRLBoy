import tls from "node:tls";

const TWITCH_IRC_HOST = "irc.chat.twitch.tv";
const TWITCH_IRC_PORT = 6697;

function parseTags(rawTags = "") {
  const tags = {};
  for (const pair of rawTags.split(";")) {
    const [key, value = ""] = pair.split("=");
    tags[key] = value;
  }
  return tags;
}

function parsePrivmsg(line) {
  const match = line.match(/^(?:@([^ ]+) )?:(\S+)!\S+ PRIVMSG #(\S+) :(.+)$/);
  if (!match) return null;

  const [, rawTags, username, channel, text] = match;
  const tags = parseTags(rawTags);
  return {
    platform: "twitch",
    channel,
    broadcasterId: tags["room-id"],
    messageId: tags.id,
    user: {
      id: tags["user-id"],
      name: username,
      displayName: tags["display-name"] || username,
      badges: tags.badges || "",
    },
    text,
    raw: line,
  };
}

export function createTwitchAdapter(config, router, logger) {
  let socket;
  let buffer = "";
  let stopped = false;

  function requireConfig() {
    const missing = [];
    if (!config.username) missing.push("TWITCH_BOT_USERNAME");
    if (!config.oauthToken) missing.push("TWITCH_OAUTH_TOKEN");
    if (!config.channel) missing.push("TWITCH_CHANNEL");
    if (missing.length) {
      throw new Error(`Twitch is enabled but missing ${missing.join(", ")}`);
    }
  }

  function sendRaw(message) {
    if (!socket || socket.destroyed) {
      throw new Error("Twitch socket is not connected");
    }
    socket.write(`${message}\r\n`);
  }

  function reply(message) {
    sendRaw(`PRIVMSG #${config.channel.toLowerCase()} :${message}`);
  }

  async function accessToken() {
    const token = (await config.getAccessToken?.()) || config.oauthToken;
    return String(token || "").replace(/^oauth:/, "");
  }

  async function twitchApi(url, options = {}) {
    const token = await accessToken();
    const response = await fetch(url, {
      ...options,
      headers: {
        Authorization: `Bearer ${token}`,
        "Client-Id": config.clientId,
        "Content-Type": "application/json",
        ...options.headers,
      },
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Twitch API ${response.status}: ${body}`);
    }
  }

  function moderationIds(ctx) {
    const broadcasterId = config.broadcasterId || ctx.broadcasterId;
    const moderatorId = config.moderatorUserId;
    if (!config.clientId) throw new Error("TWITCH_CLIENT_ID is required for moderation actions");
    if (!broadcasterId) throw new Error("Twitch broadcaster ID was not available");
    if (!moderatorId) throw new Error("TWITCH_MODERATOR_USER_ID is required for moderation actions");
    return { broadcasterId, moderatorId };
  }

  const moderationActions = {
    async deleteMessage(ctx) {
      const { broadcasterId, moderatorId } = moderationIds(ctx);
      if (!ctx.messageId) throw new Error("Twitch message ID was not available");

      const url = new URL("https://api.twitch.tv/helix/moderation/chat");
      url.searchParams.set("broadcaster_id", broadcasterId);
      url.searchParams.set("moderator_id", moderatorId);
      url.searchParams.set("message_id", ctx.messageId);
      await twitchApi(url, { method: "DELETE" });
    },

    async timeoutUser(ctx, duration, reasons) {
      const { broadcasterId, moderatorId } = moderationIds(ctx);
      if (!ctx.user?.id) throw new Error("Twitch user ID was not available");

      const url = new URL("https://api.twitch.tv/helix/moderation/bans");
      url.searchParams.set("broadcaster_id", broadcasterId);
      url.searchParams.set("moderator_id", moderatorId);
      await twitchApi(url, {
        method: "POST",
        body: JSON.stringify({
          data: {
            user_id: ctx.user.id,
            duration,
            reason: `KTRLBoy: ${reasons.join(", ")}`.slice(0, 500),
          },
        }),
      });
    },

    async banUser(ctx, reasons) {
      const { broadcasterId, moderatorId } = moderationIds(ctx);
      if (!ctx.user?.id) throw new Error("Twitch user ID was not available");

      const url = new URL("https://api.twitch.tv/helix/moderation/bans");
      url.searchParams.set("broadcaster_id", broadcasterId);
      url.searchParams.set("moderator_id", moderatorId);
      await twitchApi(url, {
        method: "POST",
        body: JSON.stringify({
          data: {
            user_id: ctx.user.id,
            reason: `KTRLBoy: ${reasons.join(", ")}`.slice(0, 500),
          },
        }),
      });
    },
  };

  async function handleLine(line) {
    if (line.startsWith("PING")) {
      sendRaw("PONG :tmi.twitch.tv");
      return;
    }

    const message = parsePrivmsg(line);
    if (!message) return;

    logger.info(`[twitch] ${message.user.displayName}: ${message.text}`);
      await router.handleMessage({
        ...message,
        reply,
        moderationActions,
      });
  }

  function connect() {
    stopped = false;
    requireConfig();

    socket = tls.connect(TWITCH_IRC_PORT, TWITCH_IRC_HOST, () => {
      logger.info("[twitch] connected");
      sendRaw("CAP REQ :twitch.tv/tags twitch.tv/commands");
      sendRaw(`PASS ${config.oauthToken}`);
      sendRaw(`NICK ${config.username}`);
      sendRaw(`JOIN #${config.channel.toLowerCase()}`);
    });

    socket.setEncoding("utf8");

    socket.on("data", (chunk) => {
      buffer += chunk;
      const lines = buffer.split("\r\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        handleLine(line).catch((error) => logger.error("[twitch] message error", error));
      }
    });

    socket.on("error", (error) => logger.error("[twitch] socket error", error));
    socket.on("close", () => {
      if (stopped) return;
      logger.warn("[twitch] disconnected; reconnecting in 10 seconds");
      setTimeout(connect, 10000);
    });
  }

  function stop() {
    stopped = true;
    socket?.end();
  }

  return {
    platform: "twitch",
    start: connect,
    stop,
    sendMessage: reply,
  };
}
