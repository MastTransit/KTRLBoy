import { applyStoredAuth } from "../src/config.js";

const records = {
  twitch: {
    accessToken: "streamer-twitch-token",
    metadata: {
      username: "ktrlboy",
      channelSlug: "streamer-channel",
      userId: "streamer-user-id",
    },
  },
  youtube: {
    accessToken: "streamer-youtube-token",
    metadata: {
      liveChatId: "streamer-live-chat-id",
    },
  },
  kick: {
    accessToken: "streamer-kick-token",
    metadata: {
      userId: "12345",
    },
  },
};

const config = {
  twitch: {
    channel: "",
    username: "env-bot",
    oauthToken: "oauth:env-token",
    moderatorUserId: "env-moderator",
    authSource: "manual-env",
  },
  youtube: {
    accessToken: "env-youtube-token",
    liveChatId: "",
    authSource: "manual-env",
  },
  kick: {
    accessToken: "env-kick-token",
    broadcasterUserId: "",
    authSource: "manual-env",
  },
};

applyStoredAuth(config, {
  get(provider) {
    return records[provider] || null;
  },
});

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(config.twitch.oauthToken === "oauth:streamer-twitch-token", "Twitch did not prefer streamer token");
assert(config.twitch.username === "ktrlboy", "Twitch did not prefer streamer username");
assert(config.twitch.channel === "streamer-channel", "Twitch channel was not discovered");
assert(config.twitch.moderatorUserId === "streamer-user-id", "Twitch moderator ID did not prefer streamer account");
assert(config.twitch.authSource === "streamer-account", "Twitch auth source was not streamer account");

assert(config.youtube.accessToken === "streamer-youtube-token", "YouTube did not prefer streamer token");
assert(config.youtube.liveChatId === "streamer-live-chat-id", "YouTube live chat ID was not discovered");
assert(config.youtube.authSource === "streamer-account", "YouTube auth source was not streamer account");

assert(config.kick.accessToken === "streamer-kick-token", "Kick did not prefer streamer token");
assert(config.kick.broadcasterUserId === "12345", "Kick broadcaster ID was not discovered");
assert(config.kick.authSource === "streamer-account", "Kick auth source was not streamer account");

console.log("streamer auth priority smoke test passed");
