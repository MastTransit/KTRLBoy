import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".auth");
const storePath = path.join(storeDir, "tokens.json");

function readStore() {
  if (!fs.existsSync(storePath)) return {};

  try {
    return JSON.parse(fs.readFileSync(storePath, "utf8"));
  } catch {
    return {};
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

export function isExpired(record, skewMs = 60000) {
  if (!record?.expiresAt) return false;
  return Date.parse(record.expiresAt) <= Date.now() + skewMs;
}

export function tokenPublicStatus(record) {
  if (!record?.accessToken) {
    return {
      connected: false,
      expired: false,
      expiresAt: null,
      scopes: [],
      metadata: {},
    };
  }

  return {
    connected: true,
    expired: isExpired(record, 0),
    expiresAt: record.expiresAt || null,
    scopes: record.scopes || [],
    metadata: record.metadata || {},
    updatedAt: record.updatedAt || null,
  };
}

export function createTokenStore() {
  return {
    get(provider) {
      return readStore()[provider] || null;
    },

    set(provider, record) {
      const data = readStore();
      data[provider] = {
        ...record,
        provider,
        updatedAt: new Date().toISOString(),
      };
      writeStore(data);
      return data[provider];
    },

    clear(provider) {
      const data = readStore();
      delete data[provider];
      writeStore(data);
    },

    status() {
      const data = readStore();
      return {
        twitch: tokenPublicStatus(data.twitch),
        youtube: tokenPublicStatus(data.youtube),
        kick: tokenPublicStatus(data.kick),
      };
    },
  };
}
