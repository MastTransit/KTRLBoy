﻿const {
  readStore,
  writeStore
} = require("./stores");

function normalizeTimer(timer) {
  const intervalSeconds = Number(timer.intervalSeconds || timer.interval || 300);

  return {
    id: timer.id || timer.name || `timer-${Date.now()}`,
    name: timer.name || timer.id || "Timer",
    message: timer.message || timer.response || "",
    enabled: timer.enabled !== false,
    intervalSeconds: Number.isFinite(intervalSeconds) && intervalSeconds > 0 ? intervalSeconds : 300,
    nextRunAt: timer.nextRunAt || null,
    lastRunAt: timer.lastRunAt || null
  };
}

function getTimerItems() {
  const store = readStore("timers");
  const items = Array.isArray(store.items) ? store.items : [];

  return items.map(normalizeTimer);
}

function getDueTimers(now = new Date()) {
  const nowTime = now.getTime();

  return getTimerItems().filter((timer) => {
    if (!timer.enabled) return false;
    if (!timer.message) return false;

    if (!timer.nextRunAt) {
      return true;
    }

    const nextRunTime = new Date(timer.nextRunAt).getTime();

    if (!Number.isFinite(nextRunTime)) {
      return true;
    }

    return nextRunTime <= nowTime;
  });
}

function tickTimers(now = new Date()) {
  const store = readStore("timers");
  const originalItems = Array.isArray(store.items) ? store.items : [];
  const due = getDueTimers(now);
  const dueIds = new Set(due.map((timer) => timer.id));

  const updatedItems = originalItems.map((timer) => {
    const normalized = normalizeTimer(timer);

    if (!dueIds.has(normalized.id)) {
      return timer;
    }

    const nextRunAt = new Date(now.getTime() + normalized.intervalSeconds * 1000).toISOString();

    return {
      ...timer,
      id: normalized.id,
      name: normalized.name,
      message: normalized.message,
      enabled: normalized.enabled,
      intervalSeconds: normalized.intervalSeconds,
      lastRunAt: now.toISOString(),
      nextRunAt
    };
  });

  const updatedStore = {
    ...store,
    items: updatedItems,
    updatedAt: now.toISOString()
  };

  writeStore("timers", updatedStore);

  return {
    ranAt: now.toISOString(),
    due,
    responses: due.map((timer) => ({
      id: timer.id,
      name: timer.name,
      message: timer.message
    })),
    timers: readStore("timers")
  };
}

module.exports = {
  normalizeTimer,
  getTimerItems,
  getDueTimers,
  tickTimers
};
