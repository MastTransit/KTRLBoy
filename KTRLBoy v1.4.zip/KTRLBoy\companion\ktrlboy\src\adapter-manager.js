﻿const {
  getRuntimeStatus
} = require("./runtime-manager");

const {
  getPlatformStatus,
  getPlatformSummary
} = require("./platform-manager");

const {
  processMessage
} = require("./message-pipeline");

const ADAPTER_STATE = {
  twitch: {
    id: "twitch",
    label: "Twitch",
    started: false,
    connected: false,
    connectionState: "stopped",
    startedAt: null,
    stoppedAt: null,
    lastMessageAt: null,
    lastResult: null
  },
  youtube: {
    id: "youtube",
    label: "YouTube Live",
    started: false,
    connected: false,
    connectionState: "stub_only",
    startedAt: null,
    stoppedAt: null,
    lastMessageAt: null,
    lastResult: null
  },
  kick: {
    id: "kick",
    label: "Kick",
    started: false,
    connected: false,
    connectionState: "stub_only",
    startedAt: null,
    stoppedAt: null,
    lastMessageAt: null,
    lastResult: null
  }
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function getAdapterState(providerId) {
  const state = ADAPTER_STATE[providerId];

  if (!state) {
    throw new Error(`Unknown KTRLboy adapter: ${providerId}`);
  }

  const platform = getPlatformStatus(providerId);

  return {
    ...clone(state),
    platform,
    ready: platform.ready === true,
    canStart: platform.ready === true,
    notes: [
      "This is the KTRLboy v1.3 adapter contract stub.",
      "It does not open a real platform socket/API connection yet.",
      "Messages can be tested through the local KTRLboy message pipeline."
    ]
  };
}

function listAdapters() {
  return {
    runtime: getRuntimeStatus(),
    platformSummary: getPlatformSummary(),
    adapters: Object.keys(ADAPTER_STATE).map(getAdapterState)
  };
}

function startAdapter(providerId) {
  const state = ADAPTER_STATE[providerId];

  if (!state) {
    throw new Error(`Unknown KTRLboy adapter: ${providerId}`);
  }

  const platform = getPlatformStatus(providerId);

  state.started = true;
  state.connected = false;
  state.connectionState = platform.ready ? "ready_stub_started" : "started_not_ready";
  state.startedAt = new Date().toISOString();

  return getAdapterState(providerId);
}

function stopAdapter(providerId) {
  const state = ADAPTER_STATE[providerId];

  if (!state) {
    throw new Error(`Unknown KTRLboy adapter: ${providerId}`);
  }

  state.started = false;
  state.connected = false;
  state.connectionState = "stopped";
  state.stoppedAt = new Date().toISOString();

  return getAdapterState(providerId);
}

function testAdapterMessage(providerId, input = {}) {
  const state = ADAPTER_STATE[providerId];

  if (!state) {
    throw new Error(`Unknown KTRLboy adapter: ${providerId}`);
  }

  const result = processMessage({
    platform: providerId,
    user: input.user || "adapter-test-user",
    message: input.message || ""
  });

  state.lastMessageAt = new Date().toISOString();
  state.lastResult = result;

  return {
    adapter: getAdapterState(providerId),
    result
  };
}

module.exports = {
  listAdapters,
  getAdapterState,
  startAdapter,
  stopAdapter,
  testAdapterMessage
};
