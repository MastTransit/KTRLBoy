﻿# KTRLboy Adapter API

This document describes the adapter contract introduced in KTRLboy Alpha v1.3-dev.

## Purpose

Adapters are the bridge between external chat platforms and the internal KTRLboy message pipeline.

The current adapter implementation is a stub contract. It does not connect to live Twitch, YouTube, or Kick chat yet.

## Adapter routes

List adapters:

GET /api/ktrlboy/adapters

Get one adapter:

GET /api/ktrlboy/adapters/:providerId

Start adapter:

POST /api/ktrlboy/adapters/:providerId/start

Stop adapter:

POST /api/ktrlboy/adapters/:providerId/stop

Test message:

POST /api/ktrlboy/adapters/:providerId/test-message

## Provider IDs

Supported IDs:

- twitch
- youtube
- kick

## Test message body

{
  "user": "Kody",
  "message": "!test"
}

## Test message result

The adapter test message should call the internal KTRLboy message pipeline.

Pipeline:

1. Moderation check.
2. If allowed, command route.
3. Return response if matched.

## Adapter state shape

Adapters should return:

- id
- label
- started
- connected
- connectionState
- startedAt
- stoppedAt
- lastMessageAt
- lastResult
- platform
- ready
- canStart
- notes

## Twitch v1.3-dev behavior

The Twitch adapter stub:

- Can start.
- Can stop.
- Can process local test messages.
- Does not connect to Twitch chat yet.
- Reports platform readiness using the platform manager.
- Keeps last result for debugging.

## Real adapter implementation notes

When the real Twitch adapter is added, it should:

- Use the existing token-manager for tokens.
- Use platform-manager for readiness.
- Use runtime-manager for runtime state.
- Send incoming chat messages through message-pipeline.
- Send command responses back to Twitch chat.
- Never expose raw tokens.
- Never write outside companion/ktrlboy.
