﻿const {
  readStore,
  writeStore
} = require("./stores");

const KNOWN_PROVIDERS = ["twitch", "youtube", "kick"];

function getTokenStore() {
  const store = readStore("tokens");

  return {
    schemaVersion: store.schemaVersion || 1,
    providers: store.providers || {},
    notes: store.notes || "KTRLboy token data. Placeholder only. Do not commit real tokens."
  };
}

function redactProvider(providerId, provider = {}) {
  const hasAccessToken = Boolean(provider.accessToken);
  const hasRefreshToken = Boolean(provider.refreshToken);
  const hasClientId = Boolean(provider.clientId);

  return {
    id: providerId,
    configured: hasAccessToken || hasRefreshToken || hasClientId,
    hasAccessToken,
    hasRefreshToken,
    hasClientId,
    expiresAt: provider.expiresAt || null,
    updatedAt: provider.updatedAt || null,
    scopes: Array.isArray(provider.scopes) ? provider.scopes : []
  };
}

function listTokenProviders() {
  const store = getTokenStore();
  const providerIds = Array.from(new Set([
    ...KNOWN_PROVIDERS,
    ...Object.keys(store.providers || {})
  ]));

  return providerIds.map((providerId) => {
    return redactProvider(providerId, store.providers?.[providerId] || {});
  });
}

function getTokenProvider(providerId) {
  const store = getTokenStore();
  return redactProvider(providerId, store.providers?.[providerId] || {});
}

function getTokenProviderRaw(providerId) {
  const store = getTokenStore();
  return store.providers?.[providerId] || {};
}

function setTokenProvider(providerId, payload = {}) {
  if (!providerId) {
    throw new Error("Provider id is required.");
  }

  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new Error("Token payload must be an object.");
  }

  const store = getTokenStore();
  const existing = store.providers?.[providerId] || {};

  const allowed = {
    accessToken: Object.prototype.hasOwnProperty.call(payload, "accessToken") ? payload.accessToken || "" : existing.accessToken || "",
    refreshToken: Object.prototype.hasOwnProperty.call(payload, "refreshToken") ? payload.refreshToken || "" : existing.refreshToken || "",
    clientId: Object.prototype.hasOwnProperty.call(payload, "clientId") ? payload.clientId || "" : existing.clientId || "",
    expiresAt: Object.prototype.hasOwnProperty.call(payload, "expiresAt") ? payload.expiresAt || null : existing.expiresAt || null,
    scopes: Array.isArray(payload.scopes) ? payload.scopes : Array.isArray(existing.scopes) ? existing.scopes : [],
    updatedAt: new Date().toISOString()
  };

  const updated = {
    ...store,
    providers: {
      ...(store.providers || {}),
      [providerId]: {
        ...existing,
        ...allowed
      }
    },
    updatedAt: new Date().toISOString()
  };

  writeStore("tokens", updated);

  return getTokenProvider(providerId);
}

function clearTokenProvider(providerId) {
  if (!providerId) {
    throw new Error("Provider id is required.");
  }

  const store = getTokenStore();
  const providers = {
    ...(store.providers || {})
  };

  delete providers[providerId];

  writeStore("tokens", {
    ...store,
    providers,
    updatedAt: new Date().toISOString()
  });

  return getTokenProvider(providerId);
}

module.exports = {
  KNOWN_PROVIDERS,
  listTokenProviders,
  getTokenProvider,
  setTokenProvider,
  clearTokenProvider,
  getTokenProviderRaw
};


