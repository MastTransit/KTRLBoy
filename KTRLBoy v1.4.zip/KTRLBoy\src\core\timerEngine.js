function renderTemplate(template, values) {
  return String(template || "").replace(/\{([a-zA-Z0-9_]+)\}/g, (match, key) =>
    Object.prototype.hasOwnProperty.call(values, key) ? values[key] : match,
  );
}

export function createTimerEngine(timerStore, moduleStore, logger, options = {}) {
  let interval;
  let sendTargets = [];
  let lineCounter = 0;
  const lastSentAt = new Map();
  const lastLineCount = new Map();
  const messageIndexes = new Map();

  function timersEnabled() {
    return moduleStore?.isEnabled?.("timers") !== false;
  }

  function recordMessage() {
    lineCounter += 1;
  }

  function selectMessage(timer) {
    const messages = timer.messages || [timer.message].filter(Boolean);
    const currentIndex = messageIndexes.get(timer.name) || 0;
    const message = messages[currentIndex % messages.length];
    messageIndexes.set(timer.name, currentIndex + 1);
    return message;
  }

  function isDue(timer, now) {
    const intervalMs = timer.intervalMinutes * 60 * 1000;
    const previousSentAt = lastSentAt.get(timer.name) || 0;
    const previousLineCount = lastLineCount.get(timer.name) || 0;
    return now - previousSentAt >= intervalMs && lineCounter - previousLineCount >= timer.chatLines;
  }

  async function tick() {
    if (!timersEnabled() || sendTargets.length === 0) return;

    const now = Date.now();
    for (const timer of timerStore.list().filter((item) => item.enabled)) {
      if (!isDue(timer, now)) continue;

      const message = renderTemplate(selectMessage(timer), {
        bot: options.botName || "KTRLBoy",
        channel: options.channel || "",
        platform: "all",
        prefix: options.commandPrefix || "!",
      });
      let sent = 0;

      for (const target of sendTargets) {
        try {
          await target.sendMessage(message, timer);
          sent += 1;
        } catch (error) {
          logger.warn(
            `[timers] ${timer.name} failed on ${target.platform || "adapter"}: ${
              error instanceof Error ? error.message : String(error)
            }`,
          );
        }
      }

      if (sent > 0) {
        lastSentAt.set(timer.name, now);
        lastLineCount.set(timer.name, lineCounter);
        logger.info(`[timers] ${timer.name} sent to ${sent} adapter${sent === 1 ? "" : "s"}`);
      }
    }
  }

  function start(adapters = []) {
    stop();
    sendTargets = adapters.filter((adapter) => typeof adapter.sendMessage === "function");
    interval = setInterval(() => tick().catch((error) => logger.error("[timers] tick failed", error)), 15000);
    interval.unref?.();
  }

  function stop() {
    if (interval) clearInterval(interval);
    interval = null;
    sendTargets = [];
  }

  return {
    recordMessage,
    start,
    stop,
    tick,
  };
}
