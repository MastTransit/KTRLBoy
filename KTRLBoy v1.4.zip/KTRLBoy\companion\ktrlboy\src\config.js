﻿const fs = require("fs");
const path = require("path");

const SERVICE_ROOT = path.resolve(__dirname, "..");
const CONFIG_ROOT = path.join(SERVICE_ROOT, "config");
const CONFIG_PATH = path.join(CONFIG_ROOT, "ktrlboy.config.json");

const DEFAULT_CONFIG = {
  schemaVersion: 1,
  botName: "KTRLboy",
  commandPrefix: "!",
  runtimeEnabled: false,
  platforms: {
    twitch: {
      enabled: false,
      channel: "",
      clientId: "",
      redirectUri: "http://localhost:3000/api/ktrlboy/auth/twitch/callback",
      scopes: [
        "chat:read",
        "chat:edit"
      ]
    },
    youtube: {
      enabled: false,
      liveChatId: ""
    },
    kick: {
      enabled: false,
      channel: ""
    }
  },
  ui: {
    theme: "ktrl",
    showDevTools: true
  },
  notes: "KTRLboy config is owned by KTRL. Tokens are stored separately and redacted."
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function ensureConfigRoot() {
  fs.mkdirSync(CONFIG_ROOT, {
    recursive: true
  });
}

function readJsonSafe(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return clone(fallback);
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return clone(fallback);
  }
}

function writeJson(filePath, value) {
  ensureConfigRoot();
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + "\n", "utf8");
}

function normalizeConfig(value = {}) {
  return {
    ...clone(DEFAULT_CONFIG),
    ...value,
    platforms: {
      ...clone(DEFAULT_CONFIG.platforms),
      ...(value.platforms || {}),
      twitch: {
        ...clone(DEFAULT_CONFIG.platforms.twitch),
        ...(value.platforms?.twitch || {}),
        scopes: Array.isArray(value.platforms?.twitch?.scopes)
          ? value.platforms.twitch.scopes
          : clone(DEFAULT_CONFIG.platforms.twitch.scopes)
      },
      youtube: {
        ...clone(DEFAULT_CONFIG.platforms.youtube),
        ...(value.platforms?.youtube || {})
      },
      kick: {
        ...clone(DEFAULT_CONFIG.platforms.kick),
        ...(value.platforms?.kick || {})
      }
    },
    ui: {
      ...clone(DEFAULT_CONFIG.ui),
      ...(value.ui || {})
    }
  };
}

function ensureConfig() {
  ensureConfigRoot();

  if (!fs.existsSync(CONFIG_PATH)) {
    writeJson(CONFIG_PATH, DEFAULT_CONFIG);
  }

  return CONFIG_PATH;
}

function getConfig() {
  ensureConfig();
  return normalizeConfig(readJsonSafe(CONFIG_PATH, DEFAULT_CONFIG));
}

function updateConfig(patch = {}) {
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
    throw new Error("Config payload must be an object.");
  }

  const current = getConfig();
  const updated = normalizeConfig({
    ...current,
    ...patch,
    platforms: {
      ...current.platforms,
      ...(patch.platforms || {}),
      twitch: {
        ...current.platforms.twitch,
        ...(patch.platforms?.twitch || {}),
        scopes: Array.isArray(patch.platforms?.twitch?.scopes)
          ? patch.platforms.twitch.scopes
          : current.platforms.twitch.scopes
      },
      youtube: {
        ...current.platforms.youtube,
        ...(patch.platforms?.youtube || {})
      },
      kick: {
        ...current.platforms.kick,
        ...(patch.platforms?.kick || {})
      }
    },
    ui: {
      ...current.ui,
      ...(patch.ui || {})
    },
    updatedAt: new Date().toISOString()
  });

  writeJson(CONFIG_PATH, updated);
  return getConfig();
}

function resetConfig() {
  writeJson(CONFIG_PATH, {
    ...clone(DEFAULT_CONFIG),
    resetAt: new Date().toISOString()
  });

  return getConfig();
}

module.exports = {
  CONFIG_ROOT,
  CONFIG_PATH,
  DEFAULT_CONFIG,
  getConfig,
  updateConfig,
  resetConfig
};

