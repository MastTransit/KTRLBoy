# Spam Filters

KTRLBoy can moderate chat with StreamElements-style spam filters and provider actions.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Spam Filters` to tune rules.

The Spam Filters screen uses buttons for the common parameters: action mode, toggles, timeout presets, and numeric step controls.

## Default Mode

Moderation starts in `dryRun` mode. In dry run, KTRLBoy logs what it would have done without deleting, timing out, or banning anyone.

Turn off `Dry run` only after you have confirmed the rules behave the way you want.

## Rules

KTRLBoy can flag:

- blocked terms
- links when links are disabled
- excessive caps
- repeated characters
- rapid message spam

The GUI stores settings in:

```text
.data/moderation.json
```

Recent moderation events are stored in:

```text
.data/moderation-log.json
```

## Actions

Available actions:

- `Warn only`
- `Delete message`
- `Timeout repeat offenders`
- `Ban repeat offenders`

Moderators, owners, and broadcasters are ignored by default.

## Platform Support

Twitch:

- Deletes messages through Twitch Helix `Delete Chat Messages`.
- Times out or bans users through Twitch Helix `Ban User`.
- Requires OAuth scopes:

```text
chat:read chat:edit moderator:manage:chat_messages moderator:manage:banned_users
```

YouTube:

- Deletes messages through `liveChatMessages.delete`.
- Times out or bans users through `liveChatBans.insert`.
- Uses the existing `youtube.force-ssl` scope.

Kick:

- Warns are supported through chat replies.
- Kick public API moderation endpoints are limited in this starter.
- Chat-command moderation is available only if you set:

```env
KICK_ALLOW_CHAT_COMMAND_MODERATION=true
```

That fallback sends commands such as `/timeout` and `/ban` through chat, so the logged-in Kick account must have moderator permissions.
