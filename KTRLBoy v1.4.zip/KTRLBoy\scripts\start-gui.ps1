$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")

if (-not $env:LAUNCHER_STATUS_ENABLED) {
  $env:LAUNCHER_STATUS_ENABLED = "true"
}

if (-not $env:LAUNCHER_STATUS_HOST) {
  $env:LAUNCHER_STATUS_HOST = "localhost"
}

if (-not $env:LAUNCHER_STATUS_PORT) {
  $env:LAUNCHER_STATUS_PORT = "8790"
}

$url = "http://$env:LAUNCHER_STATUS_HOST`:$env:LAUNCHER_STATUS_PORT/"
Write-Host "KTRLBoy GUI: $url"
Write-Host "Press Ctrl+C to stop KTRLBoy."

Set-Location $root
node src/index.js
