import fs from "node:fs";
import path from "node:path";

const storeDir = path.join(process.cwd(), ".data");
const storePath = path.join(storeDir, "authorizations.json");

const providerDefaults = {
  twitch: {
    label: "Twitch",
    sourceUrl: "https://dev.twitch.tv/docs/authentication/getting-tokens-oauth/",
    docsUrl: "https://dev.twitch.tv/docs/authentication/getting-tokens-oauth/",
    appUrl: "https://dev.twitch.tv/console/apps",
    authorizationEndpoint: "https://id.twitch.tv/oauth2/authorize",
    tokenEndpoint: "https://id.twitch.tv/oauth2/token",
    validateEndpoint: "https://id.twitch.tv/oauth2/validate",
  },
  youtube: {
    label: "YouTube",
    sourceUrl: "https://accounts.google.com/.well-known/openid-configuration",
    docsUrl: "https://developers.google.com/identity/protocols/oauth2/web-server",
    appUrl: "https://console.cloud.google.com/apis/credentials",
    apiLibraryUrl: "https://console.cloud.google.com/apis/library/youtube.googleapis.com",
    authorizationEndpoint: "https://accounts.google.com/o/oauth2/v2/auth",
    tokenEndpoint: "https://oauth2.googleapis.com/token",
    revokeEndpoint: "https://oauth2.googleapis.com/revoke",
  },
  kick: {
    label: "Kick",
    sourceUrl: "https://docs.kick.com/getting-started/generating-tokens-oauth2-flow",
    docsUrl: "https://docs.kick.com/getting-started/generating-tokens-oauth2-flow",
    appUrl: "https://kick.com/settings/developer",
    appSetupUrl: "https://docs.kick.com/getting-started/kick-apps-setup",
    authorizationEndpoint: "https://id.kick.com/oauth/authorize",
    tokenEndpoint: "https://id.kick.com/oauth/token",
    revokeEndpoint: "https://id.kick.com/oauth/revoke",
    introspectEndpoint: "https://id.kick.com/oauth/token/introspect",
  },
};

function readStore() {
  if (!fs.existsSync(storePath)) return null;

  try {
    return JSON.parse(fs.readFileSync(storePath, "utf8"));
  } catch {
    return null;
  }
}

function writeStore(data) {
  fs.mkdirSync(storeDir, { recursive: true });
  fs.writeFileSync(storePath, `${JSON.stringify(data, null, 2)}\n`, {
    mode: 0o600,
  });
}

function providerConfig(config, provider) {
  return config.oauth?.[provider] || {};
}

function providerSnapshot(config, provider, links) {
  const oauth = providerConfig(config, provider);
  const callbackUrl = `${config.oauth.redirectBaseUrl.replace(/\/$/, "")}/auth/${provider}/callback`;

  return {
    ...links,
    callbackUrl,
    scopes: oauth.scopes || [],
    clientConfigured: Boolean(oauth.clientId),
    connectPath: `/auth/${provider}/start?flow=browser`,
    localConnectPath: `/auth/${provider}/start?flow=local`,
    buttons: [
      {
        label: "Connect Streamer Account",
        kind: "primary",
        href: `/auth/${provider}/start?flow=browser`,
        enabled: Boolean(oauth.clientId),
      },
      {
        label: "Client Authorization Setup",
        kind: "external",
        href: links.appUrl || links.appSetupUrl || links.docsUrl,
        enabled: Boolean(links.appUrl || links.appSetupUrl || links.docsUrl),
      },
      {
        label: "Login Docs",
        kind: "external",
        href: links.docsUrl,
        enabled: Boolean(links.docsUrl),
      },
      {
        label: "Auth Endpoint",
        kind: "external",
        href: links.authorizationEndpoint,
        enabled: Boolean(links.authorizationEndpoint),
      },
    ],
  };
}

function defaultsForConfig(config) {
  return {
    updatedAt: null,
    source: "defaults",
    providers: Object.fromEntries(
      Object.entries(providerDefaults).map(([provider, links]) => [
        provider,
        providerSnapshot(config, provider, links),
      ]),
    ),
  };
}

async function fetchJson(url, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
    return response.json();
  } finally {
    clearTimeout(timer);
  }
}

async function checkUrl(url, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: "GET",
      signal: controller.signal,
    });
    return {
      ok: response.ok,
      status: response.status,
    };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    };
  } finally {
    clearTimeout(timer);
  }
}

export function createAuthorizationCatalog(config, logger) {
  function getCatalog() {
    const stored = readStore();
    if (!stored?.providers) return defaultsForConfig(config);

    return {
      ...defaultsForConfig(config),
      ...stored,
      providers: Object.fromEntries(
        Object.entries(providerDefaults).map(([provider, defaults]) => [
          provider,
          providerSnapshot(config, provider, {
            ...defaults,
            ...(stored.providers?.[provider] || {}),
          }),
        ]),
      ),
    };
  }

  async function refresh() {
    const catalog = defaultsForConfig(config);
    const results = {};

    try {
      const googleDiscovery = await fetchJson(providerDefaults.youtube.sourceUrl);
      catalog.providers.youtube = providerSnapshot(config, "youtube", {
        ...catalog.providers.youtube,
        authorizationEndpoint:
          googleDiscovery.authorization_endpoint ||
          catalog.providers.youtube.authorizationEndpoint,
        tokenEndpoint: googleDiscovery.token_endpoint || catalog.providers.youtube.tokenEndpoint,
        revokeEndpoint: googleDiscovery.revocation_endpoint || catalog.providers.youtube.revokeEndpoint,
        issuer: googleDiscovery.issuer,
      });
      results.youtube = { ok: true, source: providerDefaults.youtube.sourceUrl };
    } catch (error) {
      results.youtube = {
        ok: false,
        source: providerDefaults.youtube.sourceUrl,
        error: error instanceof Error ? error.message : String(error),
      };
      logger.warn("[auth-links] YouTube discovery refresh failed", results.youtube.error);
    }

    await Promise.all(
      ["twitch", "kick"].map(async (provider) => {
        const result = await checkUrl(providerDefaults[provider].sourceUrl);
        results[provider] = {
          ...result,
          source: providerDefaults[provider].sourceUrl,
        };
      }),
    );

    const refreshed = {
      ...catalog,
      updatedAt: new Date().toISOString(),
      source: "internet-refresh",
      refreshResults: results,
    };
    writeStore(refreshed);
    return refreshed;
  }

  return {
    getCatalog,
    refresh,
  };
}
