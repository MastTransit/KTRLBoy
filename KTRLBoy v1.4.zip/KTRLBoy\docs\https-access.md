# HTTPS Access

KTRLBoy can serve its local GUI, launcher API, install page, and OAuth callbacks over HTTPS.

HTTP remains the default for local-only testing. Turn on HTTPS when you need browser-secure access, a public reverse proxy, or provider callback URLs that require HTTPS.

## Local Self-Signed Test

Generate a local certificate and private key:

```powershell
npm.cmd run cert:https
```

This creates:

```text
.certs/ktrlboy-localhost.crt
.certs/ktrlboy-localhost.pfx
```

Then set:

```env
LAUNCHER_STATUS_ENABLED=true
LAUNCHER_STATUS_PROTOCOL=https
LAUNCHER_STATUS_HOST=localhost
LAUNCHER_STATUS_PORT=8790
LAUNCHER_STATUS_HTTPS_PFX_PATH=.certs/ktrlboy-localhost.pfx
LAUNCHER_STATUS_HTTPS_PFX_PASSPHRASE=ktrlboy-local
OAUTH_REDIRECT_BASE_URL=https://localhost:8790
```

For executable self-tests with the local self-signed certificate, also set:

```env
LAUNCHER_STATUS_ALLOW_SELF_SIGNED=true
```

Browsers will still warn about a self-signed certificate unless it is trusted on the machine.

## Real HTTPS

For real internet-facing access, put KTRLBoy behind a trusted HTTPS endpoint such as a reverse proxy, tunnel, or hosted launcher domain. Use certificate files issued for that hostname, then set:

```env
LAUNCHER_STATUS_PROTOCOL=https
LAUNCHER_STATUS_HOST=0.0.0.0
LAUNCHER_STATUS_PORT=8790
LAUNCHER_STATUS_HTTPS_CERT_PATH=C:\path\to\fullchain.pem
LAUNCHER_STATUS_HTTPS_KEY_PATH=C:\path\to\privkey.pem
OAUTH_REDIRECT_BASE_URL=https://your-domain.example
```

KTRLBoy also accepts a PFX bundle with:

```env
LAUNCHER_STATUS_HTTPS_PFX_PATH=C:\path\to\certificate.pfx
LAUNCHER_STATUS_HTTPS_PFX_PASSPHRASE=your-pfx-password
```

Add matching callback URLs in Twitch, YouTube, and Kick:

```text
https://your-domain.example/auth/twitch/callback
https://your-domain.example/auth/youtube/callback
https://your-domain.example/auth/kick/callback
```

## Verify

Run:

```powershell
npm.cmd run test:https
```

The test starts KTRLBoy on `https://localhost:8791`, verifies `/health`, `/status`, and the GUI, then stops the server.
