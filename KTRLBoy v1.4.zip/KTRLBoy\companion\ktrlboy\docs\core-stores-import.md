﻿# KTRLboy Core Stores Import

This is the first KTRL-native rebuild chunk from KTRLboy v1.2.

## Imported logic direction

The original KTRLboy v1.2 store modules are represented by new KTRL-owned JSON stores:

- commandStore -> companion/ktrlboy/data/commands.json
- timerStore -> companion/ktrlboy/data/timers.json
- moduleStore -> companion/ktrlboy/data/modules.json
- moderationStore -> companion/ktrlboy/data/moderation.json
- tokenStore -> companion/ktrlboy/data/tokens.json

## Current API

Read-only endpoints:

- /api/ktrlboy/data
- /api/ktrlboy/stores
- /api/ktrlboy/commands
- /api/ktrlboy/timers
- /api/ktrlboy/modules
- /api/ktrlboy/moderation

## Rules

- Runtime bot adapters are still disabled.
- Write/edit APIs come after read APIs are verified.
- Token data is redacted in snapshots.
- KTRLboy update scope remains companion/ktrlboy only.
