# KTRLBoy Alpha 1.2

Release version: `1.2.0-alpha.1`

## Highlights

- Added the KTRLBoy GUI dashboard with StreamElements-inspired controls.
- Added Twitch, YouTube, and Kick streamer account login flows through browser OAuth.
- Added in-app authorization setup cards for saving provider Client ID and scopes to `.env`.
- Added the Channel API panel and `/api/channel-api` endpoint for streamer channel connection state.
- Added command editing, timer editing, spam filter moderation, and module controls.
- Added chat moderator command management through `!cmd`.
- Added KTRLBoy icon and black/red/silver visual theme from the provided artwork.
- Added Windows executable packaging and desktop zip output.

## Verification

- `npm.cmd run check`
- `npm.cmd run test:streamer-auth`
- `npm.cmd run test:chat-commands`
- `npm.cmd run test:local`
- `dist\KTRLBoy\KTRLBoy.exe --self-test --no-browser`

## Notes

Provider Client ID values are used to start client-side authorization popups. KTRLBoy uses the connected streamer/platform account token as the primary chat and Channel API authorization.
