$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$distRoot = Join-Path $root "dist"
$appDir = Join-Path $distRoot "KTRLBoy"
$exePath = Join-Path $appDir "KTRLBoy.exe"
$sourcePath = Join-Path $PSScriptRoot "KTRLBoyLauncher.cs"
$iconPath = Join-Path $root "src\gui\assets\KTRLBoy.ico"

if (Test-Path $appDir) {
  Remove-Item -LiteralPath $appDir -Recurse -Force
}

New-Item -ItemType Directory -Force -Path $appDir | Out-Null

Copy-Item -LiteralPath (Join-Path $root "src") -Destination (Join-Path $appDir "src") -Recurse -Force
Copy-Item -LiteralPath (Join-Path $root "docs") -Destination (Join-Path $appDir "docs") -Recurse -Force
Copy-Item -LiteralPath (Join-Path $root "scripts") -Destination (Join-Path $appDir "scripts") -Recurse -Force
if (Test-Path (Join-Path $root "companion")) {
  Copy-Item -LiteralPath (Join-Path $root "companion") -Destination (Join-Path $appDir "companion") -Recurse -Force
}
if (Test-Path (Join-Path $root "releases")) {
  Copy-Item -LiteralPath (Join-Path $root "releases") -Destination (Join-Path $appDir "releases") -Recurse -Force
}
Copy-Item -LiteralPath (Join-Path $root "package.json") -Destination $appDir -Force
Copy-Item -LiteralPath (Join-Path $root "README.md") -Destination $appDir -Force
Copy-Item -LiteralPath (Join-Path $root ".env.example") -Destination $appDir -Force

$cscCandidates = @(
  (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
  (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe")
)
$cscPath = $cscCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if ((Test-Path $iconPath) -and $cscPath) {
  & $cscPath /nologo /target:exe "/out:$exePath" "/win32icon:$iconPath" $sourcePath
  if ($LASTEXITCODE -ne 0) {
    throw "KTRLBoy launcher compile failed with exit code $LASTEXITCODE"
  }
} else {
  $source = Get-Content -LiteralPath $sourcePath -Raw
  Add-Type -TypeDefinition $source -OutputAssembly $exePath -OutputType ConsoleApplication
}

Get-Item -LiteralPath $exePath | Select-Object FullName, Length
