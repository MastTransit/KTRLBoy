# Executable Test

KTRLBoy can be built as a Windows `.exe` launcher for local testing.

Build it:

```powershell
npm.cmd run build:exe
```

The executable is created at:

```text
dist\KTRLBoy\KTRLBoy.exe
```

Run it from File Explorer or PowerShell:

```powershell
dist\KTRLBoy\KTRLBoy.exe
```

The executable starts KTRLBoy, serves the GUI, and opens:

```text
http://localhost:8790/
```

For automated testing without opening a browser:

```powershell
dist\KTRLBoy\KTRLBoy.exe --self-test --no-browser
```

This executable is a launcher wrapper. It still requires Node.js to be installed on the PC.
