﻿const {
  readStore,
  writeStore
} = require("./stores");

function normalizeSettings(settings = {}) {
  return {
    enabled: settings.enabled === true,
    blockLinks: settings.blockLinks === true,
    blockCaps: settings.blockCaps === true,
    blockRepeatedCharacters: settings.blockRepeatedCharacters === true,
    maxCapsPercent: Number(settings.maxCapsPercent || 75),
    minCapsLength: Number(settings.minCapsLength || 12),
    maxRepeatedCharacters: Number(settings.maxRepeatedCharacters || 8),
    blockedTerms: Array.isArray(settings.blockedTerms) ? settings.blockedTerms : []
  };
}

function getModerationSettings() {
  const store = readStore("moderation");
  return normalizeSettings(store.settings || {});
}

function containsLink(message) {
  return /(https?:\/\/|www\.|discord\.gg|\.com\b|\.net\b|\.org\b)/i.test(message);
}

function getCapsPercent(message) {
  const letters = message.replace(/[^a-z]/gi, "");
  if (!letters.length) return 0;

  const caps = letters.replace(/[^A-Z]/g, "");
  return Math.round((caps.length / letters.length) * 100);
}

function hasRepeatedCharacters(message, maxRepeatedCharacters) {
  const pattern = new RegExp(`(.)\\1{${Math.max(1, maxRepeatedCharacters)},}`, "i");
  return pattern.test(message);
}

function findBlockedTerms(message, blockedTerms) {
  const lower = String(message || "").toLowerCase();

  return blockedTerms
    .map((term) => String(term || "").trim())
    .filter(Boolean)
    .filter((term) => lower.includes(term.toLowerCase()));
}

function checkMessage(input = {}) {
  const message = String(input.message || "");
  const platform = input.platform || "local";
  const user = input.user || "local-user";
  const settings = getModerationSettings();

  const violations = [];

  if (!settings.enabled) {
    return {
      allowed: true,
      enabled: false,
      platform,
      user,
      message,
      violations: []
    };
  }

  const blockedTerms = findBlockedTerms(message, settings.blockedTerms);

  if (blockedTerms.length) {
    violations.push({
      type: "blocked_terms",
      terms: blockedTerms
    });
  }

  if (settings.blockLinks && containsLink(message)) {
    violations.push({
      type: "link"
    });
  }

  if (settings.blockCaps && message.length >= settings.minCapsLength) {
    const capsPercent = getCapsPercent(message);

    if (capsPercent >= settings.maxCapsPercent) {
      violations.push({
        type: "caps",
        capsPercent
      });
    }
  }

  if (
    settings.blockRepeatedCharacters &&
    hasRepeatedCharacters(message, settings.maxRepeatedCharacters)
  ) {
    violations.push({
      type: "repeated_characters",
      maxRepeatedCharacters: settings.maxRepeatedCharacters
    });
  }

  return {
    allowed: violations.length === 0,
    enabled: true,
    platform,
    user,
    message,
    violations
  };
}

function appendModerationLog(result) {
  const store = readStore("moderation");
  const log = Array.isArray(store.log) ? store.log : [];

  const entry = {
    id: `mod-${Date.now()}`,
    checkedAt: new Date().toISOString(),
    allowed: result.allowed,
    platform: result.platform,
    user: result.user,
    message: result.message,
    violations: result.violations || []
  };

  const updated = {
    ...store,
    log: [entry, ...log].slice(0, 250),
    updatedAt: new Date().toISOString()
  };

  writeStore("moderation", updated);

  return entry;
}

function checkAndLogMessage(input = {}) {
  const result = checkMessage(input);

  if (result.enabled && !result.allowed) {
    result.logEntry = appendModerationLog(result);
  }

  return result;
}

function clearModerationLog() {
  const store = readStore("moderation");

  const updated = {
    ...store,
    log: [],
    updatedAt: new Date().toISOString()
  };

  writeStore("moderation", updated);

  return readStore("moderation");
}

module.exports = {
  normalizeSettings,
  getModerationSettings,
  checkMessage,
  checkAndLogMessage,
  clearModerationLog
};
