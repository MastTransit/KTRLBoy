import http from "node:http";
import crypto from "node:crypto";

const KICK_CHAT_API = "https://api.kick.com/public/v1/chat";

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) {
        req.destroy(new Error("Request body too large"));
      }
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (error) {
        reject(error);
      }
    });
    req.on("error", reject);
  });
}

function timingSafeEqual(a, b) {
  const left = Buffer.from(a || "");
  const right = Buffer.from(b || "");
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function extractKickMessage(payload) {
  const data = payload.data || payload;
  const sender = data.sender || data.user || data.chatter || {};
  const message = data.message || {};
  const text = data.content || message.content || message.text || data.text || "";
  const badges = sender.badges || sender.identity?.badges || [];
  const roles = [
    ...(Array.isArray(badges) ? badges : []),
    sender.role,
    sender.user_type,
    sender.type,
  ]
    .filter(Boolean)
    .map((role) => String(role).toLowerCase());

  if (!text) return null;

  return {
    platform: "kick",
    channel: String(data.broadcaster_user_id || data.channel_id || ""),
    user: {
      id: sender.user_id || sender.id,
      name: sender.username || sender.name,
      displayName: sender.username || sender.name || "Kick viewer",
      isModerator: Boolean(
        sender.is_moderator ||
          sender.isModerator ||
          roles.includes("moderator") ||
          roles.includes("mod"),
      ),
      isBroadcaster: Boolean(
        sender.is_broadcaster ||
          sender.isBroadcaster ||
          roles.includes("broadcaster") ||
          roles.includes("streamer"),
      ),
      roles,
    },
    text,
    raw: payload,
  };
}

export function createKickAdapter(config, router, logger) {
  let server;

  async function accessToken() {
    return (await config.getAccessToken?.()) || config.accessToken;
  }

  function requireConfig() {
    if (!config.accessToken) {
      throw new Error("Kick is enabled but missing KICK_ACCESS_TOKEN");
    }
  }

  async function reply(message) {
    const body = {
      content: message,
      type: config.sendAs,
    };

    if (config.sendAs === "user" && config.broadcasterUserId) {
      body.broadcaster_user_id = Number(config.broadcasterUserId);
    }

    const response = await fetch(KICK_CHAT_API, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${await accessToken()}`,
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const responseBody = await response.text();
      throw new Error(`Kick API ${response.status}: ${responseBody}`);
    }
  }

  function chatCommandModeration() {
    if (!config.allowChatCommandModeration) {
      throw new Error("Kick chat-command moderation is disabled");
    }
  }

  const moderationActions = {
    async deleteMessage() {
      throw new Error("Kick public chat API does not expose message delete in this starter");
    },

    async timeoutUser(ctx, duration, reasons) {
      chatCommandModeration();
      const username = ctx.user?.name || ctx.user?.displayName;
      if (!username) throw new Error("Kick username was not available");
      await reply(`/timeout ${username} ${duration} KTRLBoy: ${reasons.join(", ")}`.slice(0, 450));
    },

    async banUser(ctx, reasons) {
      chatCommandModeration();
      const username = ctx.user?.name || ctx.user?.displayName;
      if (!username) throw new Error("Kick username was not available");
      await reply(`/ban ${username} KTRLBoy: ${reasons.join(", ")}`.slice(0, 450));
    },
  };

  async function handleWebhook(req, res) {
    if (req.method !== "POST" || req.url !== "/kick/webhook") {
      res.writeHead(404);
      res.end("Not found");
      return;
    }

    if (config.webhookSecret) {
      const provided = req.headers["x-bot-webhook-secret"];
      if (!timingSafeEqual(provided, config.webhookSecret)) {
        res.writeHead(401);
        res.end("Unauthorized");
        return;
      }
    }

    const payload = await readJson(req);
    const message = extractKickMessage(payload);

    if (message) {
      logger.info(`[kick] ${message.user.displayName}: ${message.text}`);
      await router.handleMessage({ ...message, reply, moderationActions });
    }

    res.writeHead(204);
    res.end();
  }

  function start() {
    requireConfig();

    server = http.createServer((req, res) => {
      handleWebhook(req, res).catch((error) => {
        logger.error("[kick] webhook error", error);
        res.writeHead(500);
        res.end("Internal server error");
      });
    });

    server.listen(config.webhookPort, () => {
      logger.info(`[kick] webhook listening on http://localhost:${config.webhookPort}/kick/webhook`);
    });
  }

  return {
    platform: "kick",
    start,
    stop: () => server?.close(),
    sendMessage: reply,
  };
}
