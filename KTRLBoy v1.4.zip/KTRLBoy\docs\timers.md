# Timers

KTRLBoy timers are recurring chat messages. They are modeled after the same practical pattern used by creator dashboards: a message, an interval, and a minimum chat-line requirement so the bot does not talk into an inactive chat.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Timers` to add, edit, disable, or delete timer messages.

## Timer Rules

- Names use lowercase letters, numbers, dashes, or underscores.
- Each timer can have up to 10 messages.
- Put one message per line to rotate timer responses.
- Messages are limited to 400 characters each.
- Intervals are stored in minutes.
- Required chat lines must be at least `1`.
- Timers are stored in `.data/timers.json`.

## Placeholders

Timer messages can use:

```text
{bot}
{prefix}
{platform}
{channel}
```

Example:

```text
Name: socials
Message: Follow the channel and use {prefix}help for commands.
Interval: 15
Required chat lines: 5
```

The timer engine starts after platform adapters start. It sends through every connected adapter that supports chat output.
