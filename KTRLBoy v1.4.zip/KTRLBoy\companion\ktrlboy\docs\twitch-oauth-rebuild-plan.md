﻿# Twitch OAuth/Auth Rebuild Plan

KTRLboy Alpha v1.3-dev will rebuild Twitch auth from the KTRLboy v1.2 source, but adapted to KTRL-native rules.

## Source files inspected

- companion/ktrlboy/_source-v1.2/src/core/oauthManager.js
- companion/ktrlboy/_source-v1.2/src/platforms/twitch.js
- companion/ktrlboy/_source-v1.2/src/config.js

## KTRL-native rules

- KTRL serves KTRLboy directly at /KTRLboy.
- KTRLboy auth APIs live under /api/ktrlboy/auth/twitch.
- Callback route should be /api/ktrlboy/auth/twitch/callback.
- Token values are stored in companion/ktrlboy/data/tokens.json.
- Token APIs must remain redacted.
- Twitch auth must not write outside companion/ktrlboy.
- Twitch adapter connection comes after OAuth works.
- No 3001 sidecar.

## Planned Twitch auth routes

- GET /api/ktrlboy/auth/twitch
- GET /api/ktrlboy/auth/twitch/start
- GET /api/ktrlboy/auth/twitch/callback
- POST /api/ktrlboy/tokens/twitch/clear

## Planned Twitch config fields

Stored in companion/ktrlboy/config/ktrlboy.config.json:

- platforms.twitch.enabled
- platforms.twitch.channel
- platforms.twitch.clientId
- platforms.twitch.redirectUri
- platforms.twitch.scopes

Client secret is not part of the KTRLBoy auth model. Streamers and consumers authorize through client-side provider popups with a Client ID, and Kick uses PKCE.

## Planned Twitch token fields

Stored in companion/ktrlboy/data/tokens.json under providers.twitch:

- accessToken
- refreshToken
- clientId
- expiresAt
- scopes
- updatedAt

API responses only expose booleans:

- hasAccessToken
- hasRefreshToken
- hasClientId
- configured

## oauthManager.js relevant lines

L2: import { isExpired, tokenPublicStatus } from "./tokenStore.js";
L4: const providerNames = ["twitch", "youtube", "kick"];
L39: function normalizeScopes(value, fallback = []) {
L48: function normalizeToken(provider, token, metadata, requestedScopes, previousRecord = null) {
L51: accessToken: token.access_token,
L52: refreshToken: token.refresh_token || previousRecord?.refreshToken || "",
L53: tokenType: token.token_type || previousRecord?.tokenType || "Bearer",
L54: expiresAt: expiresAt(token.expires_in) || previousRecord?.expiresAt || null,
L55: scopes: normalizeScopes(token.scope, requestedScopes),
L86: async function getJson(url, accessToken, label, authorizationPrefix = "Bearer", headers = {}) {
L89: Authorization: `${authorizationPrefix} ${accessToken}`,
L97: export function createOAuthManager(config, tokenStore, logger) {
L106: function redirectUri(provider) {
L107: return `${config.oauth.redirectBaseUrl.replace(/\/$/, "")}/auth/${provider}/callback`;
L113: if (!providerOauth.clientId) missing.push(`${provider.toUpperCase()}_CLIENT_ID`);
L114: client-side popup auth requires only the provider Client ID;
L135: const scopes = providerOauth.scopes || [];
L149: ? "https://id.kick.com/oauth/authorize"
L150: : "https://id.twitch.tv/oauth2/authorize",
L154: authUrl.searchParams.set("client_id", providerOauth.clientId);
L155: authUrl.searchParams.set("redirect_uri", redirectUri(provider));
L156: authUrl.searchParams.set("scope", scopes.join(" "));
L162: authUrl.searchParams.set("include_granted_scopes", "true");
L175: const scopes = providerOauth.scopes || [];
L177: if (provider === "twitch") {
L178: const token = await postForm(
L179: "https://id.twitch.tv/oauth2/token",
L181: client_id: providerOauth.clientId,
L182: no client_secret is used in the current KTRLBoy client-side popup flow,
L185: redirect_uri: redirectUri(provider),
L187: "Twitch token exchange failed",
L190: "https://id.twitch.tv/oauth2/validate",
L191: token.access_token,
L192: "Twitch token validation failed",
L195: const profile = await discoverTwitchMetadata(
L196: token.access_token,
L197: providerOauth.clientId,
L199: logger.warn("[twitch] login succeeded but profile discovery failed", error.message);
L202: return normalizeToken(
L204: token,
L211: validation.scopes || scopes,
L216: const token = await postForm(
L217: "https://oauth2.googleapis.com/token",
L219: client_id: providerOauth.clientId,
L220: no client_secret is used in the current KTRLBoy client-side popup flow,
L223: redirect_uri: redirectUri(provider),
L225: "YouTube token exchange failed",
L227: const metadata = await discoverYouTubeMetadata(token.access_token).catch((error) => {
L231: return normalizeToken(provider, token, metadata, scopes);
L235: const token = await postForm(
L236: "https://id.kick.com/oauth/token",
L238: client_id: providerOauth.clientId,
L239: code_verifier is used for PKCE instead of a client_secret,
L242: redirect_uri: redirectUri(provider),
L245: "Kick token exchange failed",
L247: const metadata = await discoverKickMetadata(token.access_token).catch((error) => {
L251: return normalizeToken(provider, token, metadata, scopes);
L257: async function handleCallback(provider, query) {
L270: if (!code) throw new Error("OAuth callback did not include an authorization code.");
L282: const saved = tokenStore.set(provider, record);
L283: return tokenPublicStatus(saved);
L286: async function refresh(provider) {
L289: const previousRecord = tokenStore.get(provider);
L290: if (!previousRecord?.refreshToken) {
L291: throw new Error(`${provider} does not have a refresh token yet`);
L295: const tokenUrl =
L297: ? "https://oauth2.googleapis.com/token"
L299: ? "https://id.kick.com/oauth/token"
L300: : "https://id.twitch.tv/oauth2/token";
L302: const token = await postForm(
L303: tokenUrl,
L305: client_id: providerOauth.clientId,
L306: client_secret: providerOauth.clientSecret,
L307: refresh_token: previousRecord.refreshToken,
L308: grant_type: "refresh_token",
L310: `${provider} refresh failed`,
L313: const saved = tokenStore.set(
L315: normalizeToken(provider, token, {}, providerOauth.scopes || [], previousRecord),
L318: return tokenPublicStatus(saved);
L321: async function refreshExpiredTokens() {
L323: const record = tokenStore.get(provider);
L324: if (!record?.accessToken || !isExpired(record)) continue;
L328: await refresh(provider);
L330: logger.warn(`[${provider}] stored token refresh failed`, error.message);
L335: async function accessToken(provider) {
L336: const record = tokenStore.get(provider);
L337: if (!record?.accessToken) return "";
L339: if (isExpired(record) && record.refreshToken && configured(provider)) {
L340: await refresh(provider);
L341: return tokenStore.get(provider)?.accessToken || "";
L344: return record.accessToken;
L348: const token = await accessToken("youtube");
L349: if (!token) throw new Error("YouTube is not connected");
L351: const metadata = await discoverYouTubeMetadata(token);
L352: const previousRecord = tokenStore.get("youtube");
L353: const saved = tokenStore.set("youtube", {
L360: return tokenPublicStatus(saved);
L366: const token = await accessToken(provider);
L367: if (!token) throw new Error(`${provider} is not connected`);
L370: if (provider === "twitch") {
L371: metadata = await discoverTwitchMetadata(token, providerConfig(provider).clientId);
L373: metadata = await discoverYouTubeMetadata(token);
L375: metadata = await discoverKickMetadata(token);
L380: const previousRecord = tokenStore.get(provider);
L381: const saved = tokenStore.set(provider, {
L389: return tokenPublicStatus(saved);
L395: const record = tokenStore.get(provider);
L396: if (!record?.accessToken || !configured(provider)) {
L397: results[provider] = tokenPublicStatus(record);
L405: results[provider] = tokenPublicStatus(record);
L412: const tokenStatus = tokenStore.status();
L418: redirectUri: redirectUri(provider),
L419: scopes: providerConfig(provider).scopes || [],
L422: ...tokenStatus[provider],
L429: tokenStore.clear(provider);
L433: accessToken,
L436: handleCallback,
L437: refresh,
L438: refreshExpiredTokens,
L446: async function discoverTwitchMetadata(accessToken, clientId) {
L448: "https://api.twitch.tv/helix/users",
L449: accessToken,
L450: "Twitch profile discovery failed",
L452: { "Client-Id": clientId },
L466: async function discoverYouTubeMetadata(accessToken) {
L478: getJson(channelUrl, accessToken, "YouTube channel discovery failed"),
L479: getJson(url, accessToken, "YouTube live broadcast discovery failed"),
L494: async function discoverKickMetadata(accessToken) {
L497: accessToken,

## twitch.js relevant lines

L3: const TWITCH_IRC_HOST = "irc.chat.twitch.tv";
L4: const TWITCH_IRC_PORT = 6697;
L19: const [, rawTags, username, channel, text] = match;
L23: channel,
L25: messageId: tags.id,
L45: if (!config.oauthToken) missing.push("TWITCH_OAUTH_TOKEN");
L46: if (!config.channel) missing.push("TWITCH_CHANNEL");
L52: function sendRaw(message) {
L54: throw new Error("Twitch socket is not connected");
L56: socket.write(`${message}\r\n`);
L59: function reply(message) {
L60: sendRaw(`PRIVMSG #${config.channel.toLowerCase()} :${message}`);
L63: async function accessToken() {
L64: const token = (await config.getAccessToken?.()) || config.oauthToken;
L65: return String(token || "").replace(/^oauth:/, "");
L69: const token = await accessToken();
L73: Authorization: `Bearer ${token}`,
L96: async deleteMessage(ctx) {
L98: if (!ctx.messageId) throw new Error("Twitch message ID was not available");
L100: const url = new URL("https://api.twitch.tv/helix/moderation/chat");
L103: url.searchParams.set("message_id", ctx.messageId);
L147: sendRaw("PONG :tmi.twitch.tv");
L151: const message = parsePrivmsg(line);
L152: if (!message) return;
L154: logger.info(`[twitch] ${message.user.displayName}: ${message.text}`);
L155: await router.handleMessage({
L156: ...message,
L162: function connect() {
L166: socket = tls.connect(TWITCH_IRC_PORT, TWITCH_IRC_HOST, () => {
L167: logger.info("[twitch] connected");
L168: sendRaw("CAP REQ :twitch.tv/tags twitch.tv/commands");
L169: sendRaw(`PASS ${config.oauthToken}`);
L170: sendRaw(`NICK ${config.username}`);
L171: sendRaw(`JOIN #${config.channel.toLowerCase()}`);
L182: handleLine(line).catch((error) => logger.error("[twitch] message error", error));
L189: logger.warn("[twitch] disconnected; reconnecting in 10 seconds");
L190: setTimeout(connect, 10000);
L201: start: connect,
L203: sendMessage: reply,

## config.js relevant lines

L51: function scopesFromEnv(name, fallback = []) {
L61: const twitch = tokenStore.get("twitch");
L62: if (twitch?.accessToken) {
L63: config.twitch.oauthToken = `oauth:${twitch.accessToken}`;
L64: config.twitch.username = twitch.metadata?.username || config.twitch.username || "";
L65: config.twitch.channel ||= twitch.metadata?.channelSlug || twitch.metadata?.username || "";
L66: config.twitch.moderatorUserId = twitch.metadata?.userId || config.twitch.moderatorUserId || "";
L67: config.twitch.authSource = "streamer-account";
L68: } else if (config.twitch.oauthToken) {
L69: config.twitch.authSource = "manual-env";
L105: redirectBaseUrl:
L106: process.env.OAUTH_REDIRECT_BASE_URL || `http://localhost:${launcherPort}`,
L107: twitch: {
L108: clientId: process.env.TWITCH_CLIENT_ID || "",
L109: client-side popup auth does not read TWITCH_CLIENT_SECRET,
L110: scopes: scopesFromEnv("TWITCH_OAUTH_SCOPES", ["chat:read", "chat:edit"]),
L113: clientId: process.env.YOUTUBE_CLIENT_ID || "",
L114: client-side popup auth does not read YOUTUBE_CLIENT_SECRET,
L115: scopes: scopesFromEnv("YOUTUBE_OAUTH_SCOPES", [
L120: clientId: process.env.KICK_CLIENT_ID || "",
L121: Kick popup auth uses PKCE and does not read KICK_CLIENT_SECRET,
L122: scopes: scopesFromEnv("KICK_OAUTH_SCOPES", [
L124: "channel:read",
L131: twitch: {
L132: channel: process.env.TWITCH_CHANNEL || "",
L133: username: process.env.TWITCH_BOT_USERNAME || "",
L134: oauthToken: process.env.TWITCH_OAUTH_TOKEN || "",
L135: clientId: process.env.TWITCH_CLIENT_ID || "",
L136: broadcasterId: process.env.TWITCH_BROADCASTER_ID || "",
L137: moderatorUserId: process.env.TWITCH_MODERATOR_USER_ID || "",
L138: authSource: process.env.TWITCH_OAUTH_TOKEN ? "manual-env" : "not-connected",
L151: webhookSecret: process.env.KICK_WEBHOOK_SECRET || "",

## Rebuild order

1. Add Twitch OAuth config fields to KTRLboy config.
2. Add Twitch auth URL builder.
3. Replace placeholder /api/ktrlboy/auth/twitch/start with real auth URL generation.
4. Add callback handler that stores popup tokens, with PKCE exchange only where required.
5. Store token through token-manager so responses remain redacted.
6. Add UI fields for Twitch Client ID / Redirect URI / Scopes.
7. Add Open Twitch Auth button.
8. Verify token provider status becomes configured.
9. Then build Twitch adapter connection separately.

## Current status

Planning foundation only. No real OAuth exchange wired yet.
