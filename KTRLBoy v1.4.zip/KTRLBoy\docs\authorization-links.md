# Authorization Links

KTRLBoy stores provider authorization link metadata separately from real streamer account OAuth tokens.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Integrations`, then use `Refresh Auth Links`.

## What Is Stored

KTRLBoy stores safe provider metadata in:

```text
.data/authorizations.json
```

This can include:

- OAuth authorization endpoint
- token endpoint
- provider login docs link
- provider OAuth setup link
- KTRLBoy callback URL
- requested scopes

Actual access tokens and refresh tokens stay in:

```text
.auth/tokens.json
```

## Buttons

The Logins screen turns the stored metadata into provider buttons:

- `Connect Streamer Account`
- `Client Authorization Setup`
- `Login Docs`
- `Auth Endpoint`

Use `Connect Streamer Account` for chat access. The external buttons are there to help you open each provider's OAuth setup or reference pages quickly.
