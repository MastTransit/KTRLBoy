# Command Editor

KTRLBoy includes a local GUI editor for custom chat commands.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Commands` to add, edit, disable, or delete text-response commands.

The response editor includes parameter buttons for common placeholders such as `{user}`, `{args}`, `{platform}`, and `{bot}`.

## Command Rules

- Names use lowercase letters, numbers, dashes, or underscores.
- Names are saved without the `!` prefix.
- Responses are limited to 400 characters.
- Built-in commands cannot be replaced from the GUI.
- Custom commands are stored in `.data/commands.json`.

## Response Placeholders

Use these in command responses:

```text
{user}
{args}
{arg1}
{arg2}
{platform}
{channel}
{bot}
{prefix}
```

Example:

```text
Command: socials
Response: Follow {user} and KTRLBoy on all channels. Latest links: https://example.com
```

In chat:

```text
!socials
```

KTRLBoy replies with the saved response.

## Moderator Chat Editing

Chat moderators can manage commands directly from chat:

```text
!cmd add socials Follow KTRLBoy everywhere: https://example.com
!cmd edit socials Latest links are at https://example.com
!cmd delete socials
!cmd enable socials
!cmd disable socials
!cmd list
```

Only broadcasters, owners, and moderators can use `!cmd`. Viewers can still run enabled custom commands, but they cannot add, edit, disable, or delete them.

If the `Custom Commands` module is turned off, built-in commands still work, but saved custom commands stop responding until the module is enabled again.
