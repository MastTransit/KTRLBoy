$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
$node = "node"
$statusPort = "8791"
$certDir = Join-Path $root ".certs"

& (Join-Path $PSScriptRoot "create-local-https-cert.ps1") -OutputDirectory $certDir -Hostname "localhost" | Out-Null

$certPath = Join-Path $certDir "ktrlboy-localhost.crt"
$pfxPath = Join-Path $certDir "ktrlboy-localhost.pfx"
$pfxPassphrase = "ktrlboy-local"

$startInfo = [System.Diagnostics.ProcessStartInfo]::new()
$startInfo.FileName = $node
$startInfo.Arguments = "src/index.js"
$startInfo.WorkingDirectory = $root.Path
$startInfo.UseShellExecute = $false
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true
$startInfo.CreateNoWindow = $true
$startInfo.Environment["BOT_NAME"] = "KTRLBoy"
$startInfo.Environment["ENABLED_PLATFORMS"] = ""
$startInfo.Environment["LAUNCHER_STATUS_ENABLED"] = "true"
$startInfo.Environment["LAUNCHER_STATUS_PROTOCOL"] = "https"
$startInfo.Environment["LAUNCHER_STATUS_HOST"] = "localhost"
$startInfo.Environment["LAUNCHER_STATUS_PORT"] = $statusPort
$startInfo.Environment["LAUNCHER_STATUS_HTTPS_PFX_PATH"] = $pfxPath
$startInfo.Environment["LAUNCHER_STATUS_HTTPS_PFX_PASSPHRASE"] = $pfxPassphrase
$startInfo.Environment["OAUTH_REDIRECT_BASE_URL"] = "https://localhost:$statusPort"

$process = [System.Diagnostics.Process]::Start($startInfo)

try {
  $healthUrl = "https://localhost:$statusPort/health"
  $statusUrl = "https://localhost:$statusPort/status"
  $guiUrl = "https://localhost:$statusPort/"
  $healthy = $false

  for ($attempt = 0; $attempt -lt 20; $attempt++) {
    try {
      $healthOutput = & $node "scripts/https-smoke-client.mjs" "https://localhost:$statusPort" 2>$null
      if ($LASTEXITCODE -eq 0 -and $healthOutput -match '"health": "ok"') {
        $healthy = $true
        break
      }
    } catch {
      Start-Sleep -Milliseconds 250
    }
  }

  if (-not $healthy) {
    throw "KTRLBoy HTTPS status server did not become healthy at $healthUrl"
  }

  [pscustomobject]@{
    health = "ok"
    guiUrl = $guiUrl
    statusUrl = $statusUrl
    certPath = $certPath
    pfxPath = $pfxPath
  } | Format-List
} finally {
  if ($process -and -not $process.HasExited) {
    $process.Kill()
    $process.WaitForExit()
  }

  $stdout = $process.StandardOutput.ReadToEnd().Trim()
  $stderr = $process.StandardError.ReadToEnd().Trim()

  if ($stdout) {
    "KTRLBoy stdout:"
    $stdout
  }

  if ($stderr) {
    "KTRLBoy stderr:"
    $stderr
  }
}
