﻿# KTRLboy Alpha v1.3 Developer Handoff

KTRLboy Alpha v1.3 is the KTRL-native rebuild of KTRLboy v1.2.

This version is intended as a clean developer foundation so KTRLboy can be worked on independently while still running as a built-in KTRL service.

## Core idea

KTRL is the platform.

KTRLboy is a built-in service inside KTRL.

KTRLboy should run dependently under KTRL, but update independently from the KTRLboy GitHub.

## Current state

Working:

- KTRL serves KTRLboy at /KTRLboy.
- KTRLboy APIs live under /api/ktrlboy.
- KTRLboy does not use the old 3001 sidecar flow.
- KTRLboy has independent versioning.
- KTRLboy update scope is companion/ktrlboy only.
- Core data stores work.
- Command routing works.
- Timers work locally.
- Moderation works locally.
- Message pipeline works locally.
- Runtime start/stop foundation works.
- Platform readiness works.
- Redacted token storage works.
- Twitch auth foundation exists.
- Twitch adapter stub exists.
- Twitch adapter test messages pass through the real message pipeline.

Not finished:

- Real Twitch chat connection.
- Real YouTube Live connection.
- Real Kick connection.
- Production OAuth polish.
- Production command editor UI.
- Production timer editor UI.
- Production moderation editor UI.

## Folder structure

KTRL consumes KTRLboy from:

companion/ktrlboy

Important files:

- companion/ktrlboy/ktrlboy-version.json
- companion/ktrlboy/service-update.json
- companion/ktrlboy/src/service.js
- companion/ktrlboy/src/stores.js
- companion/ktrlboy/src/command-router.js
- companion/ktrlboy/src/timer-engine.js
- companion/ktrlboy/src/moderation-engine.js
- companion/ktrlboy/src/message-pipeline.js
- companion/ktrlboy/src/config.js
- companion/ktrlboy/src/token-manager.js
- companion/ktrlboy/src/platform-manager.js
- companion/ktrlboy/src/runtime-manager.js
- companion/ktrlboy/src/auth-links.js
- companion/ktrlboy/src/adapter-manager.js

Data lives in:

companion/ktrlboy/data

Config lives in:

companion/ktrlboy/config

Docs live in:

companion/ktrlboy/docs

## API base

All KTRLboy APIs are under:

/api/ktrlboy

## Primary routes

Page:

- GET /KTRLboy

Status:

- GET /api/ktrlboy/status
- GET /api/ktrlboy/version
- GET /api/ktrlboy/update-source

Stores:

- GET /api/ktrlboy/stores
- GET /api/ktrlboy/data
- GET /api/ktrlboy/commands
- PUT /api/ktrlboy/commands
- POST /api/ktrlboy/commands/reset
- GET /api/ktrlboy/timers
- PUT /api/ktrlboy/timers
- POST /api/ktrlboy/timers/reset
- GET /api/ktrlboy/modules
- PUT /api/ktrlboy/modules
- POST /api/ktrlboy/modules/reset
- GET /api/ktrlboy/moderation
- PUT /api/ktrlboy/moderation
- POST /api/ktrlboy/moderation/reset

Bot brain:

- POST /api/ktrlboy/route-message
- POST /api/ktrlboy/test-message

Timers:

- GET /api/ktrlboy/timers/due
- POST /api/ktrlboy/timers/tick

Moderation:

- POST /api/ktrlboy/moderation/check
- POST /api/ktrlboy/moderation/log/clear

Config:

- GET /api/ktrlboy/config
- PUT /api/ktrlboy/config
- POST /api/ktrlboy/config/reset

Tokens:

- GET /api/ktrlboy/tokens
- GET /api/ktrlboy/tokens/:providerId
- PUT /api/ktrlboy/tokens/:providerId
- POST /api/ktrlboy/tokens/:providerId/clear

Tokens are redacted in API responses. Raw token values should never be returned to the UI.

Platforms:

- GET /api/ktrlboy/platforms
- GET /api/ktrlboy/platforms/:providerId

Runtime:

- GET /api/ktrlboy/runtime
- POST /api/ktrlboy/runtime/start
- POST /api/ktrlboy/runtime/stop
- POST /api/ktrlboy/runtime/restart

Auth:

- GET /api/ktrlboy/auth
- GET /api/ktrlboy/auth/:providerId
- GET /api/ktrlboy/auth/:providerId/start
- GET /api/ktrlboy/auth/:providerId/callback
- GET /api/ktrlboy/auth/twitch/preflight
- GET /api/ktrlboy/auth/twitch/validate

Adapters:

- GET /api/ktrlboy/adapters
- GET /api/ktrlboy/adapters/:providerId
- POST /api/ktrlboy/adapters/:providerId/start
- POST /api/ktrlboy/adapters/:providerId/stop
- POST /api/ktrlboy/adapters/:providerId/test-message

## Adapter contract

The adapter contract is currently implemented by:

companion/ktrlboy/src/adapter-manager.js

The Twitch adapter stub supports:

- start
- stop
- status
- test-message

The test-message endpoint sends a message through the real KTRLboy message pipeline.

Flow:

message
-> moderation
-> command router
-> response

Example:

POST /api/ktrlboy/adapters/twitch/test-message

Body:

{
  "user": "Kody",
  "message": "!test"
}

Expected result:

- moderation allowed
- command matched
- response returned

## Update rules

KTRLboy updates should only modify:

companion/ktrlboy

KTRLboy updates must not modify:

- app
- public
- launcher
- scripts
- services/manifests/builder.service.json
- services/manifests/overlays.service.json

KTRLboy should publish its own update package separately from the main KTRL release package.

## Versioning

KTRLboy version file:

companion/ktrlboy/ktrlboy-version.json

Current rebuild target:

KTRLboy Alpha v1.3-dev

This will become:

KTRLboy Alpha v1.3

KTRLboy versioning is independent from the main KTRL platform version.

## Recommended next developer tasks

1. Convert Twitch adapter stub into a real Twitch chat adapter.
2. Keep adapter input/output compatible with adapter-manager.js.
3. Keep all token API responses redacted.
4. Keep writes scoped to companion/ktrlboy.
5. Build production command editor UI.
6. Build production timer editor UI.
7. Build production moderation editor UI.
8. Add YouTube Live adapter using the same adapter contract.
9. Add Kick adapter using the same adapter contract.
10. Prepare KTRLboy standalone update package and latest manifest.

## Do not regress

- Do not bring back the 3001 sidecar as the user-facing runtime.
- Do not expose raw access tokens or client secrets in API responses.
- Do not let KTRLboy update core KTRL files.
- Do not make Builder or Overlays depend on KTRLboy.
- Do not make KTRLboy depend on Builder or Overlays.
