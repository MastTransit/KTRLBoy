# Streamer Account Login

KTRLBoy is set up to access chat through a connected platform account. The GUI opens Twitch, YouTube, or Kick in an authorization popup, then stores the returned streamer authorization locally.

The normal login path is client-side and uses the provider Client ID only. KTRLBoy does not require a developer Client Secret for streamer authorization. The connected streamer/platform account token is what KTRLBoy uses for chat and API calls.

## Bot Name vs Chat Sender

The local bot name stays `KTRLBoy` through `BOT_NAME=KTRLBoy`.

Streaming platforms show chat messages as the account that authorized chat. KTRLBoy cannot make Twitch, YouTube, or Kick display a different sender name than the connected account.
To make chat messages appear from `KTRLBoy`, connect a Twitch/Kick account or YouTube channel/brand account named `KTRLBoy`.

## Local Callback URLs

Add these redirect/callback URLs to each provider OAuth login setup:

```text
http://localhost:8790/auth/twitch/callback
http://localhost:8790/auth/youtube/callback
http://localhost:8790/auth/kick/callback
```

Keep this value in `.env`:

```env
OAUTH_REDIRECT_BASE_URL=http://localhost:8790
```

## Twitch

Set the Twitch OAuth login values:

```env
TWITCH_CLIENT_ID=
TWITCH_OAUTH_SCOPES=chat:read chat:edit
```

KTRLBoy stores the logged-in Twitch access token and uses it as the IRC chat token. If `TWITCH_OAUTH_TOKEN` is also present, the stored streamer account token wins. Connect a Twitch account named `KTRLBoy` if Twitch chat should show the sender as KTRLBoy. Set `TWITCH_CHANNEL` only when the bot should join a channel that is different from the logged-in account.

## YouTube

Set the YouTube OAuth login values:

```env
YOUTUBE_CLIENT_ID=
YOUTUBE_OAUTH_SCOPES=https://www.googleapis.com/auth/youtube.force-ssl
```

After connecting YouTube, use `Find Chat` in the GUI while your stream is live. KTRLBoy will try to discover the active broadcast's `liveChatId`. If `YOUTUBE_ACCESS_TOKEN` is also present, the stored streamer account token wins. Connect the YouTube channel or brand account named `KTRLBoy` if chat should show that sender name.

## Kick

Set the Kick OAuth login values:

```env
KICK_CLIENT_ID=
KICK_OAUTH_SCOPES=user:read channel:read chat:write events:subscribe
```

Kick uses OAuth 2.1 with PKCE. KTRLBoy handles the PKCE verifier and stores the resulting account token locally without a Client Secret. If `KICK_ACCESS_TOKEN` is also present, the stored streamer account token wins. Connect a Kick account named `KTRLBoy` if Kick chat should show that sender name.

## Token Storage

Tokens are stored in:

```text
.auth/tokens.json
```

This folder is ignored by Git and is excluded from Docker/package artifacts. Treat it like a password file.

## GUI Flow

1. Run `npm.cmd run gui`.
2. Open `http://localhost:8790/`.
3. Go to `Integrations`.
4. Fill in the provider `Client ID` and scopes in the Client Authorization card.
5. Choose `Save Setup`. KTRLBoy writes those values to `.env` and updates the running login config.
6. Choose `Refresh Auth Links` to pull and store the latest provider authorization links.
7. Choose `Connect Streamer Account` for each provider.
8. Complete the provider login in your browser.
9. KTRLBoy marks the account as browser-verified when the provider redirects back.
10. Go to `Channel API` and use `Sync` to pull the latest connected account profile from the provider APIs.
11. Restart KTRLBoy after changing `ENABLED_PLATFORMS` so adapters start with the new credentials.

The OAuth callback still returns to KTRLBoy's local server so the app can securely store the token, but the account verification itself happens through the provider's browser popup.
