const panels = new Map(
  [...document.querySelectorAll(".panel")].map((panel) => [panel.id.replace("-panel", ""), panel]),
);
const menuItems = [...document.querySelectorAll(".menu-item")];

const elements = {
  pageTitle: document.querySelector("#page-title"),
  botState: document.querySelector("#bot-state"),
  sideHealthDot: document.querySelector("#side-health-dot"),
  sideHealthText: document.querySelector("#side-health-text"),
  metricHealth: document.querySelector("#metric-health"),
  metricUptime: document.querySelector("#metric-uptime"),
  metricPlatforms: document.querySelector("#metric-platforms"),
  metricPrefix: document.querySelector("#metric-prefix"),
  metricCommands: document.querySelector("#metric-commands"),
  metricTimers: document.querySelector("#metric-timers"),
  detailBot: document.querySelector("#detail-bot"),
  detailRequested: document.querySelector("#detail-requested"),
  detailStarted: document.querySelector("#detail-started"),
  detailErrors: document.querySelector("#detail-errors"),
  lastUpdated: document.querySelector("#last-updated"),
  platformTable: document.querySelector("#platform-table"),
  loginList: document.querySelector("#login-list"),
  commandList: document.querySelector("#command-list"),
  commandForm: document.querySelector("#command-form"),
  commandName: document.querySelector("#command-name"),
  commandResponse: document.querySelector("#command-response"),
  commandEnabled: document.querySelector("#command-enabled"),
  commandNew: document.querySelector("#command-new"),
  commandSave: document.querySelector("#command-save"),
  timerList: document.querySelector("#timer-list"),
  timerForm: document.querySelector("#timer-form"),
  timerName: document.querySelector("#timer-name"),
  timerMessages: document.querySelector("#timer-messages"),
  timerInterval: document.querySelector("#timer-interval"),
  timerChatLines: document.querySelector("#timer-chat-lines"),
  timerEnabled: document.querySelector("#timer-enabled"),
  timerNew: document.querySelector("#timer-new"),
  timerReset: document.querySelector("#timer-reset"),
  timerSave: document.querySelector("#timer-save"),
  moderationForm: document.querySelector("#moderation-form"),
  moderationLog: document.querySelector("#moderation-log"),
  modEnabled: document.querySelector("#mod-enabled"),
  modDryRun: document.querySelector("#mod-dry-run"),
  modAction: document.querySelector("#mod-action"),
  modBlockedTerms: document.querySelector("#mod-blocked-terms"),
  modAllowLinks: document.querySelector("#mod-allow-links"),
  modWarnBeforeAction: document.querySelector("#mod-warn-before-action"),
  modTimeoutSeconds: document.querySelector("#mod-timeout-seconds"),
  modTimeoutAfter: document.querySelector("#mod-timeout-after"),
  modMaxMessages: document.querySelector("#mod-max-messages"),
  modSpamWindow: document.querySelector("#mod-spam-window"),
  modCapsPercent: document.querySelector("#mod-caps-percent"),
  modRepeatedChars: document.querySelector("#mod-repeated-chars"),
  setupList: document.querySelector("#setup-list"),
  moduleList: document.querySelector("#module-list"),
  modulesSave: document.querySelector("#modules-save"),
  healthUrl: document.querySelector("#health-url"),
  statusUrl: document.querySelector("#status-url"),
  refreshButton: document.querySelector("#refresh-button"),
  authRefreshButton: document.querySelector("#auth-refresh-button"),
};

const platformNames = ["twitch", "youtube", "kick"];
let editingCommandName = "";
let editingTimerName = "";
let moderationFormDirty = false;
let moduleFormDirty = false;

function markModerationDirty() {
  moderationFormDirty = true;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function titleCase(value) {
  return `${value.slice(0, 1).toUpperCase()}${value.slice(1)}`;
}

function formatDuration(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m ${seconds}s`;
  return `${seconds}s`;
}

function setHealth(ok) {
  elements.botState.textContent = ok ? "Online" : "Needs attention";
  elements.botState.classList.toggle("is-ok", ok);
  elements.botState.classList.toggle("is-error", !ok);
  elements.sideHealthDot.classList.toggle("is-ok", ok);
  elements.sideHealthDot.classList.toggle("is-error", !ok);
  elements.sideHealthText.textContent = ok ? "Online" : "Needs attention";
  elements.metricHealth.textContent = ok ? "Online" : "Check setup";
}

function badge(text, tone) {
  return `<span class="badge ${tone ? `is-${tone}` : ""}">${escapeHtml(text)}</span>`;
}

function platformStatus(platform, status) {
  const found = status.platforms.find((item) => item.name === platform);
  if (!status.requestedPlatforms.includes(platform)) return badge("Idle", "warn");
  if (!found) return badge("Waiting", "warn");
  if (found.status === "started") return badge("Started", "ok");
  if (found.status === "failed") return badge("Failed", "error");
  return badge(titleCase(found.status), "warn");
}

function renderPlatforms(status) {
  elements.platformTable.innerHTML = platformNames
    .map((platform) => {
      const setup = status.platformConfig?.[platform];
      const login = status.oauth?.[platform];
      const requested = status.requestedPlatforms.includes(platform);
      const configured = setup?.configured || login?.connected;

      return `
        <tr>
          <td><strong>${titleCase(platform)}</strong></td>
          <td>${requested ? badge("Yes", "ok") : badge("No", "warn")}</td>
          <td>${configured ? badge("Ready", "ok") : badge("Missing", "warn")}</td>
          <td>${platformStatus(platform, status)}</td>
        </tr>
      `;
    })
    .join("");
}

function renderLogins(status) {
  elements.loginList.innerHTML = platformNames
    .map((platform) => {
      const login = status.oauth?.[platform] || {};
      const auth = status.authorizations?.providers?.[platform] || {};
      const connected = Boolean(login.connected);
      const configured = Boolean(login.configured);
      const metadata = login.metadata || {};
      const account =
        metadata.displayName ||
        metadata.username ||
        metadata.channelTitle ||
        metadata.channelSlug ||
        metadata.broadcastTitle ||
        "Not connected";
      const scopes = login.scopes?.length ? login.scopes.join(", ") : "No scopes configured";
      const expires = login.expiresAt ? new Date(login.expiresAt).toLocaleString() : "No expiry";
      const redirect = login.redirectUri || "";
      const profile = metadata.profileImage
        ? `<span>Profile: <code>${escapeHtml(metadata.profileImage)}</code></span>`
        : "";
      const synced = metadata.syncedAt ? new Date(metadata.syncedAt).toLocaleString() : "Not synced";
      const verifiedAt = metadata.browserVerifiedAt || metadata.localVerifiedAt || "";
      const verification = verifiedAt
        ? `${metadata.verificationMethod === "local" ? "Local callback" : "Browser"} at ${new Date(
            verifiedAt,
          ).toLocaleString()}`
        : "Not verified";
      const authUpdated = status.authorizations?.updatedAt
        ? new Date(status.authorizations.updatedAt).toLocaleString()
        : "Defaults";
      const authButtons = (auth.buttons || [])
        .map((button) => {
          const className = button.kind === "primary" ? "link-button" : "external-button";
          const disabled = button.enabled === false ? "is-disabled" : "";
          const target = button.href?.startsWith("http") ? ` target="_blank" rel="noreferrer"` : "";
          const authStart = button.href?.startsWith("/auth/")
            ? ` data-auth-start="${escapeHtml(platform)}"`
            : "";
          return `<a class="${className} ${disabled}" href="${escapeHtml(button.href || "#")}"${target}${authStart}>${escapeHtml(button.label)}</a>`;
        })
        .join("");

      return `
        <article class="login-card">
          <div>
            <h3>${titleCase(platform)}</h3>
            ${connected ? badge("Connected", login.expired ? "warn" : "ok") : badge("Not connected", "warn")}
            ${configured ? badge("App ready", "ok") : badge("App credentials missing", "warn")}
            <div class="login-meta">
              <span>Account: <strong>${escapeHtml(account)}</strong></span>
              <span>Verified: ${escapeHtml(verification)}</span>
              <span>Synced: ${escapeHtml(synced)}</span>
              <span>Auth links: ${escapeHtml(authUpdated)}</span>
              <span>Expires: ${escapeHtml(expires)}</span>
              <span>Scopes: ${escapeHtml(scopes)}</span>
              ${profile}
              <span>Callback: <code>${escapeHtml(redirect)}</code></span>
              <span>Authorize: <code>${escapeHtml(auth.authorizationEndpoint || "")}</code></span>
            </div>
            <div class="link-strip">${authButtons}</div>
          </div>
          <div class="action-row">
            <button class="ghost-button" type="button" data-provider="${platform}" data-action="sync-profile" ${connected ? "" : "disabled"}>Sync Login</button>
            <button class="ghost-button" type="button" data-provider="${platform}" data-action="refresh" ${connected ? "" : "disabled"}>Refresh</button>
            ${
              platform === "youtube"
                ? `<button class="ghost-button" type="button" data-provider="${platform}" data-action="discover-chat" ${connected ? "" : "disabled"}>Find Chat</button>`
                : ""
            }
            <button class="ghost-button" type="button" data-provider="${platform}" data-action="logout" ${connected ? "" : "disabled"}>Disconnect</button>
          </div>
        </article>
      `;
    })
    .join("");
}

function resetCommandForm() {
  editingCommandName = "";
  elements.commandName.value = "";
  elements.commandName.disabled = false;
  elements.commandResponse.value = "";
  elements.commandEnabled.checked = true;
  elements.commandSave.textContent = "Save";
}

function editCommand(command) {
  editingCommandName = command.name;
  elements.commandName.value = command.name;
  elements.commandName.disabled = true;
  elements.commandResponse.value = command.response || "";
  elements.commandEnabled.checked = command.enabled !== false;
  elements.commandSave.textContent = "Update";
  elements.commandName.scrollIntoView({ block: "nearest" });
}

function insertCommandToken(token) {
  const input = elements.commandResponse;
  const start = input.selectionStart ?? input.value.length;
  const end = input.selectionEnd ?? input.value.length;
  const prefix = start > 0 && !/\s$/.test(input.value.slice(0, start)) ? " " : "";
  const suffix = end < input.value.length && !/^\s/.test(input.value.slice(end)) ? " " : "";
  input.setRangeText(`${prefix}${token}${suffix}`, start, end, "end");
  input.focus();
}

function resetTimerForm() {
  editingTimerName = "";
  elements.timerName.value = "";
  elements.timerName.disabled = false;
  elements.timerMessages.value = "";
  elements.timerInterval.value = "15";
  elements.timerChatLines.value = "5";
  elements.timerEnabled.checked = true;
  elements.timerSave.textContent = "Save";
}

function editTimer(timer) {
  editingTimerName = timer.name;
  elements.timerName.value = timer.name;
  elements.timerName.disabled = true;
  elements.timerMessages.value = (timer.messages || []).join("\n");
  elements.timerInterval.value = timer.intervalMinutes;
  elements.timerChatLines.value = timer.chatLines;
  elements.timerEnabled.checked = timer.enabled !== false;
  elements.timerSave.textContent = "Update";
  elements.timerName.scrollIntoView({ block: "nearest" });
}

function insertTimerToken(token) {
  const input = elements.timerMessages;
  const start = input.selectionStart ?? input.value.length;
  const end = input.selectionEnd ?? input.value.length;
  const prefix = start > 0 && !/\s$/.test(input.value.slice(0, start)) ? " " : "";
  const suffix = end < input.value.length && !/^\s/.test(input.value.slice(end)) ? " " : "";
  input.setRangeText(`${prefix}${token}${suffix}`, start, end, "end");
  input.focus();
}

function syncActionButtons() {
  document.querySelectorAll("[data-mod-action]").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.modAction === elements.modAction.value);
  });
}

function syncToggleButtons() {
  document.querySelectorAll("[data-toggle-target]").forEach((button) => {
    const input = document.querySelector(`#${button.dataset.toggleTarget}`);
    button.classList.toggle("is-active", Boolean(input?.checked));
  });
}

function setNumericValue(targetId, value) {
  const input = document.querySelector(`#${targetId}`);
  if (!input) return;

  const min = input.min === "" ? Number.NEGATIVE_INFINITY : Number(input.min);
  const max = input.max === "" ? Number.POSITIVE_INFINITY : Number(input.max);
  const next = Math.max(min, Math.min(max, Math.round(Number(value))));
  input.value = String(next);
  if (targetId.startsWith("mod-")) markModerationDirty();
}

function renderCommands(status) {
  const builtIns = status.commands?.builtIn || [];
  const custom = status.commands?.custom || [];
  window.__ktrlboyCommands = custom;
  const cards = [
    ...builtIns.map((command) => ({ ...command, builtIn: true })),
    ...custom.map((command) => ({ ...command, builtIn: false })),
  ];

  elements.commandList.innerHTML = cards
    .map((command) => {
      const title = `${status.commandPrefix || "!"}${command.name}`;
      const description = command.builtIn ? command.description : command.response;

      return `
        <article class="command-card">
          <div>
            <strong>${escapeHtml(title)}</strong>
            ${command.builtIn ? badge("Built-in", "") : badge(command.enabled ? "Enabled" : "Disabled", command.enabled ? "ok" : "warn")}
            <p>${escapeHtml(description || "")}</p>
          </div>
          ${
            command.builtIn
              ? ""
              : `<div class="action-row">
                  <button class="ghost-button" type="button" data-command="${escapeHtml(command.name)}" data-command-action="edit">Edit</button>
                  <button class="ghost-button" type="button" data-command="${escapeHtml(command.name)}" data-command-action="delete">Delete</button>
                </div>`
          }
        </article>
      `;
    })
    .join("");
}

function renderTimers(status) {
  const timers = status.timers?.items || [];
  window.__ktrlboyTimers = timers;
  elements.metricTimers.textContent = String(timers.filter((timer) => timer.enabled).length);

  elements.timerList.innerHTML =
    timers.length === 0
      ? `<article class="timer-card"><strong>No timers yet</strong><p>Create recurring chat messages with a chat-line threshold.</p></article>`
      : timers
          .map(
            (timer) => `
              <article class="timer-card">
                <div>
                  <strong>${escapeHtml(timer.name)}</strong>
                  ${badge(timer.enabled ? "Enabled" : "Disabled", timer.enabled ? "ok" : "warn")}
                  <p>${escapeHtml((timer.messages || []).join(" / "))}</p>
                  <div class="timer-meta">
                    <span>${escapeHtml(String(timer.intervalMinutes))}m interval</span>
                    <span>${escapeHtml(String(timer.chatLines))} chat lines</span>
                    <span>${escapeHtml(String((timer.messages || []).length))} message${(timer.messages || []).length === 1 ? "" : "s"}</span>
                  </div>
                </div>
                <div class="action-row">
                  <button class="ghost-button" type="button" data-timer="${escapeHtml(timer.name)}" data-timer-action="edit">Edit</button>
                  <button class="ghost-button" type="button" data-timer="${escapeHtml(timer.name)}" data-timer-action="delete">Delete</button>
                </div>
              </article>
            `,
          )
          .join("");
}

function renderModules(status) {
  const modules = moduleFormDirty && window.__ktrlboyModules ? window.__ktrlboyModules : status.modules || {};
  const entries = Object.entries(modules);
  const enabledCount = entries.filter(([, module]) => module.enabled).length;
  elements.moduleList.innerHTML =
    entries.length === 0
      ? `<article class="module-card"><strong>No modules available</strong><p>Module controls appear after the bot starts.</p></article>`
      : entries
          .map(
            ([key, module]) => `
              <article class="module-card">
                <div>
                  <strong>${escapeHtml(module.label || key)}</strong>
                  <p>${escapeHtml(module.description || "")}</p>
                  <code>${escapeHtml(key)}</code>
                </div>
                <button class="toggle-button ${module.enabled ? "is-active" : ""}" type="button" data-module-key="${escapeHtml(
                  key,
                )}" aria-pressed="${module.enabled ? "true" : "false"}">
                  ${module.enabled ? "On" : "Off"}
                </button>
              </article>
            `,
          )
          .join("");

  elements.moduleList.dataset.enabledCount = String(enabledCount);
  if (!moduleFormDirty) {
    window.__ktrlboyModules = modules;
  }
}

function renderSetup(status) {
  elements.setupList.innerHTML = platformNames
    .map((platform) => {
      const login = status.oauth?.[platform];
      const setup = status.platformConfig?.[platform] || {
        configured: false,
        missing: ["Not checked"],
      };
      const ready = setup.configured || login?.connected;
      const missing = setup.missing?.length ? setup.missing.join(", ") : "Ready";
      const tone = ready ? "ok" : "warn";
      const text = ready ? "Chat credentials present" : missing;

      return `
        <article class="setup-card">
          <div>
            <strong>${titleCase(platform)}</strong>
            <span>${text}</span>
          </div>
          ${badge(ready ? "Ready" : "Needs setup", tone)}
        </article>
      `;
    })
    .join("");
}

function renderModeration(status) {
  const settings = status.moderation?.settings;
  if (!settings) return;

  if (!moderationFormDirty) {
    elements.modEnabled.checked = Boolean(settings.enabled);
    elements.modDryRun.checked = Boolean(settings.dryRun);
    elements.modAction.value = settings.action;
    elements.modBlockedTerms.value = (settings.blockedTerms || []).join("\n");
    elements.modAllowLinks.checked = Boolean(settings.allowLinks);
    elements.modWarnBeforeAction.checked = Boolean(settings.warnBeforeAction);
    elements.modTimeoutSeconds.value = settings.timeoutSeconds;
    elements.modTimeoutAfter.value = settings.timeoutAfterViolations;
    elements.modMaxMessages.value = settings.maxMessagesPerWindow;
    elements.modSpamWindow.value = settings.spamWindowSeconds;
    elements.modCapsPercent.value = settings.maxCapsPercent;
    elements.modRepeatedChars.value = settings.maxRepeatedChars;
    syncActionButtons();
    syncToggleButtons();
  }

  const log = status.moderation?.log || [];
  elements.moderationLog.innerHTML =
    log.length === 0
      ? `<article class="moderation-log-card"><strong>No moderation events yet</strong><span>Dry-run and real actions appear here.</span></article>`
      : log
          .map(
            (entry) => `
              <article class="moderation-log-card">
                <strong>${escapeHtml(entry.platform)}: ${escapeHtml(entry.user)} (${escapeHtml(entry.result)})</strong>
                <span>${escapeHtml(new Date(entry.at).toLocaleString())}</span>
                <span>${escapeHtml((entry.reasons || []).join(", "))}</span>
                <span>${escapeHtml(entry.text || "")}</span>
              </article>
            `,
          )
          .join("");
}

async function refreshStatus() {
  try {
    const response = await fetch("/status", { cache: "no-store" });
    const status = await response.json();

    setHealth(Boolean(status.ok));
    elements.metricUptime.textContent = formatDuration(status.uptimeMs);
    elements.metricPlatforms.textContent = String(status.startedPlatforms.length);
    elements.metricPrefix.textContent = status.commandPrefix;
    elements.metricCommands.textContent = String((status.commands?.custom || []).length);
    elements.metricTimers.textContent = String((status.timers?.items || []).filter((timer) => timer.enabled).length);
    elements.detailBot.textContent = status.botName;
    elements.detailRequested.textContent = status.requestedPlatforms.join(", ") || "None";
    elements.detailStarted.textContent = status.startedPlatforms.join(", ") || "None";
    elements.detailErrors.textContent = status.errors.join(", ") || "None";
    elements.healthUrl.textContent = status.routes?.health || "/health";
    elements.statusUrl.textContent = status.routes?.status || "/status";
    elements.lastUpdated.textContent = `Updated ${new Date().toLocaleTimeString()}`;

    renderPlatforms(status);
    renderLogins(status);
    renderCommands(status);
    renderTimers(status);
    renderModeration(status);
    renderModules(status);
    renderSetup(status);
  } catch (error) {
    setHealth(false);
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
  }
}

async function saveModeration(event) {
  event.preventDefault();
  const response = await fetch("/api/moderation", {
    method: "PUT",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      enabled: elements.modEnabled.checked,
      dryRun: elements.modDryRun.checked,
      action: elements.modAction.value,
      blockedTerms: elements.modBlockedTerms.value,
      allowLinks: elements.modAllowLinks.checked,
      warnBeforeAction: elements.modWarnBeforeAction.checked,
      timeoutSeconds: elements.modTimeoutSeconds.value,
      timeoutAfterViolations: elements.modTimeoutAfter.value,
      maxMessagesPerWindow: elements.modMaxMessages.value,
      spamWindowSeconds: elements.modSpamWindow.value,
      maxCapsPercent: elements.modCapsPercent.value,
      maxRepeatedChars: elements.modRepeatedChars.value,
    }),
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Moderation save failed");
  }
  moderationFormDirty = false;
  await refreshStatus();
}

async function runLoginAction(provider, action) {
  const response = await fetch(`/auth/${provider}/${action}`, {
    method: "POST",
    cache: "no-store",
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || `${provider} ${action} failed`);
  }
  await refreshStatus();
}

async function refreshAuthorizationLinks() {
  elements.authRefreshButton.disabled = true;
  elements.authRefreshButton.textContent = "Refreshing";
  try {
    const response = await fetch("/api/authorizations", {
      method: "POST",
      cache: "no-store",
    });
    const body = await response.json();
    if (!response.ok || !body.ok) {
      throw new Error(body.error || "Authorization link refresh failed");
    }
    await refreshStatus();
  } finally {
    elements.authRefreshButton.disabled = false;
    elements.authRefreshButton.textContent = "Refresh Auth Links";
  }
}

async function saveCommand(event) {
  event.preventDefault();
  const name = editingCommandName || elements.commandName.value;
  const method = editingCommandName ? "PUT" : "POST";
  const path = editingCommandName ? `/api/commands/${encodeURIComponent(editingCommandName)}` : "/api/commands";
  const response = await fetch(path, {
    method,
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      name,
      response: elements.commandResponse.value,
      enabled: elements.commandEnabled.checked,
    }),
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Command save failed");
  }

  resetCommandForm();
  await refreshStatus();
}

async function deleteCommand(name) {
  const response = await fetch(`/api/commands/${encodeURIComponent(name)}`, {
    method: "DELETE",
    cache: "no-store",
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Command delete failed");
  }

  resetCommandForm();
  await refreshStatus();
}

async function saveTimer(event) {
  event.preventDefault();
  const name = editingTimerName || elements.timerName.value;
  const method = editingTimerName ? "PUT" : "POST";
  const path = editingTimerName ? `/api/timers/${encodeURIComponent(editingTimerName)}` : "/api/timers";
  const response = await fetch(path, {
    method,
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      name,
      messages: elements.timerMessages.value
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean),
      enabled: elements.timerEnabled.checked,
      intervalMinutes: elements.timerInterval.value,
      chatLines: elements.timerChatLines.value,
    }),
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Timer save failed");
  }

  resetTimerForm();
  await refreshStatus();
}

async function deleteTimer(name) {
  const response = await fetch(`/api/timers/${encodeURIComponent(name)}`, {
    method: "DELETE",
    cache: "no-store",
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Timer delete failed");
  }

  resetTimerForm();
  await refreshStatus();
}

async function saveModules() {
  const response = await fetch("/api/modules", {
    method: "PUT",
    cache: "no-store",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ modules: window.__ktrlboyModules || {} }),
  });
  const body = await response.json();
  if (!response.ok || !body.ok) {
    throw new Error(body.error || "Module save failed");
  }

  moduleFormDirty = false;
  window.__ktrlboyModules = body.modules;
  await refreshStatus();
}

function activatePanel(name) {
  for (const [panelName, panel] of panels) {
    panel.classList.toggle("is-active", panelName === name);
  }

  for (const item of menuItems) {
    const active = item.dataset.panel === name;
    item.classList.toggle("is-active", active);
    if (active) elements.pageTitle.textContent = item.textContent;
  }

  if (window.location.hash !== `#${name}`) {
    window.history.replaceState(null, "", `#${name}`);
  }
}

for (const item of menuItems) {
  item.addEventListener("click", () => activatePanel(item.dataset.panel));
}

elements.refreshButton.addEventListener("click", refreshStatus);
elements.authRefreshButton.addEventListener("click", () => {
  refreshAuthorizationLinks().catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
window.addEventListener("message", (event) => {
  if (event.origin !== window.location.origin) return;
  if (event.data?.type !== "ktrlboy-auth-verified") return;
  activatePanel("logins");
  refreshStatus();
});
window.addEventListener("storage", (event) => {
  if (event.key !== "ktrlboy-auth-event") return;
  activatePanel("logins");
  refreshStatus();
});
elements.loginList.addEventListener("click", (event) => {
  const link = event.target.closest("a[data-auth-start]");
  if (!link) return;

  event.preventDefault();
  const popup = window.open(link.href, `ktrlboy-auth-${link.dataset.authStart}`, "width=680,height=780");
  if (!popup) window.location.href = link.href;
});
elements.commandNew.addEventListener("click", resetCommandForm);
elements.commandForm.addEventListener("click", (event) => {
  const tokenButton = event.target.closest("[data-insert-token]");
  if (!tokenButton) return;
  insertCommandToken(tokenButton.dataset.insertToken);
});
elements.commandForm.addEventListener("submit", (event) => {
  saveCommand(event).catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
elements.timerNew.addEventListener("click", resetTimerForm);
elements.timerReset.addEventListener("click", resetTimerForm);
elements.timerForm.addEventListener("click", (event) => {
  const tokenButton = event.target.closest("[data-timer-token]");
  if (tokenButton) {
    insertTimerToken(tokenButton.dataset.timerToken);
    return;
  }

  const setButton = event.target.closest("[data-set-target][data-set-value]");
  if (setButton) {
    setNumericValue(setButton.dataset.setTarget, setButton.dataset.setValue);
    return;
  }

  const stepButton = event.target.closest("[data-step-target][data-step]");
  if (stepButton) {
    const input = document.querySelector(`#${stepButton.dataset.stepTarget}`);
    const current = Number(input?.value || 0);
    setNumericValue(stepButton.dataset.stepTarget, current + Number(stepButton.dataset.step));
  }
});
elements.timerForm.addEventListener("submit", (event) => {
  saveTimer(event).catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
elements.moderationForm.addEventListener("submit", (event) => {
  saveModeration(event).catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
elements.moderationForm.addEventListener("input", () => {
  moderationFormDirty = true;
});
elements.moderationForm.addEventListener("click", (event) => {
  const actionButton = event.target.closest("[data-mod-action]");
  if (actionButton) {
    elements.modAction.value = actionButton.dataset.modAction;
    syncActionButtons();
    markModerationDirty();
    return;
  }

  const toggleButton = event.target.closest("[data-toggle-target]");
  if (toggleButton) {
    const input = document.querySelector(`#${toggleButton.dataset.toggleTarget}`);
    if (!input) return;
    input.checked = !input.checked;
    syncToggleButtons();
    markModerationDirty();
    return;
  }

  const setButton = event.target.closest("[data-set-target][data-set-value]");
  if (setButton) {
    setNumericValue(setButton.dataset.setTarget, setButton.dataset.setValue);
    return;
  }

  const stepButton = event.target.closest("[data-step-target][data-step]");
  if (stepButton) {
    const input = document.querySelector(`#${stepButton.dataset.stepTarget}`);
    const current = Number(input?.value || 0);
    setNumericValue(stepButton.dataset.stepTarget, current + Number(stepButton.dataset.step));
  }
});
elements.commandList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-command][data-command-action]");
  if (!button) return;

  const command = button.dataset.command;
  if (button.dataset.commandAction === "edit") {
    const currentStatusCommand = window.__ktrlboyCommands?.find((item) => item.name === command);
    if (currentStatusCommand) editCommand(currentStatusCommand);
    return;
  }

  deleteCommand(command).catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
elements.timerList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-timer][data-timer-action]");
  if (!button) return;

  const timer = button.dataset.timer;
  if (button.dataset.timerAction === "edit") {
    const currentTimer = window.__ktrlboyTimers?.find((item) => item.name === timer);
    if (currentTimer) editTimer(currentTimer);
    return;
  }

  deleteTimer(timer).catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});
elements.loginList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-provider][data-action]");
  if (!button) return;

  button.disabled = true;
  runLoginAction(button.dataset.provider, button.dataset.action)
    .catch((error) => {
      elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
      setHealth(false);
    })
    .finally(() => {
      button.disabled = false;
    });
});
elements.moduleList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-module-key]");
  if (!button) return;

  const key = button.dataset.moduleKey;
  const current = window.__ktrlboyModules || {};
  const module = current[key];
  if (!module) return;

  window.__ktrlboyModules = {
    ...current,
    [key]: {
      ...module,
      enabled: !module.enabled,
    },
  };
  moduleFormDirty = true;
  renderModules({ modules: window.__ktrlboyModules });
});
elements.modulesSave.addEventListener("click", () => {
  saveModules().catch((error) => {
    elements.detailErrors.textContent = error instanceof Error ? error.message : String(error);
    setHealth(false);
  });
});

resetTimerForm();
refreshStatus();
if (window.location.hash && panels.has(window.location.hash.slice(1))) {
  activatePanel(window.location.hash.slice(1));
}
setInterval(refreshStatus, 5000);
