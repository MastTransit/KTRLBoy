import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const guiRoot = path.join(process.cwd(), "src", "gui");
const resolvedGuiRoot = path.resolve(guiRoot);
const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
};

function writeJson(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(body, null, 2));
}

function writeHtml(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 100000) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      if (!body) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error("Request body must be valid JSON."));
      }
    });
    req.on("error", reject);
  });
}

function writeFile(res, filePath) {
  fs.readFile(filePath, (error, content) => {
    if (error) {
      writeJson(res, 404, { ok: false, error: "Not found" });
      return;
    }

    const extension = path.extname(filePath);
    res.writeHead(200, {
      "Content-Type": mimeTypes[extension] || "application/octet-stream",
      "Cache-Control": "no-store",
    });
    res.end(content);
  });
}

function tryServeGui(req, res) {
  if (req.method !== "GET") return false;

  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/" || url.pathname === "/gui") {
    writeFile(res, path.join(guiRoot, "index.html"));
    return true;
  }

  if (!url.pathname.startsWith("/gui/")) return false;

  const requestedPath = decodeURIComponent(url.pathname.replace("/gui/", ""));
  const filePath = path.resolve(guiRoot, requestedPath);
  if (filePath !== resolvedGuiRoot && !filePath.startsWith(`${resolvedGuiRoot}${path.sep}`)) {
    writeJson(res, 403, { ok: false, error: "Forbidden" });
    return true;
  }

  writeFile(res, filePath);
  return true;
}

function missingFields(fields) {
  return Object.entries(fields)
    .filter(([, value]) => !value)
    .map(([name]) => name);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function oauthResultPage(title, message, event = null) {
  const eventJson = event ? JSON.stringify(event).replaceAll("</", "<\\/") : "null";

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${title}</title>
    <style>
      body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: #f6f7f2; color: #1d211c; font-family: system-ui, sans-serif; }
      main { width: min(520px, calc(100vw - 32px)); border: 1px solid #dce1d7; background: #fff; padding: 28px; box-shadow: 0 18px 44px rgba(26, 31, 26, .1); }
      h1 { margin: 0 0 10px; font-size: 1.45rem; }
      p { color: #667064; line-height: 1.5; }
      a { color: #135a38; font-weight: 700; }
    </style>
  </head>
  <body>
    <main>
      <h1>${escapeHtml(title)}</h1>
      <p>${escapeHtml(message)}</p>
      <a href="/">Back to KTRLBoy</a>
    </main>
    <script>
      const event = ${eventJson};
      if (event) {
        try {
          localStorage.setItem("ktrlboy-auth-event", JSON.stringify(event));
          if (window.opener) window.opener.postMessage(event, window.location.origin);
        } catch {}
        window.setTimeout(() => {
          if (window.opener) window.close();
          else window.location.href = "/#logins";
        }, 1600);
      }
    </script>
  </body>
</html>`;
}

export function createStatusServer(
  config,
  state,
  logger,
  oauthManager = null,
  commandStore = null,
  router = null,
  moderationStore = null,
  authorizationCatalog = null,
  timerStore = null,
  moduleStore = null,
) {
  let server;

  function snapshot() {
    const baseUrl = `http://${config.launcherStatus.host}:${config.launcherStatus.port}`;

    return {
      botName: config.botName,
      ok: state.errors.length === 0,
      uptimeMs: Date.now() - state.startedAt,
      commandPrefix: config.commandPrefix,
      routes: {
        gui: `${baseUrl}/`,
        health: `${baseUrl}/health`,
        status: `${baseUrl}/status`,
      },
      requestedPlatforms: config.enabledPlatforms,
      startedPlatforms: state.platforms
        .filter((platform) => platform.status === "started")
        .map((platform) => platform.name),
      platforms: state.platforms,
      oauth: oauthManager?.status() || {},
      authorizations: authorizationCatalog?.getCatalog?.() || null,
      commands: {
        builtIn: router?.listBuiltIns?.() || [],
        custom: commandStore?.list?.() || [],
      },
      moderation: moderationStore
        ? {
            settings: moderationStore.getSettings(),
            log: moderationStore.recentLog(),
          }
        : null,
      timers: timerStore
        ? {
            items: timerStore.list(),
          }
        : null,
      modules: moduleStore?.getSettings?.() || null,
      platformConfig: {
        twitch: {
          configured: Boolean(
            config.twitch.channel && config.twitch.username && config.twitch.oauthToken,
          ),
          missing: missingFields({
            TWITCH_CHANNEL: config.twitch.channel,
            TWITCH_BOT_USERNAME: config.twitch.username,
            TWITCH_OAUTH_TOKEN: config.twitch.oauthToken,
          }),
        },
        youtube: {
          configured: Boolean(config.youtube.accessToken && config.youtube.liveChatId),
          missing: missingFields({
            YOUTUBE_ACCESS_TOKEN: config.youtube.accessToken,
            YOUTUBE_LIVE_CHAT_ID: config.youtube.liveChatId,
          }),
        },
        kick: {
          configured: Boolean(config.kick.accessToken),
          missing: missingFields({
            KICK_ACCESS_TOKEN: config.kick.accessToken,
          }),
        },
      },
      errors: state.errors,
    };
  }

  function start() {
    if (!config.launcherStatus.enabled) return;

    server = http.createServer((req, res) => {
      const url = new URL(req.url, "http://localhost");

      if (oauthManager && url.pathname === "/auth/status" && req.method === "GET") {
        writeJson(res, 200, { ok: true, providers: oauthManager.status() });
        return;
      }

      if (authorizationCatalog && url.pathname === "/api/authorizations") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            catalog: authorizationCatalog.getCatalog(),
          });
          return;
        }

        if (req.method === "POST") {
          authorizationCatalog
            .refresh()
            .then((catalog) => writeJson(res, 200, { ok: true, catalog }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      const oauthMatch = url.pathname.match(
        /^\/auth\/(twitch|youtube|kick)\/(start|callback|logout|refresh|sync-profile|discover-chat)$/,
      );
      if (oauthManager && oauthMatch) {
        const [, provider, action] = oauthMatch;

        if (action === "start" && req.method === "GET") {
          try {
            res.writeHead(302, {
              Location: oauthManager.start(provider, {
                flow: url.searchParams.get("flow") || "browser",
              }),
            });
            res.end();
          } catch (error) {
            writeHtml(
              res,
              400,
              oauthResultPage("Login setup needed", error instanceof Error ? error.message : String(error)),
            );
          }
          return;
        }

        if (action === "callback" && req.method === "GET") {
          oauthManager
            .handleCallback(provider, url.searchParams)
            .then((status) => {
              writeHtml(
                res,
                200,
                oauthResultPage(
                  `${provider} connected`,
                  "Browser verification completed. You can return to the KTRLBoy Logins menu.",
                  {
                    type: "ktrlboy-auth-verified",
                    provider,
                    status,
                    verifiedAt: new Date().toISOString(),
                  },
                ),
              );
            })
            .catch((error) => {
              writeHtml(
                res,
                400,
                oauthResultPage(
                  `${provider} login failed`,
                  error instanceof Error ? error.message : String(error),
                ),
              );
            });
          return;
        }

        if (action === "logout" && req.method === "POST") {
          oauthManager.clear(provider);
          writeJson(res, 200, { ok: true, providers: oauthManager.status() });
          return;
        }

        if (action === "refresh" && req.method === "POST") {
          oauthManager
            .refresh(provider)
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (action === "sync-profile" && req.method === "POST") {
          oauthManager
            .syncProfile(provider)
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (action === "discover-chat" && provider === "youtube" && req.method === "POST") {
          oauthManager
            .discoverYouTubeLiveChat()
            .then((status) => writeJson(res, 200, { ok: true, status }))
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (oauthManager && url.pathname === "/auth/sync-profiles" && req.method === "POST") {
        oauthManager
          .syncProfiles()
          .then((providers) => writeJson(res, 200, { ok: true, providers }))
          .catch((error) =>
            writeJson(res, 400, {
              ok: false,
              error: error instanceof Error ? error.message : String(error),
            }),
          );
        return;
      }

      const commandMatch = url.pathname.match(/^\/api\/commands(?:\/([a-z0-9_-]+))?$/i);
      if (commandStore && commandMatch) {
        const [, commandName] = commandMatch;

        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            builtIn: router?.listBuiltIns?.() || [],
            custom: commandStore.list(),
          });
          return;
        }

        if (req.method === "POST" || req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const command = commandStore.upsert({
                ...body,
                name: commandName || body.name,
              });
              writeJson(res, commandName ? 200 : 201, { ok: true, command });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (req.method === "DELETE" && commandName) {
          const removed = commandStore.remove(commandName);
          writeJson(res, removed ? 200 : 404, { ok: removed });
          return;
        }
      }

      if (moderationStore && url.pathname === "/api/moderation") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            settings: moderationStore.getSettings(),
            log: moderationStore.recentLog(),
          });
          return;
        }

        if (req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const settings = moderationStore.updateSettings(body);
              writeJson(res, 200, { ok: true, settings });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      const timerMatch = url.pathname.match(/^\/api\/timers(?:\/([a-z0-9_-]+))?$/i);
      if (timerStore && timerMatch) {
        const [, timerName] = timerMatch;

        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            timers: timerStore.list(),
          });
          return;
        }

        if (req.method === "POST" || req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const timer = timerStore.upsert({
                ...body,
                name: timerName || body.name,
              });
              writeJson(res, timerName ? 200 : 201, { ok: true, timer });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }

        if (req.method === "DELETE" && timerName) {
          const removed = timerStore.remove(timerName);
          writeJson(res, removed ? 200 : 404, { ok: removed });
          return;
        }
      }

      if (moduleStore && url.pathname === "/api/modules") {
        if (req.method === "GET") {
          writeJson(res, 200, {
            ok: true,
            modules: moduleStore.getSettings(),
          });
          return;
        }

        if (req.method === "PUT") {
          readJsonBody(req)
            .then((body) => {
              const modules = moduleStore.updateSettings(body.modules || body);
              writeJson(res, 200, { ok: true, modules });
            })
            .catch((error) =>
              writeJson(res, 400, {
                ok: false,
                error: error instanceof Error ? error.message : String(error),
              }),
            );
          return;
        }
      }

      if (tryServeGui(req, res)) return;

      if (req.method === "GET" && req.url === "/health") {
        writeJson(res, state.errors.length === 0 ? 200 : 500, {
          ok: state.errors.length === 0,
          botName: config.botName,
        });
        return;
      }

      if (req.method === "GET" && req.url === "/status") {
        writeJson(res, state.errors.length === 0 ? 200 : 500, snapshot());
        return;
      }

      writeJson(res, 404, { ok: false, error: "Not found" });
    });

    server.listen(config.launcherStatus.port, config.launcherStatus.host, () => {
      logger.info(
        `[launcher] status listening on http://${config.launcherStatus.host}:${config.launcherStatus.port}`,
      );
    });
  }

  return {
    start,
    stop: () => server?.close(),
    snapshot,
  };
}
