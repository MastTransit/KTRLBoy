import fs from "node:fs";
import path from "node:path";

const workspaceRoot = process.cwd();
const envPath = path.join(workspaceRoot, ".env");

export function loadDotEnv() {
  if (!fs.existsSync(envPath)) return;

  const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;

    const separator = trimmed.indexOf("=");
    if (separator === -1) continue;

    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }

    if (!process.env[key]) process.env[key] = value;
  }
}

function numberFromEnv(name, fallback) {
  const value = Number(process.env[name]);
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function booleanFromEnv(name, fallback) {
  const value = process.env[name];
  if (!value) return fallback;
  return ["1", "true", "yes", "on"].includes(value.trim().toLowerCase());
}

function listFromEnv(name, fallback = []) {
  const value = process.env[name];
  if (!value) return fallback;
  return value
    .split(",")
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
}

function scopesFromEnv(name, fallback = []) {
  const value = process.env[name];
  if (!value) return fallback;
  return value
    .split(/[\s,]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

export function applyStoredAuth(config, tokenStore) {
  const twitch = tokenStore.get("twitch");
  if (twitch?.accessToken) {
    config.twitch.oauthToken ||= `oauth:${twitch.accessToken}`;
    config.twitch.username ||= twitch.metadata?.username || "";
    config.twitch.channel ||= twitch.metadata?.channelSlug || twitch.metadata?.username || "";
    config.twitch.moderatorUserId ||= twitch.metadata?.userId || "";
  }

  const youtube = tokenStore.get("youtube");
  if (youtube?.accessToken) {
    config.youtube.accessToken ||= youtube.accessToken;
    config.youtube.liveChatId ||= youtube.metadata?.liveChatId || "";
  }

  const kick = tokenStore.get("kick");
  if (kick?.accessToken) {
    config.kick.accessToken ||= kick.accessToken;
    config.kick.broadcasterUserId ||= String(kick.metadata?.userId || "");
  }
}

export function getConfig() {
  loadDotEnv();

  const launcherPort = numberFromEnv("LAUNCHER_STATUS_PORT", 8790);

  return {
    botName: process.env.BOT_NAME || "KTRLBoy",
    commandPrefix: process.env.COMMAND_PREFIX || "!",
    launcherStatus: {
      enabled: booleanFromEnv("LAUNCHER_STATUS_ENABLED", false),
      host: process.env.LAUNCHER_STATUS_HOST || "127.0.0.1",
      port: launcherPort,
    },
    oauth: {
      redirectBaseUrl:
        process.env.OAUTH_REDIRECT_BASE_URL || `http://localhost:${launcherPort}`,
      twitch: {
        clientId: process.env.TWITCH_CLIENT_ID || "",
        clientSecret: process.env.TWITCH_CLIENT_SECRET || "",
        scopes: scopesFromEnv("TWITCH_OAUTH_SCOPES", ["chat:read", "chat:edit"]),
      },
      youtube: {
        clientId: process.env.YOUTUBE_CLIENT_ID || "",
        clientSecret: process.env.YOUTUBE_CLIENT_SECRET || "",
        scopes: scopesFromEnv("YOUTUBE_OAUTH_SCOPES", [
          "https://www.googleapis.com/auth/youtube.force-ssl",
        ]),
      },
      kick: {
        clientId: process.env.KICK_CLIENT_ID || "",
        clientSecret: process.env.KICK_CLIENT_SECRET || "",
        scopes: scopesFromEnv("KICK_OAUTH_SCOPES", [
          "user:read",
          "channel:read",
          "chat:write",
          "events:subscribe",
        ]),
      },
    },
    enabledPlatforms: listFromEnv("ENABLED_PLATFORMS", []),
    twitch: {
      channel: process.env.TWITCH_CHANNEL || "",
      username: process.env.TWITCH_BOT_USERNAME || "",
      oauthToken: process.env.TWITCH_OAUTH_TOKEN || "",
      clientId: process.env.TWITCH_CLIENT_ID || "",
      broadcasterId: process.env.TWITCH_BROADCASTER_ID || "",
      moderatorUserId: process.env.TWITCH_MODERATOR_USER_ID || "",
    },
    youtube: {
      accessToken: process.env.YOUTUBE_ACCESS_TOKEN || "",
      liveChatId: process.env.YOUTUBE_LIVE_CHAT_ID || "",
      pollIntervalMs: numberFromEnv("YOUTUBE_POLL_INTERVAL_MS", 5000),
    },
    kick: {
      accessToken: process.env.KICK_ACCESS_TOKEN || "",
      broadcasterUserId: process.env.KICK_BROADCASTER_USER_ID || "",
      sendAs: process.env.KICK_SEND_AS || "bot",
      webhookPort: numberFromEnv("KICK_WEBHOOK_PORT", 8787),
      webhookSecret: process.env.KICK_WEBHOOK_SECRET || "",
      allowChatCommandModeration: booleanFromEnv("KICK_ALLOW_CHAT_COMMAND_MODERATION", false),
    },
  };
}
