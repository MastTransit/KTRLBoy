# KTRLBoy Chat Bot

A small custom chatbot starter for Twitch, YouTube Live, and Kick. It uses plain Node.js so the first run is simple, and each platform adapter can be expanded as your stream setup grows.

## What It Does

- Responds to `!ping`, `!hello`, `!uptime`, and `!help`
- Connects to Twitch chat over IRC for a quick local bot
- Polls YouTube Live Chat through the YouTube Live Streaming API
- Accepts Kick chat events by webhook and sends Kick chat messages through Kick's official chat API
- Keeps shared command logic in one place so commands work the same across platforms
- Provides a StreamElements-inspired local dashboard with Integrations, Commands, Timers, Spam Filters, and Modules
- Lets moderators manage custom commands from chat with `!cmd`
- Lets moderators toggle major modules from chat with `!module`
- Sends timer messages at configured intervals after enough chat activity
- Applies local spam filters for blocked terms, links, caps, repeated characters, and message spam

## Quick Start

1. Copy `.env.example` to `.env`.
2. Fill in the platform credentials you want to use.
3. Set `ENABLED_PLATFORMS`, for example:

```env
ENABLED_PLATFORMS=twitch,youtube,kick
```

4. Run:

```powershell
npm.cmd run check
npm.cmd start
```

To smoke test KTRLBoy locally before integrating it with another launcher:

```powershell
npm.cmd run test:local
```

To open the local GUI menu:

```powershell
npm.cmd run gui
```

Then visit `http://localhost:8790/`.

For Twitch, YouTube, and Kick login setup, see [docs/login-integration.md](docs/login-integration.md).

To refresh and store provider authorization links, see [docs/authorization-links.md](docs/authorization-links.md).

To add or edit chat commands from the GUI, see [docs/command-editor.md](docs/command-editor.md).

To schedule recurring chat messages, see [docs/timers.md](docs/timers.md).

To enable spam filter moderation rules, see [docs/moderation.md](docs/moderation.md).

To turn bot areas on or off from the dashboard or chat, see [docs/modules.md](docs/modules.md).

To test KTRLBoy as a Windows executable, see [docs/executable-test.md](docs/executable-test.md).

## Run Beside Another GitHub Project

KTRLBoy can run as a sidecar next to a project you collaborate on. The safest default is to keep the bot in its own folder beside that repo:

```text
projects/
  collaborator-project/
  ktrlboy-chat-bot/
```

For Docker or submodule setups, see [docs/github-sidecar.md](docs/github-sidecar.md).

If the GitHub project is a launcher, use [docs/launcher-integration.md](docs/launcher-integration.md) for the start command and local health/status API.

## Platform Notes

### Twitch

This starter uses Twitch IRC because it is the fastest way to get a local custom bot online. Twitch's current docs recommend EventSub and the Twitch API for full chatbot functionality, but IRC remains useful for simple read/write chat bots.

Required environment:

```env
TWITCH_CHANNEL=your_channel_name
TWITCH_BOT_USERNAME=your_bot_username
TWITCH_OAUTH_TOKEN=oauth:...
```

The token needs chat read/write permissions, commonly `chat:read` and `chat:edit`.

### YouTube

YouTube Live Chat requires an OAuth access token and the active `liveChatId` for the current broadcast. The bot polls `liveChatMessages.list` and posts replies with `liveChatMessages.insert`.

Required environment:

```env
YOUTUBE_ACCESS_TOKEN=...
YOUTUBE_LIVE_CHAT_ID=...
```

### Kick

Kick now has official developer docs for OAuth, chat APIs, and webhooks. This starter receives chat events at:

```text
POST /kick/webhook
```

Run the bot locally, expose the webhook with a tunnel such as Cloudflare Tunnel or ngrok, then subscribe Kick events to your public URL.

Required environment:

```env
KICK_ACCESS_TOKEN=...
KICK_SEND_AS=bot
KICK_WEBHOOK_PORT=8787
```

If sending as `user`, also set:

```env
KICK_BROADCASTER_USER_ID=123
```

## Adding Commands

Edit `src/core/commandRouter.js`. Each command receives:

```js
{
  platform,
  channel,
  user,
  text,
  raw,
  reply
}
```

Add a new command in the `commands` map:

```js
shoutout: async (ctx, args) => {
  const name = args[0]?.replace(/^@/, "");
  if (!name) return ctx.reply("Usage: !shoutout @name");
  return ctx.reply(`Go check out @${name}!`);
}
```

## Useful Official Docs

- Twitch Chat & Chatbots: https://dev.twitch.tv/docs/chat
- YouTube Live Chat Messages: https://developers.google.com/youtube/v3/live/docs/liveChatMessages
- Kick Chat API: https://docs.kick.com/apis/chat
