# Login Integration

KTRLBoy supports local OAuth login for Twitch, YouTube, and Kick from the GUI menu.

## Local Callback URLs

Add these redirect/callback URLs to each provider developer app:

```text
http://localhost:8790/auth/twitch/callback
http://localhost:8790/auth/youtube/callback
http://localhost:8790/auth/kick/callback
```

Keep this value in `.env`:

```env
OAUTH_REDIRECT_BASE_URL=http://localhost:8790
```

## Twitch

Create a Twitch developer app, then set:

```env
TWITCH_CLIENT_ID=
TWITCH_CLIENT_SECRET=
TWITCH_OAUTH_SCOPES=chat:read chat:edit
```

KTRLBoy stores the logged-in Twitch access token and uses it as the IRC bot token. Set `TWITCH_CHANNEL` when the bot should join a channel that is different from the logged-in account.

## YouTube

Create a Google Cloud OAuth web client, enable the YouTube Data API v3, then set:

```env
YOUTUBE_CLIENT_ID=
YOUTUBE_CLIENT_SECRET=
YOUTUBE_OAUTH_SCOPES=https://www.googleapis.com/auth/youtube.force-ssl
```

After connecting YouTube, use `Find Chat` in the GUI while your stream is live. KTRLBoy will try to discover the active broadcast's `liveChatId`.

## Kick

Create a Kick app, then set:

```env
KICK_CLIENT_ID=
KICK_CLIENT_SECRET=
KICK_OAUTH_SCOPES=user:read channel:read chat:write events:subscribe
```

Kick uses OAuth 2.1 with PKCE. KTRLBoy handles the PKCE verifier and stores the resulting token locally.

## Token Storage

Tokens are stored in:

```text
.auth/tokens.json
```

This folder is ignored by Git and is excluded from Docker/package artifacts. Treat it like a password file.

## GUI Flow

1. Run `npm.cmd run gui`.
2. Open `http://localhost:8790/`.
3. Go to `Logins`.
4. Choose `Refresh Auth Links` to pull and store the latest provider authorization links.
5. Choose `Verify in Browser` for each provider.
6. Complete the provider login in your browser.
7. KTRLBoy marks the account as browser-verified when the provider redirects back.
8. Use `Sync Login` to pull the latest connected account profile from the provider APIs.
9. Restart KTRLBoy after changing `ENABLED_PLATFORMS` so adapters start with the new credentials.

The OAuth callback still returns to KTRLBoy's local server so the app can securely store the token, but the account verification itself happens through the provider's browser login page.
