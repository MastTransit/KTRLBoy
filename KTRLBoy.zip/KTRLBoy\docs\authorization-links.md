# Authorization Links

KTRLBoy stores provider authorization link metadata separately from real OAuth tokens.

Run:

```powershell
npm.cmd run gui
```

Open:

```text
http://localhost:8790/
```

Go to `Logins`, then use `Refresh Auth Links`.

## What Is Stored

KTRLBoy stores safe provider metadata in:

```text
.data/authorizations.json
```

This can include:

- OAuth authorization endpoint
- token endpoint
- provider OAuth docs link
- provider developer/app setup link
- KTRLBoy callback URL
- requested scopes

Actual access tokens and refresh tokens stay in:

```text
.auth/tokens.json
```

## Buttons

The Logins screen turns the stored metadata into provider buttons:

- `Verify in Browser`
- `App Setup`
- `OAuth Docs`
- `Auth Endpoint`

Use `Verify in Browser` for login. The external buttons are there to help you open each provider's setup or reference pages quickly.
