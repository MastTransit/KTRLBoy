# Launcher Integration

KTRLBoy is ready to run as a sidecar process from a launcher-style GitHub project.

## Start Command

From the launcher, start:

```text
scripts\start-ktrlboy.cmd
```

Or call Node directly from this folder:

```text
npm.cmd run launcher
```

## Status API

Enable the local status API in `.env`:

```env
LAUNCHER_STATUS_ENABLED=true
LAUNCHER_STATUS_HOST=127.0.0.1
LAUNCHER_STATUS_PORT=8790
```

The launcher can poll:

```text
GET http://127.0.0.1:8790/health
GET http://127.0.0.1:8790/status
```

The GUI menu runs at:

```text
http://localhost:8790/
```

`/health` returns a small readiness result:

```json
{
  "ok": true,
  "botName": "KTRLBoy"
}
```

`/status` returns the requested platforms, started platforms, uptime, and startup errors.

## Launcher Flow

1. Check whether `http://127.0.0.1:8790/health` is already healthy.
2. If it is not running, start `scripts\start-ktrlboy.cmd`.
3. Poll `/health` until it returns `200`.
4. Show bot status in the launcher using `/status`.

## Important

Keep KTRLBoy's `.env` in the bot folder. Do not move Twitch, YouTube, or Kick tokens into the launcher repo unless that repo is private and intentionally owns those secrets.
