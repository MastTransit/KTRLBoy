import { applyStoredAuth, getConfig } from "./config.js";
import { createAuthorizationCatalog } from "./core/authorizationCatalog.js";
import { builtInCommandDescriptions, createCommandRouter } from "./core/commandRouter.js";
import { createCommandStore } from "./core/commandStore.js";
import { createModerationEngine } from "./core/moderationEngine.js";
import { createModerationStore } from "./core/moderationStore.js";
import { createModuleStore } from "./core/moduleStore.js";
import { createOAuthManager } from "./core/oauthManager.js";
import { createStatusServer } from "./core/statusServer.js";
import { createTimerEngine } from "./core/timerEngine.js";
import { createTimerStore } from "./core/timerStore.js";
import { createTokenStore } from "./core/tokenStore.js";
import { createTwitchAdapter } from "./platforms/twitch.js";
import { createYouTubeAdapter } from "./platforms/youtube.js";
import { createKickAdapter } from "./platforms/kick.js";

const logger = {
  info: (...args) => console.log(...args),
  warn: (...args) => console.warn(...args),
  error: (...args) => console.error(...args),
};

async function main() {
  const config = getConfig();
  const tokenStore = createTokenStore();
  const oauthManager = createOAuthManager(config, tokenStore, logger);
  const authorizationCatalog = createAuthorizationCatalog(config, logger);

  await oauthManager.refreshExpiredTokens();
  applyStoredAuth(config, tokenStore);

  const commandStore = createCommandStore({
    reservedNames: Object.keys(builtInCommandDescriptions),
  });
  const moduleStore = createModuleStore();
  const moderationStore = createModerationStore();
  const moderationEngine = createModerationEngine(moderationStore, logger, moduleStore);
  const timerStore = createTimerStore();
  const timerEngine = createTimerEngine(timerStore, moduleStore, logger, {
    botName: config.botName,
    commandPrefix: config.commandPrefix,
  });

  config.twitch.getAccessToken = () => oauthManager.accessToken("twitch");
  config.youtube.getAccessToken = () => oauthManager.accessToken("youtube");
  config.kick.getAccessToken = () => oauthManager.accessToken("kick");

  const router = createCommandRouter({
    commandPrefix: config.commandPrefix,
    botName: config.botName,
    commandStore,
    moderationEngine,
    timerEngine,
    moduleStore,
  });
  const state = {
    startedAt: Date.now(),
    platforms: [],
    errors: [],
  };

  const adapters = {
    twitch: () => createTwitchAdapter(config.twitch, router, logger),
    youtube: () => createYouTubeAdapter(config.youtube, router, logger),
    kick: () => createKickAdapter(config.kick, router, logger),
  };

  logger.info(`${config.botName} starting`);
  logger.info(`Enabled platforms: ${config.enabledPlatforms.join(", ") || "none"}`);

  const started = [];
  const statusServer = createStatusServer(
    config,
    state,
    logger,
    oauthManager,
    commandStore,
    router,
    moderationStore,
    authorizationCatalog,
    timerStore,
    moduleStore,
  );

  for (const platform of config.enabledPlatforms) {
    const createAdapter = adapters[platform];
    if (!createAdapter) {
      const message = `Unknown platform "${platform}" in ENABLED_PLATFORMS`;
      logger.warn(message);
      state.platforms.push({ name: platform, status: "unknown" });
      state.errors.push(message);
      continue;
    }

    try {
      const adapter = createAdapter();
      adapter.start();
      started.push(adapter);
      state.platforms.push({ name: platform, status: "started" });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      logger.error(`[${platform}] failed to start`, error);
      state.platforms.push({ name: platform, status: "failed", error: message });
      state.errors.push(message);
    }
  }

  if (started.length === 0) {
    logger.warn("No adapters started. Set ENABLED_PLATFORMS in .env.");
  }

  timerEngine.start(started);
  statusServer.start();

  function shutdown() {
    logger.info("Shutting down bot");
    for (const adapter of started) {
      adapter.stop?.();
    }
    timerEngine.stop();
    statusServer.stop();
    process.exit(0);
  }

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main().catch((error) => {
  logger.error("KTRLBoy failed to start", error);
  process.exit(1);
});
