import crypto from "node:crypto";
import { isExpired, tokenPublicStatus } from "./tokenStore.js";

const providerNames = ["twitch", "youtube", "kick"];
const YOUTUBE_API_ROOT = "https://www.googleapis.com/youtube/v3";

function base64Url(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function randomString(size = 32) {
  return base64Url(crypto.randomBytes(size));
}

function codeChallenge(verifier) {
  return base64Url(crypto.createHash("sha256").update(verifier).digest());
}

function formBody(fields) {
  const body = new URLSearchParams();
  for (const [key, value] of Object.entries(fields)) {
    if (value !== undefined && value !== null && value !== "") {
      body.set(key, value);
    }
  }
  return body;
}

function expiresAt(expiresIn) {
  const seconds = Number(expiresIn);
  if (!Number.isFinite(seconds) || seconds <= 0) return null;
  return new Date(Date.now() + seconds * 1000).toISOString();
}

function normalizeScopes(value, fallback = []) {
  if (Array.isArray(value)) return value;
  if (!value) return fallback;
  return String(value)
    .split(/[\s,]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function normalizeToken(provider, token, metadata, requestedScopes, previousRecord = null) {
  return {
    provider,
    accessToken: token.access_token,
    refreshToken: token.refresh_token || previousRecord?.refreshToken || "",
    tokenType: token.token_type || previousRecord?.tokenType || "Bearer",
    expiresAt: expiresAt(token.expires_in) || previousRecord?.expiresAt || null,
    scopes: normalizeScopes(token.scope, requestedScopes),
    metadata: {
      ...(previousRecord?.metadata || {}),
      ...metadata,
    },
  };
}

async function readJsonResponse(response, label) {
  const text = await response.text();
  const body = text ? JSON.parse(text) : {};

  if (!response.ok) {
    throw new Error(`${label} ${response.status}: ${body.error_description || body.error || text}`);
  }

  return body;
}

async function postForm(url, fields, label) {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: formBody(fields),
  });
  return readJsonResponse(response, label);
}

async function getJson(url, accessToken, label, authorizationPrefix = "Bearer", headers = {}) {
  const response = await fetch(url, {
    headers: {
      Authorization: `${authorizationPrefix} ${accessToken}`,
      Accept: "application/json",
      ...headers,
    },
  });
  return readJsonResponse(response, label);
}

export function createOAuthManager(config, tokenStore, logger) {
  const pending = new Map();

  function providerConfig(provider) {
    const providerOauth = config.oauth[provider];
    if (!providerOauth) throw new Error(`Unknown OAuth provider "${provider}"`);
    return providerOauth;
  }

  function redirectUri(provider) {
    return `${config.oauth.redirectBaseUrl.replace(/\/$/, "")}/auth/${provider}/callback`;
  }

  function requireCredentials(provider) {
    const providerOauth = providerConfig(provider);
    const missing = [];
    if (!providerOauth.clientId) missing.push(`${provider.toUpperCase()}_CLIENT_ID`);
    if (!providerOauth.clientSecret) missing.push(`${provider.toUpperCase()}_CLIENT_SECRET`);
    if (missing.length) {
      throw new Error(`${provider} login is missing ${missing.join(", ")}`);
    }
  }

  function configured(provider) {
    try {
      requireCredentials(provider);
      return true;
    } catch {
      return false;
    }
  }

  function start(provider, options = {}) {
    requireCredentials(provider);

    const providerOauth = providerConfig(provider);
    const state = randomString();
    const verifier = provider === "kick" ? randomString(64) : "";
    const scopes = providerOauth.scopes || [];
    const flow = options.flow === "local" ? "local" : "browser";

    pending.set(state, {
      provider,
      codeVerifier: verifier,
      createdAt: Date.now(),
      flow,
    });

    const authUrl = new URL(
      provider === "youtube"
        ? "https://accounts.google.com/o/oauth2/v2/auth"
        : provider === "kick"
          ? "https://id.kick.com/oauth/authorize"
          : "https://id.twitch.tv/oauth2/authorize",
    );

    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("client_id", providerOauth.clientId);
    authUrl.searchParams.set("redirect_uri", redirectUri(provider));
    authUrl.searchParams.set("scope", scopes.join(" "));
    authUrl.searchParams.set("state", state);

    if (provider === "youtube") {
      authUrl.searchParams.set("access_type", "offline");
      authUrl.searchParams.set("prompt", "consent");
      authUrl.searchParams.set("include_granted_scopes", "true");
    }

    if (provider === "kick") {
      authUrl.searchParams.set("code_challenge", codeChallenge(verifier));
      authUrl.searchParams.set("code_challenge_method", "S256");
    }

    return authUrl.toString();
  }

  async function exchange(provider, code, pendingLogin) {
    const providerOauth = providerConfig(provider);
    const scopes = providerOauth.scopes || [];

    if (provider === "twitch") {
      const token = await postForm(
        "https://id.twitch.tv/oauth2/token",
        {
          client_id: providerOauth.clientId,
          client_secret: providerOauth.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri(provider),
        },
        "Twitch token exchange failed",
      );
      const validation = await getJson(
        "https://id.twitch.tv/oauth2/validate",
        token.access_token,
        "Twitch token validation failed",
        "OAuth",
      );
      const profile = await discoverTwitchMetadata(
        token.access_token,
        providerOauth.clientId,
      ).catch((error) => {
        logger.warn("[twitch] login succeeded but profile discovery failed", error.message);
        return {};
      });
      return normalizeToken(
        provider,
        token,
        {
          userId: validation.user_id,
          username: validation.login,
          channelSlug: validation.login,
          ...profile,
        },
        validation.scopes || scopes,
      );
    }

    if (provider === "youtube") {
      const token = await postForm(
        "https://oauth2.googleapis.com/token",
        {
          client_id: providerOauth.clientId,
          client_secret: providerOauth.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri(provider),
        },
        "YouTube token exchange failed",
      );
      const metadata = await discoverYouTubeMetadata(token.access_token).catch((error) => {
        logger.warn("[youtube] login succeeded but live chat discovery failed", error.message);
        return {};
      });
      return normalizeToken(provider, token, metadata, scopes);
    }

    if (provider === "kick") {
      const token = await postForm(
        "https://id.kick.com/oauth/token",
        {
          client_id: providerOauth.clientId,
          client_secret: providerOauth.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri(provider),
          code_verifier: pendingLogin.codeVerifier,
        },
        "Kick token exchange failed",
      );
      const metadata = await discoverKickMetadata(token.access_token).catch((error) => {
        logger.warn("[kick] login succeeded but user discovery failed", error.message);
        return {};
      });
      return normalizeToken(provider, token, metadata, scopes);
    }

    throw new Error(`Unknown OAuth provider "${provider}"`);
  }

  async function handleCallback(provider, query) {
    if (query.get("error")) {
      throw new Error(query.get("error_description") || query.get("error"));
    }

    const state = query.get("state");
    const code = query.get("code");
    const pendingLogin = pending.get(state);

    if (!state || !pendingLogin || pendingLogin.provider !== provider) {
      throw new Error("OAuth state did not match. Start the login again from KTRLBoy.");
    }

    if (!code) throw new Error("OAuth callback did not include an authorization code.");

    pending.delete(state);
    const record = await exchange(provider, code, pendingLogin);
    record.metadata = {
      ...(record.metadata || {}),
      verificationMethod: pendingLogin.flow,
      browserVerifiedAt:
        pendingLogin.flow === "browser" ? new Date().toISOString() : record.metadata?.browserVerifiedAt,
      localVerifiedAt:
        pendingLogin.flow === "local" ? new Date().toISOString() : record.metadata?.localVerifiedAt,
    };
    const saved = tokenStore.set(provider, record);
    return tokenPublicStatus(saved);
  }

  async function refresh(provider) {
    requireCredentials(provider);

    const previousRecord = tokenStore.get(provider);
    if (!previousRecord?.refreshToken) {
      throw new Error(`${provider} does not have a refresh token yet`);
    }

    const providerOauth = providerConfig(provider);
    const tokenUrl =
      provider === "youtube"
        ? "https://oauth2.googleapis.com/token"
        : provider === "kick"
          ? "https://id.kick.com/oauth/token"
          : "https://id.twitch.tv/oauth2/token";

    const token = await postForm(
      tokenUrl,
      {
        client_id: providerOauth.clientId,
        client_secret: providerOauth.clientSecret,
        refresh_token: previousRecord.refreshToken,
        grant_type: "refresh_token",
      },
      `${provider} refresh failed`,
    );

    const saved = tokenStore.set(
      provider,
      normalizeToken(provider, token, {}, providerOauth.scopes || [], previousRecord),
    );

    return tokenPublicStatus(saved);
  }

  async function refreshExpiredTokens() {
    for (const provider of providerNames) {
      const record = tokenStore.get(provider);
      if (!record?.accessToken || !isExpired(record)) continue;
      if (!configured(provider)) continue;

      try {
        await refresh(provider);
      } catch (error) {
        logger.warn(`[${provider}] stored token refresh failed`, error.message);
      }
    }
  }

  async function accessToken(provider) {
    const record = tokenStore.get(provider);
    if (!record?.accessToken) return "";

    if (isExpired(record) && record.refreshToken && configured(provider)) {
      await refresh(provider);
      return tokenStore.get(provider)?.accessToken || "";
    }

    return record.accessToken;
  }

  async function discoverYouTubeLiveChat() {
    const token = await accessToken("youtube");
    if (!token) throw new Error("YouTube is not connected");

    const metadata = await discoverYouTubeMetadata(token);
    const previousRecord = tokenStore.get("youtube");
    const saved = tokenStore.set("youtube", {
      ...previousRecord,
      metadata: {
        ...(previousRecord?.metadata || {}),
        ...metadata,
      },
    });
    return tokenPublicStatus(saved);
  }

  async function syncProfile(provider) {
    requireCredentials(provider);

    const token = await accessToken(provider);
    if (!token) throw new Error(`${provider} is not connected`);

    let metadata = {};
    if (provider === "twitch") {
      metadata = await discoverTwitchMetadata(token, providerConfig(provider).clientId);
    } else if (provider === "youtube") {
      metadata = await discoverYouTubeMetadata(token);
    } else if (provider === "kick") {
      metadata = await discoverKickMetadata(token);
    } else {
      throw new Error(`Unknown OAuth provider "${provider}"`);
    }

    const previousRecord = tokenStore.get(provider);
    const saved = tokenStore.set(provider, {
      ...previousRecord,
      metadata: {
        ...(previousRecord?.metadata || {}),
        ...metadata,
        syncedAt: new Date().toISOString(),
      },
    });
    return tokenPublicStatus(saved);
  }

  async function syncProfiles() {
    const results = {};
    for (const provider of providerNames) {
      const record = tokenStore.get(provider);
      if (!record?.accessToken || !configured(provider)) {
        results[provider] = tokenPublicStatus(record);
        continue;
      }

      try {
        results[provider] = await syncProfile(provider);
      } catch (error) {
        logger.warn(`[${provider}] profile sync failed`, error.message);
        results[provider] = tokenPublicStatus(record);
      }
    }
    return results;
  }

  function status() {
    const tokenStatus = tokenStore.status();
    return Object.fromEntries(
      providerNames.map((provider) => [
        provider,
        {
          configured: configured(provider),
          redirectUri: redirectUri(provider),
          scopes: providerConfig(provider).scopes || [],
          connectPath: `/auth/${provider}/start?flow=browser`,
          localConnectPath: `/auth/${provider}/start?flow=local`,
          ...tokenStatus[provider],
        },
      ]),
    );
  }

  function clear(provider) {
    tokenStore.clear(provider);
  }

  return {
    accessToken,
    clear,
    discoverYouTubeLiveChat,
    handleCallback,
    refresh,
    refreshExpiredTokens,
    start,
    status,
    syncProfile,
    syncProfiles,
  };
}

async function discoverTwitchMetadata(accessToken, clientId) {
  const data = await getJson(
    "https://api.twitch.tv/helix/users",
    accessToken,
    "Twitch profile discovery failed",
    "Bearer",
    { "Client-Id": clientId },
  );
  const user = data.data?.[0] || {};
  return {
    userId: user.id,
    username: user.login,
    displayName: user.display_name,
    channelSlug: user.login,
    profileImage: user.profile_image_url,
    description: user.description,
    broadcasterType: user.broadcaster_type,
  };
}

async function discoverYouTubeMetadata(accessToken) {
  const channelUrl = new URL(`${YOUTUBE_API_ROOT}/channels`);
  channelUrl.searchParams.set("part", "snippet");
  channelUrl.searchParams.set("mine", "true");

  const url = new URL(`${YOUTUBE_API_ROOT}/liveBroadcasts`);
  url.searchParams.set("part", "snippet");
  url.searchParams.set("broadcastStatus", "active");
  url.searchParams.set("broadcastType", "all");
  url.searchParams.set("mine", "true");

  const [channelData, liveData] = await Promise.all([
    getJson(channelUrl, accessToken, "YouTube channel discovery failed"),
    getJson(url, accessToken, "YouTube live broadcast discovery failed"),
  ]);
  const channel = channelData.items?.[0];
  const broadcast = liveData.items?.[0];
  return {
    channelId: channel?.id || "",
    channelTitle: channel?.snippet?.title || "",
    customUrl: channel?.snippet?.customUrl || "",
    profileImage: channel?.snippet?.thumbnails?.default?.url || "",
    liveChatId: broadcast?.snippet?.liveChatId || "",
    broadcastTitle: broadcast?.snippet?.title || "",
    broadcastId: broadcast?.id || "",
  };
}

async function discoverKickMetadata(accessToken) {
  const data = await getJson(
    "https://api.kick.com/public/v1/users",
    accessToken,
    "Kick user discovery failed",
  );
  const user = data.data?.[0] || {};
  return {
    userId: user.user_id,
    username: user.username,
    displayName: user.name || user.username,
    profileImage: user.profile_picture,
    channelSlug: user.channel_slug,
  };
}
